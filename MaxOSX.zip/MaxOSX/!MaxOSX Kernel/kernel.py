import os
import sys
import shutil
from pathlib import Path
from tkinter import Tk, Frame, Text, BOTH, Toplevel, END
import traceback

system = sys.platform

class RSOD(Exception):
    def __init__(self):
        #Exception.__init__(self)
        root1 = Tk()

        #sizeX, sizeY = root1.winfo_screenwidth(), root1.winfo_screenheight()

        root1.wm_attributes('-fullscreen',1)
        root1.wm_attributes('-topmost',1)

        root1['cursor'] = 'none'
        root1['bg'] = '#b50e0e'

        text2 = Text(root1,
        bg='#b50e0e', fg='#adadad', font=('Courier', 25),
        selectbackground='#b50e0e', selectforeground='#adadad',highlightthickness=0, insertbackground='#b50e0e', cursor='none', wrap='word')
        text2.pack(fill=BOTH, expand=1)

        a = traceback.format_exc()
        text = [
        'Kernel panic','\n\n',
        'Python error','\n\n',
        a,'\n\n',
        '[PRESS ANY KEY]'
        ]

        for i in text:
            text2.insert(END, i)

        text2['state'] = 'disabled'

        root1.bind("<KeyRelease>", quit)

        root1.mainloop()

class COPY():
    def __init__(self, path, newpath):
        try:
            if os.path.isdir(path):
                os.mkdir(newpath)
                for i in os.listdir(path):
                    COPY(Path(path, i), Path(newpath, i))
            else:
                shutil.copy(path, newpath)
        except Exception:
            RSOD()

if __name__ == '__main__':
    shutil.copy(Path('kernel.py'),Path('..','MaxOS','!OSX','kernel.py'))
    if sys.platform == 'win32':os.system(f"cd \"{Path('..','MaxOS','!OSX')}\" & python OS.py")
    else:os.system(f"cd '{Path('..','MaxOS','!OSX')}' & python3 OS.py")
