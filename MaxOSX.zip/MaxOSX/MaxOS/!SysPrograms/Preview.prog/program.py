from MaxOSTkinter import (
                            MaxOSTk,
                            DialogWin,
                            WhatDialogWin,
                            LabelButtonSystem,
                            ListButton,
                            Separator,
                            empty,
                            ColorDialogWin,
                            MaxOSTk2,
                            BUTTON_MENU,
                            DialogWinCustom,
                            ThemeButtons,
                            FileDialogWin,
                            FileNameDialogWin
                        )
from tkinter import (
                        Frame,
                        Label,
                        Toplevel,
                        BOTH,
                        Y,
                        X,
                        NW,
                        N,
                        SW,
                        S,
                        W,
                        E,
                        NE,
                        LEFT,
                        RIGHT,
                        TOP,
                        BOTTOM,
                        Menu,
                        font,
                        Text,
                        END,
                        Canvas
                    )
import os
import sys
import shutil
from pathlib import Path
from threading import Thread
from customtkinter import CTkLabel, CTkFrame, CTkComboBox, CTkSlider, CTkScrollableFrame, CTkScrollbar
from PIL import Image, ImageTk, ImageColor, ImageChops, ImageDraw
import psutil
import sys



class MenuBtn():
    def destroy(self):
        self.btn.after_cancel(self.theme_after)
        self.btn.destroy()

    def __init__(self, master, text, command):
        self.selectbg_ = ''
        self.activebg_ = ''
        self.bg_ = ''
        def theme_update():
            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)
            self.theme_after = self.btn.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())

            color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                color_rgb_activebackground[0] = 0
            else:
                color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

            if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                color_rgb_activebackground[1] = 0
            else:
                color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

            if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                color_rgb_activebackground[2] = 0
            else:
                color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

            activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])


            self.btn['fg'] = fg_color
            self.btn['font'] = (font_, font_size-2)

            self.bg_ = bg_color
            self.selectbg_ = selectbg
            self.activebg_ = activebackground

            if self.HOVER_STATE:
                self.btn['bg'] = selectbg
            if self.ACTIVE_STATE:
                self.btn['bg'] = activebackground
            if self.ACTIVE_STATE != 1 and self.HOVER_STATE != 1:
                self.btn['bg'] = bg_color

        self.ACTIVE_STATE = 0
        self.HOVER_STATE = 0

        def hover(e=''):
            if self.ACTIVE_STATE:
                self.btn['bg'] = self.activebg_
            else:
                self.btn['bg'] = self.selectbg_
            self.HOVER_STATE = 1
        def unhover(e=''):
            self.btn['bg'] = self.bg_
            self.HOVER_STATE = 0

        def active(e=''):
            self.btn['bg'] = self.activebg_

            self.ACTIVE_STATE = 1

        def active_off(e=''):
            if self.HOVER_STATE:
                self.btn['bg'] = self.selectbg_
            else:
                self.btn['bg'] = self.bg_

            self.ACTIVE_STATE = 0

            if self.HOVER_STATE:
                command()

        self.btn = Label(master, text=text, cursor="@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
        self.btn.pack(side=LEFT, padx=2)

        self.btn.bind('<Enter>', hover)
        self.btn.bind('<Leave>', unhover)

        self.btn.bind('<ButtonPress-1>', active)
        self.btn.bind('<ButtonRelease-1>', active_off)

        theme_update()



class App():
    def __init__(self):
        def theme_update():
            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)
            self.theme_after = self.root1.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())

            color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                color_rgb_activebackground[0] = 0
            else:
                color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

            if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                color_rgb_activebackground[1] = 0
            else:
                color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

            if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                color_rgb_activebackground[2] = 0
            else:
                color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

            activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

            self.menubar['bg'] = bg_color

        list_ext = []
        list_ext_text = []
        list_ext_img = []
        for i in os.listdir(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST')):
            if i[0] != '.' or i[0] != '!':
                type = ''
                with open(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST', i,'type.txt'), 'r', encoding='utf-8') as f:
                    type = f.read()

                name = ''
                with open(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST', i,'name.txt'), 'r', encoding='utf-8') as f:
                    name = f.read()

                if type.lower() == 'text':
                    if '|' in name:
                        for n in name.split('|'):
                            list_ext.append(n)
                            list_ext_text.append(n)
                    else:
                        list_ext.append(name)
                        list_ext_text.append(name)
                elif type.lower() == 'image':
                    if '|' in name:
                        for n in name.split('|'):
                            list_ext.append(n)
                            list_ext_img.append(n)
                    else:
                        list_ext.append(name)
                        list_ext_img.append(name)



        def save_file(e=''):
            if self.view_state:
                if os.path.splitext(self.file)[0] == '@new':
                    saveas_file()
                else:
                    if os.path.splitext(self.file)[1] in list_ext_text:
                        a = list(self.view.get())
                        if a[-1] == '\n':
                            a.pop(-1)
                        a = ''.join(a)
                        with open(self.file, 'w', encoding='utf-8') as f:
                            f.write(a)
                    elif os.path.splitext(self.file)[1] in list_ext_img:
                        self.view.get().save(self.file)

                    self.view.set_file_save(0)



        def exitapp():
            if self.view != '':
                if self.view.get_file_save():
                    def OK(e=''):
                        save_file()
                        WIN.destroy()
                        self.root1.after_cancel(self.theme_after)
                        self.root1.ExitDestroy()
                    def CLOSE(e=''):
                        self.root1.after_cancel(self.theme_after)
                        self.root1.ExitDestroy()
                    if os.path.splitext(self.file)[0] == '@new':
                        WIN = WhatDialogWin(self.root1.content, title='Выход', text=f"Сохранить файл?", textyes="Да", textno='Нет', command=OK, commandclose=CLOSE, type='warning')
                    else:
                        WIN = WhatDialogWin(self.root1.content, title='Выход', text=f"Сохранить файл {os.path.split(self.file)[1]}?", textyes="Да", textno='Нет', command=OK, commandclose=CLOSE, type='warning')
                else:
                    self.root1.after_cancel(self.theme_after)
                    self.root1.ExitDestroy()
            else:
                self.root1.after_cancel(self.theme_after)
                self.root1.ExitDestroy()
        self.root1 = MaxOSTk(exitfunc=exitapp, icon=Path(cwd, 'icon.png'))
        self.root1.title2('Просмотр')
        self.root1.geometry('1000x750')
        self.root1.minsize(1000, 750)
        self.root = self.root1.content
        self.menubar = Frame(self.root)
        self.menubar.pack(fill=X, anchor=NW)

        for i in list_ext_text:
            list_ext.append(i)
        for i in list_ext_img:
            list_ext.append(i)



        self.file_save = 0
        self.file = ''

        self.get_file = ''

        self.view = ''
        self.view_state = 0

        def saveas_file(e=''):
            homefolder = ''
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'r', encoding='utf-8') as f:
                homefolder = f.read()
            def OK(e=''):
                PATH = WIN.getpath()
                if os.path.splitext(self.file)[1] in list_ext_text:
                    a = list(self.view.get())
                    if a[-1] == '\n':
                        a.pop(-1)
                    a = ''.join(a)
                    with open(PATH, 'w', encoding='utf-8') as f:
                        f.write(a)
                    self.view.destroy()
                    self.view = TextView(self.root, file=PATH, root=self.root1)
                    self.file = PATH
                    WIN.destroy()
                elif os.path.splitext(self.file)[1] in list_ext_img:
                    try:
                        self.view.get().save(PATH)
                        self.view.destroy()
                        self.view = ImageView(self.root, file=PATH, root=self.root1)
                        self.file = PATH
                        WIN.destroy()
                    except:
                        DialogWin(WIN.frameimgdesktop, title='Ошибка', text='Для данного расширения недоступен формат RGBA.\nПожалуйста выберите расширение для которого формат RGBA доступен', type='error')


            if os.path.splitext(self.file)[1] in list_ext_text:
                WIN = FileNameDialogWin(self.root, ext_list=list_ext_text, name=f"Новый{list_ext_text[0]}", command=OK, folder=homefolder)
            elif os.path.splitext(self.file)[1] in list_ext_img:
                WIN = FileNameDialogWin(self.root, ext_list=list_ext_img, name=f"Новый{list_ext_img[0]}", command=OK, folder=homefolder)


        def open_file(e=''):
            def FileOpen():
                homefolder = ''
                with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'r', encoding='utf-8') as f:
                    homefolder = f.read()
                def OK(e=''):
                    PATH = WIN.getpath()
                    if os.path.splitext(PATH)[1].lower() in list_ext_text:
                        if self.view_state:
                            self.view.destroy()
                        self.view = TextView(self.root, file=PATH, root=self.root1)
                    elif os.path.splitext(PATH)[1].lower() in list_ext_img:
                        if self.view_state:
                            self.view.destroy()
                        self.view = ImageView(self.root, file=PATH, root=self.root1)
                    self.view_state = 1
                    self.file = PATH
                    WIN.destroy()
                WIN = FileDialogWin(self.root1.content, title='Выберите файл', command=OK, ext_list=list_ext, folder=homefolder)
            if self.view != '':
                if self.view.get_file_save():
                    def OK(e=''):
                        save_file()
                        WIN.destroy()
                        FileOpen()
                    def CLOSE(e=''):
                        FileOpen()
                    if os.path.splitext(self.file)[0] == '@new':
                        WIN = WhatDialogWin(self.root1.content, title='Открыть файл', text=f"Сохранить файл?", textyes="Да", textno='Нет', command=OK, commandclose=CLOSE, type='warning')
                    else:
                        WIN = WhatDialogWin(self.root1.content, title='Открыть файл', text=f"Сохранить файл {os.path.split(self.file)[1]}?", textyes="Да", textno='Нет', command=OK, commandclose=CLOSE, type='warning')
                else:
                    FileOpen()
            else:
                FileOpen()

        def new_file(e=''):
            def NewFile():
                def theme_upd():
                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)
                    self.theme_aft2 = root.content.after(10000, theme_upd)

                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0

                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())

                    color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                        color_rgb_activebackground[0] = 0
                    else:
                        color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

                    if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                        color_rgb_activebackground[1] = 0
                    else:
                        color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

                    if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                        color_rgb_activebackground[2] = 0
                    else:
                        color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

                    activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])


                    text['bg'] = bg_color
                    text['fg'] = fg_color
                    text['font'] = (font_, font_size+5, 'bold')

                    framebtns['bg'] = bg_color

                root = DialogWinCustom(self.root1.content)
                root.title('Создать новый файл')

                text = Label(root.content, text='Выберите тип файла')
                text.pack(anchor=NW)


                framebtns = Frame(root.content)
                framebtns.pack(fill=X, expand=1, anchor=NW)

                def TXT(e=''):
                    if self.view_state == 1:
                        self.view.destroy()
                    self.view = TextView(self.root, file='@new', root=self.root1)
                    self.view_state = 1
                    self.file = f"@new{list_ext_text[0]}"

                    root.content.after_cancel(self.theme_aft2)
                    root.destroy()

                LabelButtonSystem(framebtns, text=' Текстовый файл ', command=TXT).pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

                def IMG(e=''):
                    if self.view_state == 1:
                        self.view.destroy()
                    self.view = ImageView(self.root, file='@new', root=self.root1)
                    self.view_state = 1
                    self.file = f"@new{list_ext_img[0]}"

                    root.content.after_cancel(self.theme_aft2)
                    root.destroy()

                LabelButtonSystem(framebtns, text=' Изображение ', command=IMG).pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

                def close():
                    root.content.after_cancel(self.theme_aft2)
                    root.destroy()

                LabelButtonSystem(framebtns, text=(' '+'Отмена'+' '), command=close).pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

                theme_upd()

            if self.view != '':
                if self.view.get_file_save():
                    def OK(e=''):
                        save_file()
                        WIN.destroy()
                        NewFile()
                    def CLOSE(e=''):
                        NewFile()
                    if os.path.splitext(self.file)[0] == '@new':
                        WIN = WhatDialogWin(self.root1.content, title='Создать новый файл', text=f"Сохранить файл?", textyes="Да", textno='Нет', command=OK, commandclose=CLOSE, type='warning')
                    else:
                        WIN = WhatDialogWin(self.root1.content, title='Создать новый файл', text=f"Сохранить файл {os.path.split(self.file)[1]}?", textyes="Да", textno='Нет', command=OK, commandclose=CLOSE, type='warning')
                else:
                    NewFile()
            else:
                NewFile()
        class TextView():
            def destroy(self):
                self.main.after_cancel(self.theme_after)
                self.saveas.destroy()
                if self.file != '@new':self.save_.destroy()
                self.main.destroy()
            def get(self):
                return self.main_text.get(0.0, END)
            def get_file_save(self):
                return self.file_save
            def set_file_save(self, num=0):
                self.file_save = 0
                if self.file_save:
                    self.root.title2((f"Просмотр - *{os.path.split(self.file)[1]}*"))
                else:
                    self.root.title2((f"Просмотр - {os.path.split(self.file)[1]}"))
            def __init__(self, master, file, root, file_save=self.file_save, menubar=self.menubar, save_file=save_file, saveas_file=saveas_file):
                self.file_save = 0
                self.menubar = menubar
                def theme_update():
                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)
                    self.theme_after = self.main.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())

                    color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                        color_rgb_activebackground[0] = 0
                    else:
                        color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

                    if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                        color_rgb_activebackground[1] = 0
                    else:
                        color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

                    if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                        color_rgb_activebackground[2] = 0
                    else:
                        color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

                    activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

                    self.main_text['bg'] = bg_color
                    self.main_text['fg'] = fg_color
                    self.main_text['font'] = (font_, font_size)
                    self.main_text['selectbackground'] = selectbg
                    self.main_text['insertbackground'] = fg_color
                    self.main_text['highlightbackground'] = bg_color

                    self.scrollbar1.configure(fg_color=bg_color)
                    self.scrollbar1.configure(button_color=bg_color)
                    self.scrollbar1.configure(button_hover_color=selectbg)


                    self.main['bg'] = bg_color

                    self.bg_ = bg_color
                    self.fg_ = fg_color
                    self.font_ = font_
                    self.font_size = font_size

                    self.selectbg_ = selectbg

                def GlobalUpdate():
                    self.global_after = self.main.after(100, GlobalUpdate)
                    if self.file == '@new':
                        f_r = ''
                        text_get = list(self.main_text.get(0.0, END))
                        if text_get[-1] == '\n':
                            text_get.pop(-1)
                        text_get = ''.join(text_get)
                        text_get = ''.join(text_get)
                        if f_r == text_get:
                            self.root.title2(f"Просмотр - Новый")
                            self.file_save = 0
                        else:
                            self.root.title2(f"Просмотр - *Новый*")
                            self.file_save = 1
                    else:
                        if os.path.isfile(self.file):
                            with open(self.file, 'r', encoding='utf-8') as f:
                                f_r = f.read()
                                text_get = list(self.main_text.get(0.0, END))
                                if text_get[-1] == '\n':
                                    text_get.pop(-1)
                                text_get = ''.join(text_get)
                                if f_r == text_get:
                                    self.root.title2(f"Просмотр - {os.path.split(self.file)[1]}")
                                    self.file_save = 0
                                else:
                                    self.root.title2(f"Просмотр - *{os.path.split(self.file)[1]}*")
                                    self.file_save = 1
                        else:
                            self.root.title2(f"Просмотр - *{os.path.split(self.file)[1]}*")
                            self.file_save = 1
                self.master = master
                self.file = file
                self.root = root

                self.ClipBoard = ''

                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CLIP_BOARDS','clip_board.txt'), 'r', encoding='utf-8') as f:
                    self.ClipBoard = f.read()

                self.main = Frame(self.master)
                self.main.pack(fill=BOTH, expand=1)

                if self.file == '@new':
                    self.root.title2(f"Просмотр - Новый")
                else:
                    self.root.title2(f"Просмотр - {os.path.split(self.file)[1]}")

                self.main_text = Text(self.main, insertwidth=3, cursor="@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/IBeam.cur", wrap='word', relief='flat', highlightthickness=0)
                self.main_text.pack(fill=BOTH, expand=1, side=LEFT)

                self.scrollbar1 = CTkScrollbar(self.main, command=self.main_text.yview)
                self.scrollbar1.pack(side=LEFT, fill=Y)

                self.main_text['yscrollcommand'] = self.scrollbar1.set

                def copy_text(e=''):
                    if self.main_text.tag_ranges("sel"):
                        selection_from = self.main_text.index("sel.first")
                        selection_to = self.main_text.index("sel.last")
                        text = self.main_text.get(selection_from, selection_to)
                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CLIP_BOARDS','clip_board.txt'), 'w', encoding='utf-8') as f:
                            f.write(text)

                def copy_delete_text(e=''):
                    if self.main_text.tag_ranges("sel"):
                        selection_from = self.main_text.index("sel.first")
                        selection_to = self.main_text.index("sel.last")
                        text = self.main_text.get(selection_from, selection_to)
                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CLIP_BOARDS','clip_board.txt'), 'w', encoding='utf-8') as f:
                            f.write(text)
                        self.main_text.delete(selection_from, selection_to)

                def delete_text(e=''):
                    if self.main_text.tag_ranges("sel"):
                        selection_from = self.main_text.index("sel.first")
                        selection_to = self.main_text.index("sel.last")
                        self.main_text.delete(selection_from, selection_to)

                def paste_text(e=None):
                    def paste__():
                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CLIP_BOARDS','clip_board.txt'), 'r', encoding='utf-8') as f:
                            self.ClipBoard = f.read()
                        if self.ClipBoard != '':
                            if self.main_text.tag_ranges("sel"):
                                selection_from = self.main_text.index("sel.first")
                                selection_to = self.main_text.index("sel.last")
                                self.main_text.delete(selection_from, selection_to)
                                self.main_text.insert(float(selection_from), str(self.ClipBoard))
                                self.main_text.yview(selection_from)
                            else:
                                self.main_text.insert('insert', str(self.ClipBoard))
                                self.main_text.yview('insert')
                    paste__()

                def context_menu(e=''):
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CLIP_BOARDS','clip_board.txt'), 'r', encoding='utf-8') as f:
                        self.ClipBoard = f.read()

                    menu = Menu(background=self.bg_, foreground=self.fg_, relief='flat', cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur", tearoff=0, bd=0, font=(self.font_, self.font_size), activebackground=self.selectbg_, activeforeground=self.fg_)

                    if self.main_text.tag_ranges("sel"):
                        menu.add_command(label='Копировать', command=copy_text)
                    if self.ClipBoard != '':
                        menu.add_command(label='Вставить', command=paste_text)
                    if self.main_text.tag_ranges("sel"):
                        menu.add_command(label='Вырезать', command=copy_delete_text)
                        menu.add_separator()
                        menu.add_command(label='Удалить', command=delete_text)

                    menu.post(x=e.x_root, y=e.y_root)

                self.main_text.bind('<Button-2>', context_menu)
                self.main_text.bind('<Button-3>', context_menu)
                self.main_text.bind('<Control-Button-1>', context_menu)

                self.main_text.bind('<Control-v>', paste_text)
                self.main_text.bind('<Control-c>', copy_text)
                self.main_text.bind('<Control-x>', copy_delete_text)
                if self.file != '@new':self.root.bind('<Control-s>', save_file)
                if self.file == '@new':self.root.bind('<Control-s>', saveas_file)
                self.root.bind('<Control-a>', saveas_file)

                if self.file != '@new':
                    with open(self.file, 'r', encoding='utf-8') as f:
                        self.main_text.insert(END, f.read())

                if self.file != '@new':self.save_ = MenuBtn(self.menubar, text='Сохранить', command=save_file)
                self.saveas = MenuBtn(self.menubar, text='Сохранить как', command=saveas_file)

                theme_update()
                GlobalUpdate()

        class ImageView():
            def destroy(self):
                self.main.after_cancel(self.theme_after)
                self.saveas.destroy()
                self.settings.destroy()
                if self.file != '@new':self.save_.destroy()
                self.main.destroy()
            def get(self):
                return self.image1
            def get_file_save(self):
                return self.file_save
            def set_file_save(self, num=0):
                self.file_save = 0
                if self.file_save:
                    self.root.title2((f"Просмотр - *{os.path.split(self.file)[1]}*"))
                else:
                    self.root.title2((f"Просмотр - {os.path.split(self.file)[1]}"))
            def __init__(self, master, file, root, file_save=self.file_save, menubar=self.menubar, save_file=save_file, saveas_file=saveas_file, size=(750, 500), color=''):
                self.file_save = 0
                self.menubar = menubar
                def theme_update():
                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)
                    self.theme_after = self.main.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())

                    color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_activebackground[0] == 255 or color_rgb_activebackground[0] >= 250:
                        color_rgb_activebackground[0] = 250
                    else:
                        color_rgb_activebackground[0] = color_rgb_activebackground[0]+25

                    if color_rgb_activebackground[1] == 255 or color_rgb_activebackground[1] >= 250:
                        color_rgb_activebackground[1] = 250
                    else:
                        color_rgb_activebackground[1] = color_rgb_activebackground[1]+25

                    if color_rgb_activebackground[2] == 255 or color_rgb_activebackground[2] >= 250:
                        color_rgb_activebackground[2] = 250
                    else:
                        color_rgb_activebackground[2] = color_rgb_activebackground[2]+25

                    activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])



                    self.main['bg'] = bg_color


                    self.scrollbar1.configure(fg_color=bg_color)
                    self.scrollbar1.configure(button_color=selectbg)
                    self.scrollbar1.configure(button_hover_color=activebackground)

                    self.scrollbar2.configure(fg_color=bg_color)
                    self.scrollbar2.configure(button_color=selectbg)
                    self.scrollbar2.configure(button_hover_color=activebackground)

                    self.scroll_frame['bg'] = bg_color
                    self.scroll_frame['highlightbackground'] = bg_color
                    imgframe['bg'] = bg_color
                    frame['bg'] = bg_color

                    if color == '':
                        image2['bg'] = selectbg
                        image2['highlightbackground'] = selectbg
                    else:
                        image2['bg'] = color
                        image2['highlightbackground'] = color

                self.master = master
                self.file = file
                self.root = root

                self.brush_size = 3
                self.color = '#000000'

                if self.file == '@new':
                    sizeimg = size
                else:
                    img = Image.open(self.file)
                    sizeimg = img.size
                if self.file == '@new':
                    if color == '':
                        self.image1 = Image.new('RGBA', (sizeimg[0], sizeimg[1]), (255,255,255,0))
                        draw_img = ImageDraw.Draw(self.image1)
                    else:
                        self.image1 = Image.new('RGB', (sizeimg[0], sizeimg[1]), (255, 255, 255))
                        draw_img = ImageDraw.Draw(self.image1)
                        draw_img.rectangle((0, 0, sizeimg[0], sizeimg[1]), fill=color)
                else:
                    if os.path.splitext(file)[1].lower() == '.jpg' or os.path.splitext(file)[1].lower() == '.jpeg':
                        self.image1 = Image.new('RGB', (sizeimg[0], sizeimg[1]), (255, 255, 255))
                        self.image1.paste(img)
                        draw_img = ImageDraw.Draw(self.image1)
                    else:
                        self.image1 = Image.new('RGBA', (sizeimg[0], sizeimg[1]), (255,255,255,0))
                        self.image1.paste(img)
                        draw_img = ImageDraw.Draw(self.image1)
                #img = img.resize((1920, 1010), Image.ANTIALIAS)
                self.main = Frame(self.master)
                self.main.pack(expand=1, fill=BOTH)

                if self.file == '@new':
                    self.root.title2(f"Просмотр - Новый")
                else:
                    self.root.title2(f"Просмотр - {os.path.split(self.file)[1]}")

                imgframe = Frame(self.main, width=sizeimg[0], height=sizeimg[1])
                imgframe.pack(expand=1, fill=BOTH)
                if self.file != '@new':imgframe.image = ImageTk.PhotoImage(img)
                self.scroll_frame = Canvas(imgframe, scrollregion=(0, 0, sizeimg[0], sizeimg[1]), highlightthickness=0, width=sizeimg[0])
                #self.scroll_frame.pack(expand=1, side=TOP, anchor=NW, fill=Y)

                self.scrollbar1 = CTkScrollbar(imgframe, command=self.scroll_frame.yview)
                self.scrollbar1.pack(fill=Y, side=RIGHT)

                self.scroll_frame.pack(expand=1, side=TOP, anchor=NW, fill=Y)
                frame = Frame(self.scroll_frame, width=sizeimg[0], height=sizeimg[1])
                image2 = Canvas(frame, bg='white', highlightthickness=0, highlightbackground='white', cursor="@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Handwriting.cur", width=sizeimg[0], height=sizeimg[1])
                if self.file != '@new':image2.create_image(0, 0, anchor=NW, image=imgframe.image)

                self.scrollbar2 = CTkScrollbar(imgframe, command=self.scroll_frame.xview, orientation='horizontal')
                self.scrollbar2.pack(fill=X, side=BOTTOM)

                self.scroll_frame['yscrollcommand'] = self.scrollbar1.set
                self.scroll_frame['xscrollcommand'] = self.scrollbar2.set
                lastx = None
                lasty = None
                def drawPress(event):
                    global lastx, lasty
                    lastx = event.x
                    lasty = event.y
                def draw(event):
                    global lastx, lasty, g
                    g = 1
                    x1, y1 = (lastx - self.brush_size), (lasty - self.brush_size)
                    x2, y2 = (lastx + self.brush_size), (lasty + self.brush_size)
                    image2.create_line((lastx, lasty,event.x, event.y), fill=self.color, width=self.brush_size)
                    draw_img.line((lastx, lasty,event.x, event.y), fill=self.color, width=self.brush_size)
                    #draw_img.line((lastx, lasty,event.x, event.y), fill=color, width=brush_size)
                    lastx = event.x
                    lasty = event.y

                    if self.file == '@new':
                        self.root.title2(f"Просмотр - *Новый*")
                    else:
                        self.root.title2(f"Просмотр - *{os.path.split(self.file)[1]}*")
                    self.file_save = 1
                if self.file != '@new':img2 = ImageTk.PhotoImage(img)
                image2.pack(anchor=NW)
                self.scroll_frame.create_window(0, 0, anchor=NW, window=frame, width=sizeimg[0], height=sizeimg[1])
                image2.bind('<B1-Motion>', draw)
                image2.bind('<ButtonPress-1>', drawPress)
                if self.file != '@new':self.root.bind('<Control-s>', save_file)
                if self.file == '@new':self.root.bind('<Control-s>', saveas_file)
                self.root.bind('<Control-a>', saveas_file)

                if self.file != '@new':self.save_ = MenuBtn(self.menubar, text='Сохранить', command=save_file)
                self.saveas = MenuBtn(self.menubar, text='Сохранить как', command=saveas_file)
                def settings_brush(e=''):
                    self.color_bg_set = self.color
                    self.brush_size_set = self.brush_size
                    _root = DialogWinCustom(self.main)
                    _root.title('Настройки кисти')


                    def theme_upd():
                        def get_hex(r, g, b):
                            return '#{:02x}{:02x}{:02x}'.format(r, g, b)
                        self.theme_aft = frame_content.after(10000, theme_upd)

                        bg_color = ''
                        fg_color = ''
                        font_ = ''
                        font_size = 0

                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                            bg_color = bg.read()
                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                            fg_color = fg.read()
                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                            font_ = f.read()
                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                            font_size = int(fs.read())

                        frame_content['bg'] = bg_color
                        framebtns['bg'] = bg_color

                        color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

                        if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                            color_rgb_activebackground[0] = 0
                        else:
                            color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

                        if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                            color_rgb_activebackground[1] = 0
                        else:
                            color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

                        if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                            color_rgb_activebackground[2] = 0
                        else:
                            color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

                        activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


                        color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                        if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                            color_rgb_select[0] = 250
                        else:
                            color_rgb_select[0] = color_rgb_select[0]+10

                        if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                            color_rgb_select[1] = 250
                        else:
                            color_rgb_select[1] = color_rgb_select[1]+10

                        if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                            color_rgb_select[2] = 250
                        else:
                            color_rgb_select[2] = color_rgb_select[2]+10

                        selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])


                        scalebrushsize.configure(fg_color=selectbg)
                        scalebrushsize.configure(progress_color=activebackground)
                        scalebrushsize.configure(button_color=activebackground)
                        scalebrushsize.configure(button_hover_color=selectbg)

                        lab1['bg'] = bg_color
                        lab1['fg'] = fg_color
                        lab1['font'] = (font_, font_size+5, 'bold')

                        lab2['bg'] = bg_color
                        lab2['fg'] = fg_color
                        lab2['font'] = (font_, font_size)

                        lab3['bg'] = bg_color
                        lab3['fg'] = fg_color
                        lab3['font'] = (font_, font_size+5, 'bold')

                    frame_content = Frame(_root.content)
                    frame_content.pack(fill=BOTH)

                    lab1 = Label(frame_content, text='Размер кисти')
                    lab1.pack(anchor=NW)

                    def brush_size_set(e=''):
                        self.brush_size_set = int(scalebrushsize.get())
                        lab2['text'] = int(scalebrushsize.get())

                    lab2 = Label(frame_content, text=self.brush_size_set)
                    lab2.pack(anchor=NW, padx=10, pady=5)

                    scalebrushsize = CTkSlider(frame_content, from_=1, to=100, command=brush_size_set)
                    scalebrushsize.pack(expand=1, padx=10, pady=5, fill=X)
                    scalebrushsize.set(self.brush_size_set)

                    Separator(frame_content, orient='horizontal')

                    lab3 = Label(frame_content, text='Цвет кисти')
                    lab3.pack(anchor=NW)

                    frame_bg = Frame(frame_content, bg='#9e9e9e')
                    frame_bg.pack(expand=1, padx=10, pady=5, fill=X)

                    lab_bg = Label(frame_bg, width=5, font=('Montserrat', 15), bg=self.color_bg_set)
                    lab_bg.pack(side=LEFT, expand=1, padx=2, pady=2, fill=X)

                    def color_bg_set():
                        def Okay(e=''):
                            COLOR = WIN.getcolorhex()

                            self.color_bg_set = COLOR

                            lab_bg['bg'] = COLOR

                            WIN.destroy()
                        WIN = ColorDialogWin(frame_content, title='Выбрать цвет кисти', command=Okay, color=self.color_bg_set)

                    LabelButtonSystem(frame_content, text='Выбрать цвет', command=color_bg_set).pack(fill=X, expand=1, padx=10, pady=5)

                    framebtns = Frame(frame_content)
                    framebtns.pack(side=BOTTOM, fill=X, expand=1, anchor=NW)

                    def OK(e=''):

                        self.color = self.color_bg_set
                        self.brush_size = self.brush_size_set

                        frame_content.after_cancel(self.theme_aft)
                        _root.destroy()

                    LabelButtonSystem(framebtns, text=' OK ', command=OK).pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

                    def close():
                        frame_content.after_cancel(self.theme_aft)
                        _root.destroy()

                    LabelButtonSystem(framebtns, text=(' '+'Отмена'+' '), command=close).pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

                    theme_upd()

                self.settings = MenuBtn(self.menubar, text='Настройки кисти', command=settings_brush)

                theme_update()

        MenuBtn(self.menubar, text='Открыть', command=open_file)
        MenuBtn(self.menubar, text='Новый', command=new_file)

        if os.path.splitext(fileopen)[1].lower() in list_ext_text:
            self.view = TextView(self.root, file=fileopen, root=self.root1)
            self.view_state = 1
            self.file = fileopen
        elif os.path.splitext(fileopen)[1].lower() in list_ext_img:
            try:
                Image.open(fileopen)
                self.view = ImageView(self.root, file=fileopen, root=self.root1)
                self.view_state = 1
                self.file = fileopen
            except:
                DialogWin(self.root, title='Ошибка', type='error', text='Данное изображение поврежено')

        self.root1.bind('<Control-o>', open_file)
        self.root1.bind('<Control-n>', new_file)





        theme_update()
App()
