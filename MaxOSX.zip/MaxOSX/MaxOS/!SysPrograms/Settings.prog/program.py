from MaxOSTkinter import (
                            MaxOSTk,
                            DialogWin,
                            WhatDialogWin,
                            LabelButtonSystem,
                            ListButton,
                            Separator,
                            empty,
                            ColorDialogWin,
                            MaxOSTk2,
                            BUTTON_MENU,
                            DialogWinCustom,
                            ThemeButtons,
                            FileDialogWin
                        )
from tkinter import (
                        Frame,
                        Label,
                        Toplevel,
                        BOTH,
                        Y,
                        X,
                        NW,
                        N,
                        SW,
                        S,
                        W,
                        E,
                        NE,
                        LEFT,
                        RIGHT,
                        TOP,
                        BOTTOM,
                        Menu,
                        font,
                        Text,
                        END
                    )
import os
import sys
import shutil
from pathlib import Path
from threading import Thread
from customtkinter import CTkLabel, CTkFrame, CTkComboBox, CTkSlider, CTkScrollableFrame
from PIL import Image, ImageTk, ImageColor, ImageChops
import psutil
import sys

class App():
    def __init__(self):
        def theme_update():
            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)
            self.theme_after = self.root1.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())

            color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                color_rgb_activebackground[0] = 0
            else:
                color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

            if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                color_rgb_activebackground[1] = 0
            else:
                color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

            if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                color_rgb_activebackground[2] = 0
            else:
                color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

            activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])


            self.frameleft.configure(fg_color=bg_color)
            self.frameleft.configure(scrollbar_fg_color=bg_color)
            self.frameleft.configure(scrollbar_button_color=bg_color)
            self.frameleft.configure(scrollbar_button_hover_color=selectbg)

            self.frameright.configure(fg_color=bg_color)
            self.frameright.configure(scrollbar_fg_color=bg_color)
            self.frameright.configure(scrollbar_button_color=bg_color)
            self.frameright.configure(scrollbar_button_hover_color=selectbg)

        def exitapp():
            self.root1.after_cancel(self.theme_after)
            self.root1.ExitDestroy()
        self.registry_path = ''
        with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','registry_path.txt'), 'r', encoding='utf-8') as hf:
            self.registry_path = hf.read()
        self.homefolder_path = ''
        with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'r', encoding='utf-8') as hf:
            self.homefolder_path = hf.read()
        if sys.platform == 'win32':self.root1 = MaxOSTk2(exitfunc=exitapp, icon=Path(cwd, 'icon.png'))
        elif sys.platform == 'darwin':self.root1 = MaxOSTk(exitfunc=exitapp, icon=Path(cwd, 'icon.png'))
        self.root1.title2('Настройки')
        self.root1.geometry('1000x750')
        self.root1.minsize(1000, 750)
        self.root = self.root1.content
        self.frameleft = CTkScrollableFrame(self.root, width=275, corner_radius=0)
        self.frameleft.pack(fill=Y, side=LEFT)
        self.settings_pers_state = 0
        self.settings_info_state = 0
        self.settings_user_state = 0
        self.settings_pers = ''
        self.settings_info = ''
        self.settings_user = ''
        self.icontheme_position = 0

        class settings_pers():
            def destroy(self):
                self.content.after_cancel(self.theme_after)
                self.content.after_cancel(self.global_after)
                self.content.destroy()
            def __init__(self, master, registry_path, homefolder):
                self.registry_path = registry_path
                self.homefolder_path = homefolder
                self.font_list = sorted(list(font.families()))

                def theme_update():
                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)
                    self.theme_after = self.content.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())

                    self.content['bg'] = bg_color

                    self.lab0['bg'] = bg_color
                    self.lab0['fg'] = fg_color
                    self.lab0['font'] = (font_, font_size+15, 'bold')

                    self.lab1['bg'] = bg_color
                    self.lab1['fg'] = fg_color
                    self.lab1['font'] = (font_, font_size+10, 'bold')

                    self.lab3['bg'] = bg_color
                    self.lab3['fg'] = fg_color
                    self.lab3['font'] = (font_, font_size+10, 'bold')

                    self.lab4['bg'] = bg_color
                    self.lab4['fg'] = fg_color
                    self.lab4['font'] = (font_, font_size+10, 'bold')

                    self.lab5['bg'] = bg_color
                    self.lab5['fg'] = fg_color
                    self.lab5['font'] = (font_, font_size+10, 'bold')

                    self.labfontsize['bg'] = bg_color
                    self.labfontsize['fg'] = fg_color
                    self.labfontsize['font'] = (font_, font_size)

                    self.frameconfigtb['bg'] = bg_color
                    self.tbconfigbtndown['bg'] = bg_color
                    self.tbconfigbtnup['bg'] = bg_color

                    self.comboboxfont.configure(fg_color=bg_color)
                    self.comboboxfont.configure(border_color='#9e9e9e')
                    self.comboboxfont.configure(button_color='#9e9e9e')

                    color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                        color_rgb_activebackground[0] = 0
                    else:
                        color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

                    if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                        color_rgb_activebackground[1] = 0
                    else:
                        color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

                    if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                        color_rgb_activebackground[2] = 0
                    else:
                        color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

                    activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

                    self.comboboxfont.configure(button_hover_color=selectbg)
                    self.comboboxfont.configure(dropdown_fg_color=bg_color)
                    self.comboboxfont.configure(dropdown_hover_color=selectbg)
                    self.comboboxfont.configure(dropdown_text_color=fg_color)
                    self.comboboxfont.configure(text_color=fg_color)
                    self.comboboxfont.configure(font=(font_, font_size))
                    self.comboboxfont.configure(dropdown_font=(font_, font_size))

                    self.scalefontsize.configure(fg_color=selectbg)
                    self.scalefontsize.configure(progress_color=activebackground)
                    self.scalefontsize.configure(button_color=activebackground)
                    self.scalefontsize.configure(button_hover_color=selectbg)

                    self.icontheme1['bg'] = selectbg
                    self.icontheme2['bg'] = selectbg
                    self.icontheme3['bg'] = selectbg
                    self.icontheme4['bg'] = selectbg

                    self.frame_iconsdesktop.configure(fg_color=bg_color)
                    self.frame_iconsdesktop.configure(scrollbar_fg_color=bg_color)
                    self.frame_iconsdesktop.configure(scrollbar_button_color=bg_color)
                    self.frame_iconsdesktop.configure(scrollbar_button_hover_color=selectbg)

                    self.icondesktop1['bg'] = bg_color
                    self.icondesktop2['bg'] = bg_color
                    self.icondesktop3['bg'] = bg_color
                    self.icondesktop4['bg'] = bg_color



                def GlobalUpdate():
                    self.global_after = self.content.after(100, GlobalUpdate)
                    with open(Path(self.registry_path,'SAVING','TASKBAR_CONFIG','tb_config.txt'), 'r', encoding='utf-8') as tbcnf:
                        text = tbcnf.read().lower()
                        if text == 'top':
                            self.ACTIVE_UP_TB_STATE = 1
                            self.ACTIVE_DOWN_TB_STATE = 0
                            if self.HOVER_UP_TB_STATE != 1:
                                self.tbconfigupimg = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','TOP_TB_BTN','active.png'))
                                self.tbconfigupimg = self.tbconfigupimg.resize((175, 118), Image.ANTIALIAS)
                                self.tbconfigupimg = ImageTk.PhotoImage(self.tbconfigupimg)
                                self.tbconfigbtnup.image = self.tbconfigupimg
                                self.tbconfigbtnup['image'] = self.tbconfigbtnup.image
                            if self.HOVER_DOWN_TB_STATE != 1:
                                self.tbconfigdownimg = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','BOTTOM_TB_BTN','normal.png'))
                                self.tbconfigdownimg = self.tbconfigdownimg.resize((175, 118), Image.ANTIALIAS)
                                self.tbconfigdownimg = ImageTk.PhotoImage(self.tbconfigdownimg)
                                self.tbconfigbtndown.image = self.tbconfigdownimg
                                self.tbconfigbtndown['image'] = self.tbconfigbtndown.image
                        if text == 'bottom':
                            self.ACTIVE_UP_TB_STATE = 0
                            self.ACTIVE_DOWN_TB_STATE = 1
                            if self.HOVER_UP_TB_STATE != 1:
                                self.tbconfigupimg = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','TOP_TB_BTN','normal.png'))
                                self.tbconfigupimg = self.tbconfigupimg.resize((175, 118), Image.ANTIALIAS)
                                self.tbconfigupimg = ImageTk.PhotoImage(self.tbconfigupimg)
                                self.tbconfigbtnup.image = self.tbconfigupimg
                                self.tbconfigbtnup['image'] = self.tbconfigbtnup.image
                            if self.HOVER_DOWN_TB_STATE != 1:
                                self.tbconfigdownimg = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','BOTTOM_TB_BTN','active.png'))
                                self.tbconfigdownimg = self.tbconfigdownimg.resize((175, 118), Image.ANTIALIAS)
                                self.tbconfigdownimg = ImageTk.PhotoImage(self.tbconfigdownimg)
                                self.tbconfigbtndown.image = self.tbconfigdownimg
                                self.tbconfigbtndown['image'] = self.tbconfigbtndown.image

                    """
                    with open(Path(self.registry_path,'SAVING','SYSTEM_THEME','change_theme.txt'), 'r', encoding='utf-8') as ct:
                        true = ct.read()
                        if true.lower() == 'true':
                            with open(Path(self.registry_path,'SAVING','SYSTEM_THEME','COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg_:
                                with open(Path(self.registry_path,'SAVING','SYSTEM_THEME','COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg_:
                                    bg_r = bg_.read()
                                    fg_r = fg_.read()
                                    if bg_r == '#333533' and fg_r == '#ffffff':
                                        self.icontheme_position = 0
                                        self.icontheme4.pack_forget()
                                    elif bg_r == '#effbff' and fg_r == '#000000':
                                        self.icontheme_position = 1
                                        self.icontheme4.pack_forget()
                                    elif bg_r == '#28749b' and fg_r == '#ffffff':
                                        self.icontheme_position = 2
                                        self.icontheme4.pack_forget()
                                    else:
                                        def color_img(img, color):
                                            img = Image.open(img)
                                            pixdata = img.load()
                                            r, g, b, = ImageColor.getcolor(color, "RGB")
                                            for y in range(img.size[1]):
                                                for x in range(img.size[0]):
                                                    alpha = pixdata[x, y][3]
                                                    if alpha:
                                                        pixdata[x, y] = (r, g, b, alpha)
                                            return img

                                        self.custom_user_icontheme = color_img(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','window.png'), color=bg_r)
                                        self.custom_user_icontheme.paste(color_img(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','title.png'), color=fg_r), (0,0), color_img(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','title.png'), color=self.fg_color))
                                        self.custom_user_icontheme.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','icon.png')), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','icon.png')))

                                        self.icontheme4.pack(side=LEFT)
                                        self.plus2.delete()
                                        self.plus2.pack(side=LEFT)
                                        self.icontheme_position = 3
                            check_position_icontheme()
                            """
                self.master = master

                self.icontheme_position = 0
                self.user_icontheme = ("#333533", "#ffffff")
                self.bg_color, self.fg_color = "#333533", "#ffffff"

                self.content = Frame(self.master)
                self.content.pack(fill=BOTH, expand=1)

                self.lab0 = Label(self.content, text='Персонализация')
                self.lab0.pack(anchor=NW, padx=5, pady=5)

                Separator(self.content, orient='horizontal')

                self.lab1 = Label(self.content, text='Тема')
                self.lab1.pack(anchor=NW, padx=5, pady=5)

                self.frametheme = Frame(self.content)
                self.frametheme.pack(anchor=NW)



                self.custom_user_icontheme = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','window.png'))

                def check_position_icontheme():
                    if self.icontheme_position == 0:
                        self.user_icontheme = ("#333533", "#ffffff")

                        self.icontheme1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','DARK_THEME','normal.png'))
                        self.icontheme1_ = self.icontheme1_.resize((100, 100), Image.ANTIALIAS)
                        self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme1_ = ImageTk.PhotoImage(self.icontheme1_)
                        self.icontheme1.image = self.icontheme1_
                        self.icontheme1['image'] = self.icontheme1.image
                        self.ACTIVE_icontheme1_STATE = 1


                        self.icontheme2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','LIGHT_THEME','normal.png'))
                        self.icontheme2_ = self.icontheme2_.resize((100, 100), Image.ANTIALIAS)
                        #self.icontheme2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme2_ = ImageTk.PhotoImage(self.icontheme2_)
                        self.icontheme2.image = self.icontheme2_
                        self.icontheme2['image'] = self.icontheme2.image
                        self.ACTIVE_icontheme2_STATE = 0

                        self.icontheme3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','MAXOSXBLUE_THEME','normal.png'))
                        self.icontheme3_ = self.icontheme3_.resize((100, 100), Image.ANTIALIAS)
                        #self.icontheme3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme3_ = ImageTk.PhotoImage(self.icontheme3_)
                        self.icontheme3.image = self.icontheme3_
                        self.icontheme3['image'] = self.icontheme3.image
                        self.ACTIVE_icontheme3_STATE = 0


                        self.icontheme4_ = self.custom_user_icontheme
                        self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
                        #self.icontheme3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)
                        self.icontheme4.image = self.icontheme4_
                        self.icontheme4['image'] = self.icontheme4.image
                        self.ACTIVE_icontheme4_STATE = 0
                    elif self.icontheme_position == 1:
                        self.user_icontheme = ("#effbff", "#000000")

                        self.icontheme1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','DARK_THEME','normal.png'))
                        self.icontheme1_ = self.icontheme1_.resize((100, 100), Image.ANTIALIAS)
                        #self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme1_ = ImageTk.PhotoImage(self.icontheme1_)
                        self.icontheme1.image = self.icontheme1_
                        self.icontheme1['image'] = self.icontheme1.image
                        self.ACTIVE_icontheme1_STATE = 0


                        self.icontheme2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','LIGHT_THEME','normal.png'))
                        self.icontheme2_ = self.icontheme2_.resize((100, 100), Image.ANTIALIAS)
                        self.icontheme2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme2_ = ImageTk.PhotoImage(self.icontheme2_)
                        self.icontheme2.image = self.icontheme2_
                        self.icontheme2['image'] = self.icontheme2.image
                        self.ACTIVE_icontheme2_STATE = 1


                        self.icontheme3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','MAXOSXBLUE_THEME','normal.png'))
                        self.icontheme3_ = self.icontheme3_.resize((100, 100), Image.ANTIALIAS)
                        #self.icontheme3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme3_ = ImageTk.PhotoImage(self.icontheme3_)
                        self.icontheme3.image = self.icontheme3_
                        self.icontheme3['image'] = self.icontheme3.image
                        self.ACTIVE_icontheme3_STATE = 0


                        self.icontheme4_ = self.custom_user_icontheme
                        self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
                        #self.icontheme3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)
                        self.icontheme4.image = self.icontheme4_
                        self.icontheme4['image'] = self.icontheme4.image
                        self.ACTIVE_icontheme4_STATE = 0
                    elif self.icontheme_position == 2:
                        self.user_icontheme = ("#28749b", "#ffffff")

                        self.icontheme1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','DARK_THEME','normal.png'))
                        self.icontheme1_ = self.icontheme1_.resize((100, 100), Image.ANTIALIAS)
                        #self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme1_ = ImageTk.PhotoImage(self.icontheme1_)
                        self.icontheme1.image = self.icontheme1_
                        self.icontheme1['image'] = self.icontheme1.image
                        self.ACTIVE_icontheme1_STATE = 0


                        self.icontheme2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','LIGHT_THEME','normal.png'))
                        self.icontheme2_ = self.icontheme2_.resize((100, 100), Image.ANTIALIAS)
                        #self.icontheme2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme2_ = ImageTk.PhotoImage(self.icontheme2_)
                        self.icontheme2.image = self.icontheme2_
                        self.icontheme2['image'] = self.icontheme2.image
                        self.ACTIVE_icontheme2_STATE = 0


                        self.icontheme3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','MAXOSXBLUE_THEME','normal.png'))
                        self.icontheme3_ = self.icontheme3_.resize((100, 100), Image.ANTIALIAS)
                        self.icontheme3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme3_ = ImageTk.PhotoImage(self.icontheme3_)
                        self.icontheme3.image = self.icontheme3_
                        self.icontheme3['image'] = self.icontheme3.image
                        self.ACTIVE_icontheme3_STATE = 1


                        self.icontheme4_ = self.custom_user_icontheme
                        self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
                        #self.icontheme3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)
                        self.icontheme4.image = self.icontheme4_
                        self.icontheme4['image'] = self.icontheme4.image
                        self.ACTIVE_icontheme4_STATE = 0
                    elif self.icontheme_position == 3:
                        self.user_icontheme = (self.bg_color, self.fg_color)

                        self.icontheme1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','DARK_THEME','normal.png'))
                        self.icontheme1_ = self.icontheme1_.resize((100, 100), Image.ANTIALIAS)
                        #self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme1_ = ImageTk.PhotoImage(self.icontheme1_)
                        self.icontheme1.image = self.icontheme1_
                        self.icontheme1['image'] = self.icontheme1.image
                        self.ACTIVE_icontheme1_STATE = 0


                        self.icontheme2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','LIGHT_THEME','normal.png'))
                        self.icontheme2_ = self.icontheme2_.resize((100, 100), Image.ANTIALIAS)
                        #self.icontheme2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme2_ = ImageTk.PhotoImage(self.icontheme2_)
                        self.icontheme2.image = self.icontheme2_
                        self.icontheme2['image'] = self.icontheme2.image
                        self.ACTIVE_icontheme2_STATE = 0


                        self.icontheme3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','MAXOSXBLUE_THEME','normal.png'))
                        self.icontheme3_ = self.icontheme3_.resize((100, 100), Image.ANTIALIAS)
                        #self.icontheme3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme3_ = ImageTk.PhotoImage(self.icontheme3_)
                        self.icontheme3.image = self.icontheme3_
                        self.icontheme3['image'] = self.icontheme3.image
                        self.ACTIVE_icontheme3_STATE = 0


                        self.icontheme4_ = self.custom_user_icontheme
                        self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
                        self.icontheme4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)
                        self.icontheme4.image = self.icontheme4_
                        self.icontheme4['image'] = self.icontheme4.image
                        self.ACTIVE_icontheme4_STATE = 1

                        if os.path.isdir(Path(self.registry_path, 'SAVING','SYSTEM_THEME','CUSTOM_THEMES')):
                            name = f"{self.bg_color.replace('#', '')}_{self.fg_color.replace('#', '')}.xtheme"
                            with open(Path(self.registry_path,'SAVING','SYSTEM_THEME','CUSTOM_THEMES',name), 'w', encoding='utf-8') as f:
                                f.write(f"{self.bg_color} {self.fg_color}")
                        else:
                            os.mkdir(Path(self.registry_path, 'SAVING','SYSTEM_THEME','CUSTOM_THEMES'))
                            name = f"{self.bg_color.replace('#', '')}_{self.fg_color.replace('#', '')}.xtheme"
                            with open(Path(self.registry_path,'SAVING','SYSTEM_THEME','CUSTOM_THEMES',name), 'w', encoding='utf-8') as f:
                                f.write(f"{self.bg_color} {self.fg_color}")

                    with open(Path(self.registry_path,'SAVING','SYSTEM_THEME','COLORS','bg_tb.txt'), 'w', encoding='utf-8') as bg_:
                        bg_.write(str(self.user_icontheme[0]))
                    with open(Path(self.registry_path,'SAVING','SYSTEM_THEME','COLORS','fg_tb.txt'), 'w', encoding='utf-8') as fg_:
                        fg_.write(str(self.user_icontheme[1]))
                    with open(Path(self.registry_path,'SAVING','SYSTEM_THEME','change_theme.txt'), 'w', encoding='utf-8') as f:
                        f.write(str('True'))


                def _icontheme1_():
                    self.icontheme1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','DARK_THEME','normal.png'))
                    self.icontheme1_ = self.icontheme1_.resize((100, 100), Image.ANTIALIAS)
                    self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                    self.icontheme1_ = ImageTk.PhotoImage(self.icontheme1_)
                    self.HOVER_icontheme1_STATE = 0
                    self.ACTIVE_icontheme1_STATE = 1
                    def hover_up_tb(e=''):
                        self.icontheme1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','DARK_THEME','normal.png'))
                        self.icontheme1_ = self.icontheme1_.resize((100, 100), Image.ANTIALIAS)
                        self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme1_ = ImageTk.PhotoImage(self.icontheme1_)

                        self.icontheme1.image = self.icontheme1_
                        self.icontheme1['image'] = self.icontheme1.image
                        self.HOVER_icontheme1_STATE = 1
                    def unhover_up_tb(e=''):
                        if self.ACTIVE_icontheme1_STATE:
                            self.icontheme1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','DARK_THEME','normal.png'))
                            self.icontheme1_ = self.icontheme1_.resize((100, 100), Image.ANTIALIAS)
                            self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                            self.icontheme1_ = ImageTk.PhotoImage(self.icontheme1_)

                            self.icontheme1.image = self.icontheme1_
                            self.icontheme1['image'] = self.icontheme1.image
                        else:
                            self.icontheme1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','DARK_THEME','normal.png'))
                            self.icontheme1_ = self.icontheme1_.resize((100, 100), Image.ANTIALIAS)
                            self.icontheme1_ = ImageTk.PhotoImage(self.icontheme1_)

                            self.icontheme1.image = self.icontheme1_
                            self.icontheme1['image'] = self.icontheme1.image
                        self.HOVER_icontheme1_STATE = 0
                    self.icontheme1 = Label(self.frametheme, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
                    self.icontheme1.image = self.icontheme1_
                    self.icontheme1['image'] = self.icontheme1.image
                    self.icontheme1.bind('<Enter>', hover_up_tb)
                    self.icontheme1.bind('<Leave>', unhover_up_tb)
                    def cmd_up_tb(e=''):
                        self.ACTIVE_icontheme1_STATE = 1
                        self.icontheme_position = 0
                        check_position_icontheme()
                    self.icontheme1.bind('<Button-1>', cmd_up_tb)
                    self.icontheme1.pack(side=LEFT)

                def _icontheme2_():
                    self.icontheme2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','LIGHT_THEME','normal.png'))
                    self.icontheme2_ = self.icontheme2_.resize((100, 100), Image.ANTIALIAS)
                    #self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                    self.icontheme2_ = ImageTk.PhotoImage(self.icontheme2_)
                    self.HOVER_icontheme2_STATE = 0
                    self.ACTIVE_icontheme2_STATE = 0
                    def hover_up_tb(e=''):
                        self.icontheme2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','LIGHT_THEME','normal.png'))
                        self.icontheme2_ = self.icontheme2_.resize((100, 100), Image.ANTIALIAS)
                        self.icontheme2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme2_ = ImageTk.PhotoImage(self.icontheme2_)

                        self.icontheme2.image = self.icontheme2_
                        self.icontheme2['image'] = self.icontheme2.image
                        self.HOVER_icontheme2_STATE = 1
                    def unhover_up_tb(e=''):
                        if self.ACTIVE_icontheme2_STATE:
                            self.icontheme2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','LIGHT_THEME','normal.png'))
                            self.icontheme2_ = self.icontheme2_.resize((100, 100), Image.ANTIALIAS)
                            self.icontheme2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                            self.icontheme2_ = ImageTk.PhotoImage(self.icontheme2_)

                            self.icontheme2.image = self.icontheme2_
                            self.icontheme2['image'] = self.icontheme2.image
                        else:
                            self.icontheme2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','LIGHT_THEME','normal.png'))
                            self.icontheme2_ = self.icontheme2_.resize((100, 100), Image.ANTIALIAS)
                            self.icontheme2_ = ImageTk.PhotoImage(self.icontheme2_)

                            self.icontheme2.image = self.icontheme2_
                            self.icontheme2['image'] = self.icontheme2.image
                        self.HOVER_icontheme2_STATE = 0
                    self.icontheme2 = Label(self.frametheme, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
                    self.icontheme2.image = self.icontheme2_
                    self.icontheme2['image'] = self.icontheme2.image
                    self.icontheme2.bind('<Enter>', hover_up_tb)
                    self.icontheme2.bind('<Leave>', unhover_up_tb)
                    def cmd_up_tb(e=''):
                        self.ACTIVE_icontheme2_STATE = 1
                        self.icontheme_position = 1
                        check_position_icontheme()
                    self.icontheme2.bind('<Button-1>', cmd_up_tb)
                    self.icontheme2.pack(side=LEFT)

                def _icontheme3_():
                    self.icontheme3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','MAXOSXBLUE_THEME','normal.png'))
                    self.icontheme3_ = self.icontheme3_.resize((100, 100), Image.ANTIALIAS)
                    #self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                    self.icontheme3_ = ImageTk.PhotoImage(self.icontheme3_)
                    self.HOVER_icontheme3_STATE = 0
                    self.ACTIVE_icontheme3_STATE = 0
                    def hover_up_tb(e=''):
                        self.icontheme3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','MAXOSXBLUE_THEME','normal.png'))
                        self.icontheme3_ = self.icontheme3_.resize((100, 100), Image.ANTIALIAS)
                        self.icontheme3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme3_ = ImageTk.PhotoImage(self.icontheme3_)

                        self.icontheme3.image = self.icontheme3_
                        self.icontheme3['image'] = self.icontheme3.image
                        self.HOVER_icontheme3_STATE = 1
                    def unhover_up_tb(e=''):
                        if self.ACTIVE_icontheme3_STATE:
                            self.icontheme3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','MAXOSXBLUE_THEME','normal.png'))
                            self.icontheme3_ = self.icontheme3_.resize((100, 100), Image.ANTIALIAS)
                            self.icontheme3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                            self.icontheme3_ = ImageTk.PhotoImage(self.icontheme3_)

                            self.icontheme3.image = self.icontheme3_
                            self.icontheme3['image'] = self.icontheme3.image
                        else:
                            self.icontheme3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','MAXOSXBLUE_THEME','normal.png'))
                            self.icontheme3_ = self.icontheme3_.resize((100, 100), Image.ANTIALIAS)
                            self.icontheme3_ = ImageTk.PhotoImage(self.icontheme3_)

                            self.icontheme3.image = self.icontheme3_
                            self.icontheme3['image'] = self.icontheme3.image
                        self.HOVER_icontheme3_STATE = 0
                    self.icontheme3 = Label(self.frametheme, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
                    self.icontheme3.image = self.icontheme3_
                    self.icontheme3['image'] = self.icontheme3.image
                    self.icontheme3.bind('<Enter>', hover_up_tb)
                    self.icontheme3.bind('<Leave>', unhover_up_tb)
                    def cmd_up_tb(e=''):
                        self.ACTIVE_icontheme3_STATE = 1
                        self.icontheme_position = 2
                        check_position_icontheme()
                    self.icontheme3.bind('<Button-1>', cmd_up_tb)
                    self.icontheme3.pack(side=LEFT)

                def _icontheme4_():
                    self.icontheme4_ = self.custom_user_icontheme
                    self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
                    #self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                    self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)
                    self.HOVER_icontheme4_STATE = 0
                    self.ACTIVE_icontheme4_STATE = 0
                    def hover_up_tb(e=''):
                        self.icontheme4_ = self.custom_user_icontheme
                        self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
                        self.icontheme4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                        self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)

                        self.icontheme4.image = self.icontheme4_
                        self.icontheme4['image'] = self.icontheme4.image
                        self.HOVER_icontheme4_STATE = 1
                    def unhover_up_tb(e=''):
                        if self.ACTIVE_icontheme4_STATE:
                            self.icontheme4_ = self.custom_user_icontheme
                            self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
                            self.icontheme4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                            self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)

                            self.icontheme4.image = self.icontheme4_
                            self.icontheme4['image'] = self.icontheme4.image
                        else:
                            self.icontheme4_ = self.custom_user_icontheme
                            self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
                            self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)

                            self.icontheme4.image = self.icontheme4_
                            self.icontheme4['image'] = self.icontheme4.image
                        self.HOVER_icontheme4_STATE = 0
                    self.icontheme4 = Label(self.frametheme, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
                    self.icontheme4.image = self.icontheme4_
                    self.icontheme4['image'] = self.icontheme4.image
                    self.icontheme4.bind('<Enter>', hover_up_tb)
                    self.icontheme4.bind('<Leave>', unhover_up_tb)
                    def cmd_up_tb(e=''):
                        self.ACTIVE_icontheme4_STATE = 1
                        self.icontheme_position = 3
                        check_position_icontheme()
                    self.icontheme4.bind('<Button-1>', cmd_up_tb)
                    #self.icontheme4.pack(side=LEFT)

                _icontheme1_()
                _icontheme2_()
                _icontheme3_()
                _icontheme4_()

                def maketheme():
                    self.theme_root = DialogWinCustom(self.content)
                    self.theme_root.title('Создать тему')

                    def theme_upd():
                        self.theme_aft = self.frame_content.after(10000, theme_upd)

                        bg_color = ''
                        fg_color = ''
                        font_ = ''
                        font_size = 0

                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                            bg_color = bg.read()
                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                            fg_color = fg.read()
                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                            font_ = f.read()
                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                            font_size = int(fs.read())

                        self.frame_content['bg'] = bg_color
                        self.colors1['bg'] = bg_color

                        self.lab_bg_['bg'] = bg_color
                        self.lab_bg_['fg'] = fg_color
                        self.lab_bg_['font'] = (font_, font_size)

                        self.lab_fg_['bg'] = bg_color
                        self.lab_fg_['fg'] = fg_color
                        self.lab_fg_['font'] = (font_, font_size)

                        self.colors2['bg'] = bg_color

                        self.colors3['bg'] = bg_color

                        self.framebtns['bg'] = bg_color


                    self.frame_content = Frame(self.theme_root.content)
                    self.frame_content.pack(fill=BOTH, expand=1)

                    self.colors1 = Frame(self.frame_content)
                    self.colors1.pack(fill=X)

                    self.lab_bg_ = Label(self.colors1, text='Цвет фона')
                    self.lab_bg_.pack(side=LEFT, expand=1, padx=10, pady=5)

                    self.lab_fg_ = Label(self.colors1, text='Цвет текста')
                    self.lab_fg_.pack(side=LEFT, expand=1, padx=10, pady=5)


                    self.colors2 = Frame(self.frame_content)
                    self.colors2.pack(fill=X)

                    self.frame_bg = Frame(self.colors2, bg='#9e9e9e')
                    self.frame_bg.pack(side=LEFT, expand=1, padx=10, pady=5, fill=X)

                    self.lab_bg = Label(self.frame_bg, width=5, font=('Montserrat', 15), bg='#000000')
                    self.lab_bg.pack(side=LEFT, expand=1, padx=2, pady=2, fill=X)

                    self.frame_fg = Frame(self.colors2, bg='#9e9e9e')
                    self.frame_fg.pack(side=LEFT, expand=1, padx=10, pady=5, fill=X)

                    self.lab_fg = Label(self.frame_fg, width=5, font=('Montserrat', 15), bg='#000000')
                    self.lab_fg.pack(side=LEFT, expand=1, padx=2, pady=2, fill=X)


                    self.colors3 = Frame(self.frame_content)
                    self.colors3.pack(fill=X)

                    def _bg_():
                        def OK_():
                            color = COLOR.getcolorhex()
                            self.bg_color = color
                            self.lab_bg['bg'] = color
                            COLOR.destroy()
                        COLOR = ColorDialogWin(self.theme_root.root, command=OK_, title='Выбрать цвет фона')

                    LabelButtonSystem(self.colors3, text='Выбрать цвет', command=_bg_).pack(side=LEFT, expand=1, padx=10, pady=5, fill=X)

                    def _fg_():
                        def OK_():
                            color = COLOR.getcolorhex()
                            self.fg_color = color
                            self.lab_fg['bg'] = color
                            COLOR.destroy()
                        COLOR = ColorDialogWin(self.theme_root.root, command=OK_, title='Выбрать цвет фона')

                    LabelButtonSystem(self.colors3, text='Выбрать цвет', command=_fg_).pack(side=LEFT, expand=1, padx=10, pady=5, fill=X)

                    self.framebtns = Frame(self.frame_content)
                    self.framebtns.pack(side=BOTTOM, fill=X, expand=1, anchor=NW)

                    def OK():
                        def color_img(img, color):
                            img = Image.open(img)
                            pixdata = img.load()
                            r, g, b, = ImageColor.getcolor(color, "RGB")
                            for y in range(img.size[1]):
                                for x in range(img.size[0]):
                                    alpha = pixdata[x, y][3]
                                    if alpha:
                                        pixdata[x, y] = (r, g, b, alpha)
                            return img

                        self.custom_user_icontheme = color_img(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','window.png'), color=self.bg_color)
                        self.custom_user_icontheme.paste(color_img(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','title.png'), color=self.fg_color), (0,0), color_img(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','title.png'), color=self.fg_color))
                        self.custom_user_icontheme.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','icon.png')), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','icon.png')))

                        self.icontheme4.pack(side=LEFT)
                        self.plus2.delete()
                        self.plus2.pack(side=LEFT)

                        self.frame_content.after_cancel(self.theme_aft)
                        self.theme_root.destroy()

                        if os.path.isdir(Path(self.registry_path, 'SAVING','SYSTEM_THEME','CUSTOM_THEMES')):
                            name = f"{self.bg_color.replace('#', '')}_{self.fg_color.replace('#', '')}.xtheme"
                            with open(Path(self.registry_path,'SAVING','SYSTEM_THEME','CUSTOM_THEMES',name), 'w', encoding='utf-8') as f:
                                f.write(f"{self.bg_color} {self.fg_color}")
                        else:
                            os.mkdir(Path(self.registry_path, 'SAVING','SYSTEM_THEME','CUSTOM_THEMES'))
                            name = f"{self.bg_color.replace('#', '')}_{self.fg_color.replace('#', '')}.xtheme"
                            with open(Path(self.registry_path,'SAVING','SYSTEM_THEME','CUSTOM_THEMES',name), 'w', encoding='utf-8') as f:
                                f.write(f"{self.bg_color} {self.fg_color}")

                        check_position_icontheme()

                    LabelButtonSystem(self.framebtns, text=' OK ', command=OK).pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

                    def close():
                        self.frame_content.after_cancel(self.theme_aft)
                        self.theme_root.destroy()

                    LabelButtonSystem(self.framebtns, text=(' '+'Отмена'+' '), command=close).pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

                    theme_upd()

                self.plus2 = BUTTON_MENU(self.frametheme, path='PLUS', command=maketheme, size=(100, 100))
                self.plus2.pack(side=LEFT)

                def upd_theme():
                    with open(Path(self.registry_path,'SAVING','SYSTEM_THEME','COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg_:
                        with open(Path(self.registry_path,'SAVING','SYSTEM_THEME','COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg_:
                            bg_r = bg_.read()
                            fg_r = fg_.read()
                            print(bg_r)
                            print(fg_r)
                            if bg_r == '#333533' and fg_r == '#ffffff':
                                self.user_icontheme = ("#333533", "#ffffff")
                                self.bg_color, self.fg_color = "#333533", "#ffffff"
                                self.icontheme_position = 0
                            elif bg_r == '#effbff' and fg_r == '#000000':
                                self.user_icontheme = ("#effbff", "#000000")
                                self.bg_color, self.fg_color = "#effbff", "#000000"
                                self.icontheme_position = 1
                            elif bg_r == '#28749b' and fg_r == '#ffffff':
                                self.user_icontheme = ("#28749b", "#ffffff")
                                self.bg_color, self.fg_color = "#28749b", "#ffffff"
                                self.icontheme_position = 2
                            else:
                                self.user_icontheme = (bg_r, fg_r)
                                self.bg_color, self.fg_color = bg_r, fg_r
                                def color_img(img, color):
                                    img = Image.open(img)
                                    pixdata = img.load()
                                    r, g, b, = ImageColor.getcolor(color, "RGB")
                                    for y in range(img.size[1]):
                                        for x in range(img.size[0]):
                                            alpha = pixdata[x, y][3]
                                            if alpha:
                                                pixdata[x, y] = (r, g, b, alpha)
                                    return img

                                self.custom_user_icontheme = color_img(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','window.png'), color=bg_r)
                                self.custom_user_icontheme.paste(color_img(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','title.png'), color=fg_r), (0,0), color_img(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','title.png'), color=fg_r))
                                self.custom_user_icontheme.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','icon.png')), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','icon.png')))

                                self.icontheme4.pack(side=LEFT)
                                self.plus2.delete()
                                self.plus2.pack(side=LEFT)
                                self.icontheme_position = 3
                    check_position_icontheme()
                upd_theme()

                def more_themes(e=''):
                    self.more_theme_root = DialogWinCustom(self.content)
                    self.more_theme_root.title('Выбрать тему')
                    self.theme_aft = ''
                    def theme_upd():
                        def get_hex(r, g, b):
                            return '#{:02x}{:02x}{:02x}'.format(r, g, b)
                        self.theme_aft = self.frame_content2.after(10000, theme_upd)

                        bg_color = ''
                        fg_color = ''
                        font_ = ''
                        font_size = 0

                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                            bg_color = bg.read()
                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                            fg_color = fg.read()
                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                            font_ = f.read()
                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                            font_size = int(fs.read())

                        color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                        if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                            color_rgb_select[0] = 250
                        else:
                            color_rgb_select[0] = color_rgb_select[0]+10

                        if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                            color_rgb_select[1] = 250
                        else:
                            color_rgb_select[1] = color_rgb_select[1]+10

                        if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                            color_rgb_select[2] = 250
                        else:
                            color_rgb_select[2] = color_rgb_select[2]+10

                        selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])


                        self.frame_content2.configure(fg_color=bg_color)
                        self.frame_content2.configure(scrollbar_fg_color=bg_color)
                        self.frame_content2.configure(scrollbar_button_color=bg_color)
                        self.frame_content2.configure(scrollbar_button_hover_color=selectbg)

                        self.framebtns2['bg'] = bg_color



                    self.frame_content2 = CTkScrollableFrame(self.more_theme_root.content, corner_radius=0)
                    self.frame_content2.pack(fill=BOTH, expand=1)

                    class create_theme_buttons():
                        def __init__(self, master, file, btn4, icon4, plus, root, theme_aft, command, registry_path, upd_theme):
                            self.bg = ''
                            self.fg = ''

                            self.btn4 = btn4
                            self.icon4 = icon4
                            self.plus = plus
                            self.master = master
                            self.root = root
                            self.theme_aft = theme_aft
                            self.registry_path = registry_path
                            self.upd_theme = upd_theme

                            with open(file, 'r', encoding='utf-8') as f:
                                r = f.read()
                                self.bg = r.split()[0]
                                self.fg = r.split()[1]

                            def cmd():

                                with open(Path(self.registry_path,'SAVING','SYSTEM_THEME','COLORS','bg_tb.txt'), 'w', encoding='utf-8') as bg_:
                                    bg_.write(str(self.bg))
                                with open(Path(self.registry_path,'SAVING','SYSTEM_THEME','COLORS','fg_tb.txt'), 'w', encoding='utf-8') as fg_:
                                    fg_.write(str(self.fg))
                                with open(Path(self.registry_path,'SAVING','SYSTEM_THEME','change_theme.txt'), 'w', encoding='utf-8') as f:
                                    f.write(str('True'))

                                #self.master.after_cancel(self.theme_aft)
                                self.upd_theme()
                                command()
                                self.root.destroy()

                            ThemeButtons(master, bg=self.bg, fg=self.fg, command=cmd).pack()

                    for i in os.listdir(Path(self.registry_path,'SAVING','SYSTEM_THEME','CUSTOM_THEMES')):
                        if i[0] == '.' or i[0] == '!':
                            pass
                        else:
                            if os.path.splitext(i)[1] == '.xtheme':
                                create_theme_buttons(self.frame_content2, file=Path(self.registry_path,'SAVING','SYSTEM_THEME','CUSTOM_THEMES',i), btn4=self.icontheme4, icon4=self.custom_user_icontheme, plus=self.plus2, root=self.more_theme_root, theme_aft=self.theme_aft, command=check_position_icontheme, registry_path=self.registry_path, upd_theme=upd_theme)

                    self.framebtns2 = Frame(self.more_theme_root.content)
                    self.framebtns2.pack(side=BOTTOM, fill=X, expand=1, anchor=NW)

                    def close():
                        self.frame_content2.after_cancel(self.theme_aft)
                        self.more_theme_root.destroy()

                    LabelButtonSystem(self.framebtns2, text=(' '+'Отмена'+' '), command=close).pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

                    theme_upd()

                LabelButtonSystem(self.content, text='Больше тем...', command=more_themes).pack(anchor=NW, padx=5, pady=5, fill=X)

                Separator(self.content, orient='horizontal')

                self.lab3 = Label(self.content, text='Конфигурация панели задач')
                self.lab3.pack(anchor=NW, padx=5, pady=5)

                self.frameconfigtb = Frame(self.content)
                self.frameconfigtb.pack(anchor=NW, padx=5, pady=5, fill=X)



                self.tbconfigupimg = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','TOP_TB_BTN','normal.png'))
                self.tbconfigupimg = self.tbconfigupimg.resize((175, 118), Image.ANTIALIAS)
                self.tbconfigupimg = ImageTk.PhotoImage(self.tbconfigupimg)


                self.tbconfigdownimg = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','BOTTOM_TB_BTN','normal.png'))
                self.tbconfigdownimg = self.tbconfigdownimg.resize((175, 118), Image.ANTIALIAS)
                self.tbconfigdownimg = ImageTk.PhotoImage(self.tbconfigdownimg)

                self.HOVER_UP_TB_STATE = 0
                self.ACTIVE_UP_TB_STATE = 0
                def hover_up_tb(e=''):
                    self.tbconfigupimg = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','TOP_TB_BTN','hover.png'))
                    self.tbconfigupimg = self.tbconfigupimg.resize((175, 118), Image.ANTIALIAS)
                    self.tbconfigupimg = ImageTk.PhotoImage(self.tbconfigupimg)
                    self.tbconfigbtnup.image = self.tbconfigupimg
                    self.tbconfigbtnup['image'] = self.tbconfigbtnup.image
                    self.HOVER_UP_TB_STATE = 1
                def unhover_up_tb(e=''):
                    if self.ACTIVE_UP_TB_STATE:
                        self.tbconfigupimg = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','TOP_TB_BTN','active.png'))
                        self.tbconfigupimg = self.tbconfigupimg.resize((175, 118), Image.ANTIALIAS)
                        self.tbconfigupimg = ImageTk.PhotoImage(self.tbconfigupimg)
                        self.tbconfigbtnup.image = self.tbconfigupimg
                        self.tbconfigbtnup['image'] = self.tbconfigbtnup.image
                    else:
                        self.tbconfigupimg = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','TOP_TB_BTN','normal.png'))
                        self.tbconfigupimg = self.tbconfigupimg.resize((175, 118), Image.ANTIALIAS)
                        self.tbconfigupimg = ImageTk.PhotoImage(self.tbconfigupimg)
                        self.tbconfigbtnup.image = self.tbconfigupimg
                        self.tbconfigbtnup['image'] = self.tbconfigbtnup.image
                    self.HOVER_UP_TB_STATE = 0
                self.tbconfigbtnup = Label(self.frameconfigtb, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
                self.tbconfigbtnup.image = self.tbconfigupimg
                self.tbconfigbtnup['image'] = self.tbconfigbtnup.image
                self.tbconfigbtnup.bind('<Enter>', hover_up_tb)
                self.tbconfigbtnup.bind('<Leave>', unhover_up_tb)
                def cmd_up_tb(e=''):
                    if self.ACTIVE_UP_TB_STATE:
                        self.ACTIVE_UP_TB_STATE = 0
                        self.ACTIVE_DOWN_TB_STATE = 0
                        with open(Path(self.registry_path,'SAVING','TASKBAR_CONFIG','tb_config.txt'), 'w', encoding='utf-8') as tb:
                            tb.write('False')
                    else:
                        self.ACTIVE_UP_TB_STATE = 1
                        self.ACTIVE_DOWN_TB_STATE = 0
                        with open(Path(self.registry_path,'SAVING','TASKBAR_CONFIG','tb_config.txt'), 'w', encoding='utf-8') as tb:
                            tb.write('top')
                self.tbconfigbtnup.bind('<Button-1>', cmd_up_tb)
                self.tbconfigbtnup.pack(side=LEFT, expand=1)


                self.HOVER_DOWN_TB_STATE = 0
                self.ACTIVE_DOWN_TB_STATE = 0
                def hover_down_tb(e=''):
                    self.tbconfigdownimg = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','BOTTOM_TB_BTN','hover.png'))
                    self.tbconfigdownimg = self.tbconfigdownimg.resize((175, 118), Image.ANTIALIAS)
                    self.tbconfigdownimg = ImageTk.PhotoImage(self.tbconfigdownimg)
                    self.tbconfigbtndown.image = self.tbconfigdownimg
                    self.tbconfigbtndown['image'] = self.tbconfigbtndown.image
                    self.HOVER_DOWN_TB_STATE = 1
                def unhover_down_tb(e=''):
                    if self.ACTIVE_DOWN_TB_STATE:
                        self.tbconfigdownimg = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','BOTTOM_TB_BTN','active.png'))
                        self.tbconfigdownimg = self.tbconfigdownimg.resize((175, 118), Image.ANTIALIAS)
                        self.tbconfigdownimg = ImageTk.PhotoImage(self.tbconfigdownimg)
                        self.tbconfigbtndown.image = self.tbconfigdownimg
                        self.tbconfigbtndown['image'] = self.tbconfigbtndown.image
                    else:
                        self.tbconfigdownimg = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','BOTTOM_TB_BTN','normal.png'))
                        self.tbconfigdownimg = self.tbconfigdownimg.resize((175, 118), Image.ANTIALIAS)
                        self.tbconfigdownimg = ImageTk.PhotoImage(self.tbconfigdownimg)
                        self.tbconfigbtndown.image = self.tbconfigdownimg
                        self.tbconfigbtndown['image'] = self.tbconfigbtndown.image
                    self.HOVER_DOWN_TB_STATE = 0
                self.tbconfigbtndown = Label(self.frameconfigtb, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
                self.tbconfigbtndown.image = self.tbconfigdownimg
                self.tbconfigbtndown['image'] = self.tbconfigbtndown.image
                self.tbconfigbtndown.bind('<Enter>', hover_down_tb)
                self.tbconfigbtndown.bind('<Leave>', unhover_down_tb)
                def cmd_down_tb(e=''):
                    if self.ACTIVE_DOWN_TB_STATE:
                        self.ACTIVE_UP_TB_STATE = 0
                        self.ACTIVE_DOWN_TB_STATE = 0
                        with open(Path(self.registry_path,'SAVING','TASKBAR_CONFIG','tb_config.txt'), 'w', encoding='utf-8') as tb:
                            tb.write('False')
                    else:
                        self.ACTIVE_UP_TB_STATE = 0
                        self.ACTIVE_DOWN_TB_STATE = 1
                        with open(Path(self.registry_path,'SAVING','TASKBAR_CONFIG','tb_config.txt'), 'w', encoding='utf-8') as tb:
                            tb.write('bottom')
                self.tbconfigbtndown.bind('<Button-1>', cmd_down_tb)
                self.tbconfigbtndown.pack(side=LEFT, expand=1)

                Separator(self.content, orient='horizontal')

                self.lab4 = Label(self.content, text='Шрифт')
                self.lab4.pack(anchor=NW, padx=5, pady=5)
                font_ = ''
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                    font_ = f.read()
                self.standart_font = font_

                def change_font(e=''):
                    self.standart_font = self.comboboxfont.get()
                    #with open(Path(self.registry_path, 'SAVING', 'SYSTEM_THEME', 'FONTS', 'standart_font.txt'), 'w', encoding='utf-8') as f:
                    #    f.write(self.comboboxfont.get())
                    #with open(Path(self.registry_path, 'SAVING', 'SYSTEM_THEME', 'change_theme.txt'), 'w', encoding='utf-8') as f:
                    #    f.write('True')
                self.comboboxfont = CTkComboBox(self.content, values=sorted(list(font.families())), command=change_font)
                self.comboboxfont.pack(anchor=NW, padx=5, pady=5, fill=X)
                self.comboboxfont.set(font_)
                def upd_font(e=''):
                    self.font_list = sorted(list(font.families()))
                    #self.comboboxfont.configure(values=self.font_list)
                self.comboboxfont.bind('<KeyRelease>', change_font)

                self.labfontsize = Label(self.content)
                self.labfontsize.pack(anchor=NW, padx=5, pady=5)

                font_size = 0
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as f:
                    font_size = int(f.read())
                self.standart_font_size = str(font_size)

                def change_font_size(e=''):
                    self.standart_font_size = int(self.scalefontsize.get())
                    self.labfontsize['text'] = int(self.scalefontsize.get())

                self.scalefontsize = CTkSlider(self.content, from_=1, to=100, command=change_font_size)
                self.scalefontsize.pack(anchor=NW, padx=5, pady=5, fill=X)
                self.scalefontsize.set(font_size)
                self.labfontsize['text'] = font_size
                def change_font_OK(e=''):
                    with open(Path(self.registry_path, 'SAVING', 'SYSTEM_THEME', 'FONTS', 'standart_font.txt'), 'w', encoding='utf-8') as f:
                        f.write(self.standart_font)
                    with open(Path(self.registry_path, 'SAVING', 'SYSTEM_THEME', 'FONTS', 'standart_font_size.txt'), 'w', encoding='utf-8') as f:
                        f.write(str(self.standart_font_size))
                    with open(Path(self.registry_path, 'SAVING', 'SYSTEM_THEME', 'change_theme.txt'), 'w', encoding='utf-8') as f:
                        f.write('True')
                LabelButtonSystem(self.content, text='Применить', command=change_font_OK).pack(anchor=NW, padx=5, pady=5, fill=X)

                Separator(self.content, orient='horizontal')

                self.lab5 = Label(self.content, text='Фон рабочего стола')
                self.lab5.pack(anchor=NW, padx=5, pady=5)

                self.frame_iconsdesktop = CTkScrollableFrame(self.content, orientation='horizontal', corner_radius=0)


                self.icondesktop_position = 0
                self.user_icondesktop = str('MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/DESKTOP_IMAGE/image1.png')
                self.custom_user_icon_desktop = Image.open(str(Path(self.registry_path, 'SAVING', 'DESKTOP_CONFIG', 'ImageDesktop.png')))
                self.color_desktop = 0

                def check_position_icondesktop():
                    if self.icondesktop_position == 0:
                        self.user_icondesktop = str('MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/DESKTOP_IMAGE/image1.png')

                        with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','image_desktop.txt'), 'w', encoding='utf-8') as f:
                            f.write('True')

                        self.icondesktop1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image1.png'))
                        self.icondesktop1_ = self.icondesktop1_.resize((175, 118), Image.ANTIALIAS)
                        self.icondesktop1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop1_ = ImageTk.PhotoImage(self.icondesktop1_)
                        self.icondesktop1.image = self.icondesktop1_
                        self.icondesktop1['image'] = self.icondesktop1.image
                        self.ACTIVE_icondesktop1_STATE = 1


                        self.icondesktop2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image2.png'))
                        self.icondesktop2_ = self.icondesktop2_.resize((175, 118), Image.ANTIALIAS)
                        #self.icondesktop2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop2_ = ImageTk.PhotoImage(self.icondesktop2_)
                        self.icondesktop2.image = self.icondesktop2_
                        self.icondesktop2['image'] = self.icondesktop2.image
                        self.ACTIVE_icondesktop2_STATE = 0


                        self.icondesktop3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image3.png'))
                        self.icondesktop3_ = self.icondesktop3_.resize((175, 118), Image.ANTIALIAS)
                        #self.icondesktop2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop3_ = ImageTk.PhotoImage(self.icondesktop3_)
                        self.icondesktop3.image = self.icondesktop3_
                        self.icondesktop3['image'] = self.icondesktop3.image
                        self.ACTIVE_icondesktop3_STATE = 0


                        self.icondesktop4_ = self.custom_user_icon_desktop
                        self.icondesktop4_ = self.icondesktop4_.resize((175, 118), Image.ANTIALIAS)
                        #self.icondesktop4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop4_ = ImageTk.PhotoImage(self.icondesktop4_)
                        self.icondesktop4.image = self.icondesktop4_
                        self.icondesktop4['image'] = self.icondesktop4.image
                        self.ACTIVE_icondesktop4_STATE = 0
                    elif self.icondesktop_position == 1:
                        self.user_icondesktop = str('MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/DESKTOP_IMAGE/image2.png')

                        with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','image_desktop.txt'), 'w', encoding='utf-8') as f:
                            f.write('True')

                        self.icondesktop1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image1.png'))
                        self.icondesktop1_ = self.icondesktop1_.resize((175, 118), Image.ANTIALIAS)
                        #self.icondesktop1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop1_ = ImageTk.PhotoImage(self.icondesktop1_)
                        self.icondesktop1.image = self.icondesktop1_
                        self.icondesktop1['image'] = self.icondesktop1.image
                        self.ACTIVE_icondesktop1_STATE = 0


                        self.icondesktop2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image2.png'))
                        self.icondesktop2_ = self.icondesktop2_.resize((175, 118), Image.ANTIALIAS)
                        self.icondesktop2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop2_ = ImageTk.PhotoImage(self.icondesktop2_)
                        self.icondesktop2.image = self.icondesktop2_
                        self.icondesktop2['image'] = self.icondesktop2.image
                        self.ACTIVE_icondesktop2_STATE = 1


                        self.icondesktop3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image3.png'))
                        self.icondesktop3_ = self.icondesktop3_.resize((175, 118), Image.ANTIALIAS)
                        #self.icondesktop2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop3_ = ImageTk.PhotoImage(self.icondesktop3_)
                        self.icondesktop3.image = self.icondesktop3_
                        self.icondesktop3['image'] = self.icondesktop3.image
                        self.ACTIVE_icondesktop3_STATE = 0


                        self.icondesktop4_ = self.custom_user_icon_desktop
                        self.icondesktop4_ = self.icondesktop4_.resize((175, 118), Image.ANTIALIAS)
                        #self.icondesktop4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop4_ = ImageTk.PhotoImage(self.icondesktop4_)
                        self.icondesktop4.image = self.icondesktop4_
                        self.icondesktop4['image'] = self.icondesktop4.image
                        self.ACTIVE_icondesktop4_STATE = 0
                    elif self.icondesktop_position == 2:
                        self.user_icondesktop = str('MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/DESKTOP_IMAGE/image3.png')

                        with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','image_desktop.txt'), 'w', encoding='utf-8') as f:
                            f.write('True')

                        self.icondesktop1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image1.png'))
                        self.icondesktop1_ = self.icondesktop1_.resize((175, 118), Image.ANTIALIAS)
                        #self.icondesktop1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop1_ = ImageTk.PhotoImage(self.icondesktop1_)
                        self.icondesktop1.image = self.icondesktop1_
                        self.icondesktop1['image'] = self.icondesktop1.image
                        self.ACTIVE_icondesktop1_STATE = 0


                        self.icondesktop2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image2.png'))
                        self.icondesktop2_ = self.icondesktop2_.resize((175, 118), Image.ANTIALIAS)
                        #self.icondesktop2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop2_ = ImageTk.PhotoImage(self.icondesktop2_)
                        self.icondesktop2.image = self.icondesktop2_
                        self.icondesktop2['image'] = self.icondesktop2.image
                        self.ACTIVE_icondesktop2_STATE = 0


                        self.icondesktop3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image3.png'))
                        self.icondesktop3_ = self.icondesktop3_.resize((175, 118), Image.ANTIALIAS)
                        self.icondesktop3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop3_ = ImageTk.PhotoImage(self.icondesktop3_)
                        self.icondesktop3.image = self.icondesktop3_
                        self.icondesktop3['image'] = self.icondesktop3.image
                        self.ACTIVE_icondesktop3_STATE = 1


                        self.icondesktop4_ = self.custom_user_icon_desktop
                        self.icondesktop4_ = self.icondesktop4_.resize((175, 118), Image.ANTIALIAS)
                        #self.icondesktop4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop4_ = ImageTk.PhotoImage(self.icondesktop4_)
                        self.icondesktop4.image = self.icondesktop4_
                        self.icondesktop4['image'] = self.icondesktop4.image
                        self.ACTIVE_icondesktop4_STATE = 0
                    elif self.icondesktop_position == 3:
                        self.user_icondesktop = str(Path(self.registry_path, 'SAVING', 'DESKTOP_CONFIG','DESKTOPS_IMAGES','custom_desktop_image.png'))

                        with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','image_desktop.txt'), 'w', encoding='utf-8') as f:
                            if self.color_desktop:
                                f.write('False')
                            else:
                                f.write('True')

                        self.icondesktop1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image1.png'))
                        self.icondesktop1_ = self.icondesktop1_.resize((175, 118), Image.ANTIALIAS)
                        #self.icondesktop1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop1_ = ImageTk.PhotoImage(self.icondesktop1_)
                        self.icondesktop1.image = self.icondesktop1_
                        self.icondesktop1['image'] = self.icondesktop1.image
                        self.ACTIVE_icondesktop1_STATE = 0


                        self.icondesktop2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image2.png'))
                        self.icondesktop2_ = self.icondesktop2_.resize((175, 118), Image.ANTIALIAS)
                        #self.icondesktop2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop2_ = ImageTk.PhotoImage(self.icondesktop2_)
                        self.icondesktop2.image = self.icondesktop2_
                        self.icondesktop2['image'] = self.icondesktop2.image
                        self.ACTIVE_icondesktop2_STATE = 0


                        self.icondesktop3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image3.png'))
                        self.icondesktop3_ = self.icondesktop3_.resize((175, 118), Image.ANTIALIAS)
                        #self.icondesktop3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop3_ = ImageTk.PhotoImage(self.icondesktop3_)
                        self.icondesktop3.image = self.icondesktop3_
                        self.icondesktop3['image'] = self.icondesktop3.image
                        self.ACTIVE_icondesktop3_STATE = 0


                        self.icondesktop4_ = self.custom_user_icon_desktop
                        self.icondesktop4_ = self.icondesktop4_.resize((175, 118), Image.ANTIALIAS)
                        self.icondesktop4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop4_ = ImageTk.PhotoImage(self.icondesktop4_)
                        self.icondesktop4.image = self.icondesktop4_
                        self.icondesktop4['image'] = self.icondesktop4.image
                        self.ACTIVE_icondesktop4_STATE = 1

                    if os.path.isfile(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','ImageDesktop.png')):
                        if self.icondesktop_position != 3:
                            os.remove(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','ImageDesktop.png'))
                            shutil.copy(self.user_icondesktop, Path(self.registry_path,'SAVING','DESKTOP_CONFIG','ImageDesktop.png'))
                            with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','default_desktop.txt'), 'w', encoding='utf-8') as f:
                                f.write(self.user_icondesktop)
                            with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','image_desktop_change.txt'), 'w', encoding='utf-8') as f:
                                f.write('True')
                        else:
                            color_desktop = ''
                            with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','image_desktop.txt'), 'r', encoding='utf-8') as f:
                                color_desktop = f.read().lower()

                            if color_desktop == 'true':
                                shutil.copy(self.user_icondesktop, Path(self.registry_path,'SAVING','DESKTOP_CONFIG','ImageDesktop.png'))
                            else:
                                with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','image_desktop.txt'), 'w', encoding='utf-8') as f:
                                    f.write('False')
                            with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','default_desktop.txt'), 'w', encoding='utf-8') as f:
                                f.write('False')
                            with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','image_desktop_change.txt'), 'w', encoding='utf-8') as f:
                                f.write('True')

                def upd_desktop():
                    def color_img(img, color):
                        img = Image.open(img)
                        pixdata = img.load()
                        r, g, b, = ImageColor.getcolor(color, "RGB")
                        for y in range(img.size[1]):
                            for x in range(img.size[0]):
                                alpha = pixdata[x, y][3]
                                if alpha:
                                    pixdata[x, y] = (r, g, b, alpha)
                        return img
                    image1 = ''
                    image2 = ''
                    image3 = ''
                    color_desktop = ''
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_GLOBAL','GLOBAL_VARIABLES','DEFAULT_DESKTOP_IMAGES','0.txt'), 'r', encoding='utf-8') as f:
                        image1 = f.read().lower()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_GLOBAL','GLOBAL_VARIABLES','DEFAULT_DESKTOP_IMAGES','1.txt'), 'r', encoding='utf-8') as f:
                        image2 = f.read().lower()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_GLOBAL','GLOBAL_VARIABLES','DEFAULT_DESKTOP_IMAGES','2.txt'), 'r', encoding='utf-8') as f:
                        image3 = f.read().lower()

                    with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','image_desktop.txt'), 'r', encoding='utf-8') as f:
                        color_desktop = f.read().lower()

                    if color_desktop == 'true':
                        with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','default_desktop.txt'), 'r', encoding='utf-8') as f:
                            self.color_desktop = 0
                            ImageDesktop = f.read().lower()
                            if ImageDesktop == image1:
                                self.icondesktop_position = 0
                                self.user_icondesktop = str('MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/DESKTOP_IMAGE/image1.png')
                            elif ImageDesktop == image2:
                                self.icondesktop_position = 1
                                self.user_icondesktop = str('MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/DESKTOP_IMAGE/image2.png')
                            elif ImageDesktop == image3:
                                self.icondesktop_position = 2
                                self.user_icondesktop = str('MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/DESKTOP_IMAGE/image3.png')
                            else:
                                self.icondesktop_position = 3
                                shutil.copy(Path(self.registry_path, 'SAVING', 'DESKTOP_CONFIG', 'ImageDesktop.png'), Path(self.registry_path, 'SAVING', 'DESKTOP_CONFIG', 'DESKTOPS_IMAGES', 'custom_desktop_image.png'))
                                self.custom_user_icon_desktop = Image.open(str(Path(self.registry_path, 'SAVING', 'DESKTOP_CONFIG', 'DESKTOPS_IMAGES', 'custom_desktop_image.png')))
                                self.user_icondesktop = str(self.custom_user_icon_desktop)

                                self.icondesktop4_ = self.custom_user_icon_desktop
                                self.icondesktop4_ = self.icondesktop4_.resize((175, 118), Image.ANTIALIAS)
                                #self.icondesktop4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                                self.icondesktop4_ = ImageTk.PhotoImage(self.icondesktop4_)
                                self.icondesktop4.image = self.icondesktop4_
                                self.icondesktop4['image'] = self.icondesktop4.image
                                self.ACTIVE_icondesktop4_STATE = 1
                                self.icondesktop4.pack(side=LEFT)

                                self.plus3.delete()
                                self.plus3.pack(side=LEFT)
                    else:
                        with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','bg_desktop.txt'), 'r', encoding='utf-8') as f:
                            self.icondesktop_position = 3
                            self.color_desktop = 1
                            bg_r = f.read()

                            self.custom_user_icon_desktop = color_img(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','BG_Desktop.png'), color=bg_r)

                            self.icondesktop4_ = self.custom_user_icon_desktop
                            self.icondesktop4_ = self.icondesktop4_.resize((175, 118), Image.ANTIALIAS)
                            #self.icondesktop4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                            self.icondesktop4_ = ImageTk.PhotoImage(self.icondesktop4_)
                            self.icondesktop4.image = self.icondesktop4_
                            self.icondesktop4['image'] = self.icondesktop4.image
                            self.ACTIVE_icondesktop4_STATE = 1
                            self.icondesktop4.pack(side=LEFT)

                            self.plus3.delete()
                            self.plus3.pack(side=LEFT)

                    if os.path.isfile(Path(self.registry_path, 'SAVING', 'DESKTOP_CONFIG', 'DESKTOPS_IMAGES', 'custom_desktop_image.png')) == True and color_desktop == 'true':
                        self.custom_user_icon_desktop = Image.open(str(Path(self.registry_path, 'SAVING', 'DESKTOP_CONFIG', 'DESKTOPS_IMAGES', 'custom_desktop_image.png')))

                        self.icondesktop4_ = self.custom_user_icon_desktop
                        self.icondesktop4_ = self.icondesktop4_.resize((175, 118), Image.ANTIALIAS)
                        #self.icondesktop4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop4_ = ImageTk.PhotoImage(self.icondesktop4_)
                        self.icondesktop4.image = self.icondesktop4_
                        self.icondesktop4['image'] = self.icondesktop4.image
                        self.ACTIVE_icondesktop4_STATE = 0
                        self.icondesktop4.pack(side=LEFT)

                        self.plus3.delete()
                        self.plus3.pack(side=LEFT)

                    check_position_icondesktop()

                def _icondesktop1_():
                    self.icondesktop1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image1.png'))
                    self.icondesktop1_ = self.icondesktop1_.resize((175, 118), Image.ANTIALIAS)
                    self.icondesktop1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                    self.icondesktop1_ = ImageTk.PhotoImage(self.icondesktop1_)
                    self.HOVER_icondesktop1_STATE = 0
                    self.ACTIVE_icondesktop1_STATE = 1
                    def hover_up_tb(e=''):
                        self.icondesktop1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image1.png'))
                        self.icondesktop1_ = self.icondesktop1_.resize((175, 118), Image.ANTIALIAS)
                        self.icondesktop1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop1_ = ImageTk.PhotoImage(self.icondesktop1_)

                        self.icondesktop1.image = self.icondesktop1_
                        self.icondesktop1['image'] = self.icondesktop1.image
                        self.HOVER_icondesktop1_STATE = 1
                    def unhover_up_tb(e=''):
                        if self.ACTIVE_icondesktop1_STATE:
                            self.icondesktop1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image1.png'))
                            self.icondesktop1_ = self.icondesktop1_.resize((175, 118), Image.ANTIALIAS)
                            self.icondesktop1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                            self.icondesktop1_ = ImageTk.PhotoImage(self.icondesktop1_)

                            self.icondesktop1.image = self.icondesktop1_
                            self.icondesktop1['image'] = self.icondesktop1.image
                        else:
                            self.icondesktop1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image1.png'))
                            self.icondesktop1_ = self.icondesktop1_.resize((175, 118), Image.ANTIALIAS)
                            self.icondesktop1_ = ImageTk.PhotoImage(self.icondesktop1_)

                            self.icondesktop1.image = self.icondesktop1_
                            self.icondesktop1['image'] = self.icondesktop1.image
                        self.HOVER_icondesktop1_STATE = 0
                    self.icondesktop1 = Label(self.frame_iconsdesktop, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
                    self.icondesktop1.image = self.icondesktop1_
                    self.icondesktop1['image'] = self.icondesktop1.image
                    self.icondesktop1.bind('<Enter>', hover_up_tb)
                    self.icondesktop1.bind('<Leave>', unhover_up_tb)
                    def cmd_up_tb(e=''):
                        self.ACTIVE_icondesktop1_STATE = 1
                        self.icondesktop_position = 0
                        check_position_icondesktop()
                    self.icondesktop1.bind('<Button-1>', cmd_up_tb)
                    self.icondesktop1.pack(side=LEFT)

                def _icondesktop2_():
                    self.icondesktop2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image2.png'))
                    self.icondesktop2_ = self.icondesktop2_.resize((175, 118), Image.ANTIALIAS)
                    #self.icondesktop2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                    self.icondesktop2_ = ImageTk.PhotoImage(self.icondesktop2_)
                    self.HOVER_icondesktop2_STATE = 0
                    self.ACTIVE_icondesktop2_STATE = 0
                    def hover_up_tb(e=''):
                        self.icondesktop2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image2.png'))
                        self.icondesktop2_ = self.icondesktop2_.resize((175, 118), Image.ANTIALIAS)
                        self.icondesktop2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop2_ = ImageTk.PhotoImage(self.icondesktop2_)

                        self.icondesktop2.image = self.icondesktop2_
                        self.icondesktop2['image'] = self.icondesktop2.image
                        self.HOVER_icondesktop2_STATE = 1
                    def unhover_up_tb(e=''):
                        if self.ACTIVE_icondesktop2_STATE:
                            self.icondesktop2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image2.png'))
                            self.icondesktop2_ = self.icondesktop2_.resize((175, 118), Image.ANTIALIAS)
                            self.icondesktop2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                            self.icondesktop2_ = ImageTk.PhotoImage(self.icondesktop2_)

                            self.icondesktop2.image = self.icondesktop2_
                            self.icondesktop2['image'] = self.icondesktop2.image
                        else:
                            self.icondesktop2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image2.png'))
                            self.icondesktop2_ = self.icondesktop2_.resize((175, 118), Image.ANTIALIAS)
                            self.icondesktop2_ = ImageTk.PhotoImage(self.icondesktop2_)

                            self.icondesktop2.image = self.icondesktop2_
                            self.icondesktop2['image'] = self.icondesktop2.image
                        self.HOVER_icondesktop2_STATE = 0
                    self.icondesktop2 = Label(self.frame_iconsdesktop, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
                    self.icondesktop2.image = self.icondesktop2_
                    self.icondesktop2['image'] = self.icondesktop2.image
                    self.icondesktop2.bind('<Enter>', hover_up_tb)
                    self.icondesktop2.bind('<Leave>', unhover_up_tb)
                    def cmd_up_tb(e=''):
                        self.ACTIVE_icondesktop2_STATE = 1
                        self.icondesktop_position = 1
                        check_position_icondesktop()
                    self.icondesktop2.bind('<Button-1>', cmd_up_tb)
                    self.icondesktop2.pack(side=LEFT)

                def _icondesktop3_():
                    self.icondesktop3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image3.png'))
                    self.icondesktop3_ = self.icondesktop3_.resize((175, 118), Image.ANTIALIAS)
                    #self.icondesktop3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                    self.icondesktop3_ = ImageTk.PhotoImage(self.icondesktop3_)
                    self.HOVER_icondesktop3_STATE = 0
                    self.ACTIVE_icondesktop3_STATE = 0
                    def hover_up_tb(e=''):
                        self.icondesktop3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image3.png'))
                        self.icondesktop3_ = self.icondesktop3_.resize((175, 118), Image.ANTIALIAS)
                        self.icondesktop3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop3_ = ImageTk.PhotoImage(self.icondesktop3_)

                        self.icondesktop3.image = self.icondesktop3_
                        self.icondesktop3['image'] = self.icondesktop3.image
                        self.HOVER_icondesktop3_STATE = 1
                    def unhover_up_tb(e=''):
                        if self.ACTIVE_icondesktop3_STATE:
                            self.icondesktop3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image3.png'))
                            self.icondesktop3_ = self.icondesktop3_.resize((175, 118), Image.ANTIALIAS)
                            self.icondesktop3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                            self.icondesktop3_ = ImageTk.PhotoImage(self.icondesktop3_)

                            self.icondesktop3.image = self.icondesktop3_
                            self.icondesktop3['image'] = self.icondesktop3.image
                        else:
                            self.icondesktop3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image3.png'))
                            self.icondesktop3_ = self.icondesktop3_.resize((175, 118), Image.ANTIALIAS)
                            self.icondesktop3_ = ImageTk.PhotoImage(self.icondesktop3_)

                            self.icondesktop3.image = self.icondesktop3_
                            self.icondesktop3['image'] = self.icondesktop3.image
                        self.HOVER_icondesktop3_STATE = 0
                    self.icondesktop3 = Label(self.frame_iconsdesktop, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
                    self.icondesktop3.image = self.icondesktop3_
                    self.icondesktop3['image'] = self.icondesktop3.image
                    self.icondesktop3.bind('<Enter>', hover_up_tb)
                    self.icondesktop3.bind('<Leave>', unhover_up_tb)
                    def cmd_up_tb(e=''):
                        self.ACTIVE_icondesktop3_STATE = 1
                        self.icondesktop_position = 2
                        check_position_icondesktop()
                    self.icondesktop3.bind('<Button-1>', cmd_up_tb)
                    self.icondesktop3.pack(side=LEFT)

                def _icondesktop4_():
                    self.icondesktop4_ = self.custom_user_icon_desktop
                    self.icondesktop4_ = self.icondesktop4_.resize((175, 118), Image.ANTIALIAS)
                    #self.icondesktop4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                    self.icondesktop4_ = ImageTk.PhotoImage(self.icondesktop4_)
                    self.HOVER_icondesktop4_STATE = 0
                    self.ACTIVE_icondesktop4_STATE = 0
                    def hover_up_tb(e=''):
                        self.icondesktop4_ = self.custom_user_icon_desktop
                        self.icondesktop4_ = self.icondesktop4_.resize((175, 118), Image.ANTIALIAS)
                        self.icondesktop4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                        self.icondesktop4_ = ImageTk.PhotoImage(self.icondesktop4_)

                        self.icondesktop4.image = self.icondesktop4_
                        self.icondesktop4['image'] = self.icondesktop4.image
                        self.HOVER_icondesktop4_STATE = 1
                    def unhover_up_tb(e=''):
                        if self.ACTIVE_icondesktop4_STATE:
                            self.icondesktop4_ = self.custom_user_icon_desktop
                            self.icondesktop4_ = self.icondesktop4_.resize((175, 118), Image.ANTIALIAS)
                            self.icondesktop4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                            self.icondesktop4_ = ImageTk.PhotoImage(self.icondesktop4_)

                            self.icondesktop4.image = self.icondesktop4_
                            self.icondesktop4['image'] = self.icondesktop4.image
                        else:
                            self.icondesktop4_ = self.custom_user_icon_desktop
                            self.icondesktop4_ = self.icondesktop4_.resize((175, 118), Image.ANTIALIAS)
                            self.icondesktop4_ = ImageTk.PhotoImage(self.icondesktop4_)

                            self.icondesktop4.image = self.icondesktop4_
                            self.icondesktop4['image'] = self.icondesktop4.image
                        self.HOVER_icondesktop4_STATE = 0
                    self.icondesktop4 = Label(self.frame_iconsdesktop, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
                    self.icondesktop4.image = self.icondesktop4_
                    self.icondesktop4['image'] = self.icondesktop4.image
                    self.icondesktop4.bind('<Enter>', hover_up_tb)
                    self.icondesktop4.bind('<Leave>', unhover_up_tb)
                    def cmd_up_tb(e=''):
                        self.ACTIVE_icondesktop4_STATE = 1
                        self.icondesktop_position = 3
                        check_position_icondesktop()
                    self.icondesktop4.bind('<Button-1>', cmd_up_tb)
                    #self.icondesktop4.pack(side=LEFT)

                _icondesktop1_()
                _icondesktop2_()
                _icondesktop3_()
                _icondesktop4_()

                def makecustomdesktop(e=''):
                    self.desktop_root = DialogWinCustom(self.content)
                    self.desktop_root.title('Добавить фон рабочего стола')

                    def theme_upd():
                        self.theme_aft_desktop = self.frame_content_desktop.after(10000, theme_upd)

                        bg_color = ''
                        fg_color = ''
                        font_ = ''
                        font_size = 0

                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                            bg_color = bg.read()
                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                            fg_color = fg.read()
                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                            font_ = f.read()
                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                            font_size = int(fs.read())

                        self.frame_content_desktop['bg'] = bg_color
                        self.desktop['bg'] = bg_color

                        self.lab_bg_['bg'] = bg_color
                        self.lab_bg_['fg'] = fg_color
                        self.lab_bg_['font'] = (font_, font_size)

                        self.lab_bg_2['bg'] = bg_color
                        self.lab_bg_2['fg'] = fg_color
                        self.lab_bg_2['font'] = (font_, font_size)

                        self.desktop2['bg'] = bg_color

                        self.framebtns_desktop['bg'] = bg_color


                    self.frame_content_desktop = Frame(self.desktop_root.content)
                    self.frame_content_desktop.pack(fill=BOTH, expand=1)

                    self.desktop = Frame(self.frame_content_desktop)
                    self.desktop.pack(fill=X)

                    self.lab_bg_ = Label(self.desktop, text='Изображение рабочего стола')
                    self.lab_bg_.pack(side=LEFT, expand=1, padx=10, pady=5)

                    self.lab_bg_2 = Label(self.desktop, text='Цвет фона рабочего стола')
                    self.lab_bg_2.pack(side=LEFT, expand=1, padx=10, pady=5)

                    self.desktop2 = Frame(self.frame_content_desktop)
                    self.desktop2.pack(fill=X)

                    def OK1(e=''):
                        def Okay(e=''):
                            PATH = WIN.getpath()
                            self.color_desktop = 0
                            shutil.copy(PATH, Path(self.registry_path,'SAVING','DESKTOP_CONFIG','ImageDesktop.png'))
                            with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','default_desktop.txt'), 'w', encoding='utf-8') as f:
                                f.write('False')
                            with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','image_desktop_change.txt'), 'w', encoding='utf-8') as f:
                                f.write('True')
                            with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','image_desktop.txt'), 'w', encoding='utf-8') as f:
                                f.write('True')
                            self.icondesktop4.pack(side=LEFT)
                            OK()
                        WIN = FileDialogWin(self.desktop_root.content, title='Выбрать изображение рабочего стола', ext_list=['.jpg','.jpeg','.png','.gif'], folder=Path(self.homefolder_path, 'Images'), command=Okay)

                    LabelButtonSystem(self.desktop2, text='Выбрать', command=OK1).pack(side=LEFT, expand=1, padx=10, pady=5, fill=X)

                    def OK2(e=''):
                        def Okay(e=''):
                            COLOR = WIN.getcolorhex()
                            self.color_desktop = 1
                            with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','bg_desktop.txt'), 'w', encoding='utf-8') as f:
                                f.write(COLOR)
                            with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','default_desktop.txt'), 'w', encoding='utf-8') as f:
                                f.write('False')
                            with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','image_desktop_change.txt'), 'w', encoding='utf-8') as f:
                                f.write('True')
                            with open(Path(self.registry_path,'SAVING','DESKTOP_CONFIG','image_desktop.txt'), 'w', encoding='utf-8') as f:
                                f.write('False')
                            self.icondesktop4.pack(side=LEFT)
                            OK()
                        WIN = ColorDialogWin(self.desktop_root.content, title='Выбрать цвет фона рабочего стола', command=Okay)

                    LabelButtonSystem(self.desktop2, text='Выбрать', command=OK2).pack(side=LEFT, expand=1, padx=10, pady=5, fill=X)

                    self.framebtns_desktop = Frame(self.frame_content_desktop)
                    self.framebtns_desktop.pack(side=BOTTOM, fill=X, expand=1, anchor=NW)

                    def OK():
                        self.plus3.delete()
                        self.plus3.pack(side=LEFT)

                        upd_desktop()

                        self.desktop_root.destroy()


                    LabelButtonSystem(self.framebtns_desktop, text=' OK ', command=OK).pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

                    def close():
                        self.frame_content_desktop.after_cancel(self.theme_aft_desktop)
                        self.desktop_root.destroy()

                    LabelButtonSystem(self.framebtns_desktop, text=(' '+'Отмена'+' '), command=close).pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

                    theme_upd()

                self.plus3 = BUTTON_MENU(self.frame_iconsdesktop, path='PLUS', command=makecustomdesktop, size=(118, 118))
                self.plus3.pack(side=LEFT)

                upd_desktop()



                theme_update()
                GlobalUpdate()

                self.frame_iconsdesktop.pack(anchor=NW, fill=X, expand=1)

        class settings_info():
            def destroy(self):
                self.content.after_cancel(self.theme_after)
                self.content.after_cancel(self.global_after)
                self.content.destroy()
            def __init__(self, master, registry_path):
                self.registry_path = registry_path
                self.font_list = sorted(list(font.families()))

                def theme_update():
                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)
                    self.theme_after = self.content.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    self.font_list = sorted(list(font.families()))
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())

                    self.content['bg'] = bg_color

                    self.lab0['bg'] = bg_color
                    self.lab0['fg'] = fg_color
                    self.lab0['font'] = (font_, font_size+15, 'bold')


                    self.lab1['bg'] = bg_color
                    self.lab1['fg'] = fg_color
                    self.lab1['font'] = (font_, font_size+10, 'bold')


                    self.lab2['bg'] = bg_color
                    self.lab2['fg'] = fg_color
                    self.lab2['font'] = (font_, font_size)



                    self.lab3['bg'] = bg_color
                    self.lab3['fg'] = fg_color
                    self.lab3['font'] = (font_, font_size+10, 'bold')


                    self.lab4['bg'] = bg_color
                    self.lab4['fg'] = fg_color
                    self.lab4['font'] = ('Cousine', font_size)
                    self.lab4['selectbackground'] = bg_color
                    self.lab4['selectforeground'] = fg_color
                    self.lab4['highlightbackground'] = fg_color


                    color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                        color_rgb_activebackground[0] = 0
                    else:
                        color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

                    if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                        color_rgb_activebackground[1] = 0
                    else:
                        color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

                    if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                        color_rgb_activebackground[2] = 0
                    else:
                        color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

                    activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])





                def GlobalUpdate():
                    self.global_after = self.content.after(100, GlobalUpdate)


                self.master = master

                self.content = Frame(self.master)
                self.content.pack(fill=BOTH, expand=1)

                self.lab0 = Label(self.content, text='Информация')
                self.lab0.pack(anchor=NW, padx=5, pady=5)

                Separator(self.content, orient='horizontal')

                self.lab1 = Label(self.content, text='Информация о системе')
                self.lab1.pack(anchor=NW, padx=5, pady=5)

                name = ''
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_INFO','name.txt'), 'r', encoding='utf-8') as f:
                    name = f.read()

                ver = ''
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_INFO','ver.txt'), 'r', encoding='utf-8') as f:
                    ver = f.read()

                user = ''
                with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','user.txt'), 'r', encoding='utf-8') as f:
                    user = f.read()

                developers = ''
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_INFO','developers.txt'), 'r', encoding='utf-8') as f:
                    developers = f.read()

                self.lab2 = Label(self.content, text=f"Имя системы: {name}\nВерсия: {ver}", justify=LEFT)
                self.lab2.pack(anchor=NW, padx=5, pady=5)

                Separator(self.content, orient='horizontal')

                self.lab3 = Label(self.content, text='Разработчики', justify=LEFT)
                self.lab3.pack(anchor=NW, padx=5, pady=5)

                self.lab4 = Text(self.content, wrap='word', relief='flat', cursor='@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur', highlightthickness=0)
                self.lab4.pack(anchor=NW, padx=5, pady=5, fill=X)
                self.lab4.insert(END, developers)
                self.lab4['state'] = 'disable'


                theme_update()
                GlobalUpdate()

        class settings_user():
            def destroy(self):
                self.content.after_cancel(self.theme_after)
                self.content.after_cancel(self.global_after)
                self.content.destroy()
            def __init__(self, master, registry_path):
                self.registry_path = registry_path
                self.font_list = sorted(list(font.families()))

                def theme_update():
                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)
                    self.theme_after = self.content.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    self.font_list = sorted(list(font.families()))
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())

                    self.content['bg'] = bg_color

                    self.lab0['bg'] = bg_color
                    self.lab0['fg'] = fg_color
                    self.lab0['font'] = (font_, font_size+15, 'bold')


                    self.lab1['bg'] = bg_color
                    self.lab1['fg'] = fg_color
                    self.lab1['font'] = (font_, font_size+10, 'bold')


                    self.lab2['bg'] = bg_color
                    self.lab2['fg'] = fg_color
                    self.lab2['font'] = (font_, font_size)



                    self.lab3['bg'] = bg_color
                    self.lab3['fg'] = fg_color
                    self.lab3['font'] = (font_, font_size+10, 'bold')


                    self.lab4['bg'] = bg_color
                    self.lab4['fg'] = fg_color
                    self.lab4['font'] = ('Cousine', font_size)
                    self.lab4['selectbackground'] = bg_color
                    self.lab4['selectforeground'] = fg_color
                    self.lab4['highlightbackground'] = fg_color


                    color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                        color_rgb_activebackground[0] = 0
                    else:
                        color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

                    if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                        color_rgb_activebackground[1] = 0
                    else:
                        color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

                    if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                        color_rgb_activebackground[2] = 0
                    else:
                        color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

                    activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])





                def GlobalUpdate():
                    self.global_after = self.content.after(100, GlobalUpdate)


                self.master = master

                self.content = Frame(self.master)
                self.content.pack(fill=BOTH, expand=1)

                self.lab0 = Label(self.content, text='Информация')
                self.lab0.pack(anchor=NW, padx=5, pady=5)

                Separator(self.content, orient='horizontal')

                self.lab1 = Label(self.content, text='Информация о системе')
                self.lab1.pack(anchor=NW, padx=5, pady=5)

                name = ''
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_INFO','name.txt'), 'r', encoding='utf-8') as f:
                    name = f.read()

                ver = ''
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_INFO','ver.txt'), 'r', encoding='utf-8') as f:
                    ver = f.read()

                user = ''
                with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','user.txt'), 'r', encoding='utf-8') as f:
                    user = f.read()

                developers = ''
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_INFO','developers.txt'), 'r', encoding='utf-8') as f:
                    developers = f.read()

                self.lab2 = Label(self.content, text=f"Имя системы: {name}\nВерсия: {ver}", justify=LEFT)
                self.lab2.pack(anchor=NW, padx=5, pady=5)

                Separator(self.content, orient='horizontal')

                self.lab3 = Label(self.content, text='Разработчики', justify=LEFT)
                self.lab3.pack(anchor=NW, padx=5, pady=5)

                self.lab4 = Text(self.content, wrap='word', relief='flat', cursor='@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur', highlightthickness=0)
                self.lab4.pack(anchor=NW, padx=5, pady=5, fill=X)
                self.lab4.insert(END, developers)
                self.lab4['state'] = 'disable'


                theme_update()
                GlobalUpdate()

        def pers():
            self.settings_info_state = 0
            self.settings_user_state = 0
            if self.settings_pers_state != 1:
                self.settings_pers = settings_pers(self.frameright, registry_path=self.registry_path, homefolder=self.homefolder_path)
            if self.settings_info_state != 1:
                try:self.settings_info.destroy()
                except:pass
            self.settings_pers_state = 1
        def info_():
            self.settings_pers_state = 0
            self.settings_user_state = 0
            if self.settings_pers_state != 1:
                try:self.settings_pers.destroy()
                except:pass
            if self.settings_info_state != 1:
                self.settings_info = settings_info(self.frameright, registry_path=self.registry_path)
            self.settings_info_state = 1
        ListButton(self.frameleft, text='Информация', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','info.png'), size=35, command=info_).pack(fill=X)
        ListButton(self.frameleft, text='Персонализация', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','settings.png'), size=35, command=pers).pack(fill=X)
        ListButton(self.frameleft, text='Пользователи', image=Path(cwd, 'USERS.png'), size=35, command=empty).pack(fill=X)
        ListButton(self.frameleft, text='Локальные диски', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','HDD_ICONS','hdd.png'), size=35, command=empty).pack(fill=X)

        Separator(self.root, orient='vertical')

        self.frameright = CTkScrollableFrame(self.root, width=300, corner_radius=0)
        self.frameright.pack(fill=BOTH, side=LEFT, expand=1)

        if fileopen.lower() == 'personalization':
            pers()
        elif fileopen.lower() == 'information':
            info_()


        #self.root1.bind('<Map>', self.root1.center)

        theme_update()
App()
