from MaxOSTkinter import (
                            MaxOSTk,
                            DialogWin,
                            WhatDialogWin,
                            LabelButtonSystem,
                            ListButton,
                            Separator,
                            empty,
                            ColorDialogWin,
                            EntryAuto,
                            MaxOSListbox,
                            MaxOSTk2
                        )
import datetime
from tkinter import (
                        Frame,
                        Label,
                        Toplevel,
                        BOTH,
                        Y,
                        X,
                        NW,
                        N,
                        SW,
                        S,
                        W,
                        E,
                        NE,
                        LEFT,
                        RIGHT,
                        TOP,
                        BOTTOM,
                        Menu,
                        font,
                        END,
                        Listbox
                    )
import os
import sys
import shutil
from pathlib import Path
'''
def Path(*path):
    if type(path) == tuple:
        path1 = os.sep.join(path)
        if sys.platform == 'win32':
            path1 = path1.replace('\\', '/')

        return str(path1)
    else:
        if sys.platform == 'win32':
            path1 = path1.replace('\\', '/')
        return str(path1)
    '''

from threading import Thread
from customtkinter import CTkLabel, CTkFrame, CTkComboBox, CTkSlider, CTkScrollableFrame, CTkScrollbar
from PIL import Image, ImageTk, ImageColor, UnidentifiedImageError
import psutil
import time

from random import randint

from MaxOSCode16 import ConvertFromMaxOSCode16, ConvertToMaxOSCode16


sys.path.append(Path('MaxOS','!OSX'))

from Components.RunProgram import run_program

hdd_word = ''
with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_INFO','hdd_word.txt'), 'r', encoding='utf-8') as hf:
    hdd_word = hf.read()

registry_path = ''
with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','registry_path.txt'), 'r', encoding='utf-8') as hf:
    registry_path = hf.read()

homefolder = ''
with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'r', encoding='utf-8') as hf:
    homefolder = hf.read()

'''
if os.path.isdir(Path(registry_path, 'PROGRAMS', 'FILE_MANAGER')):
    pass
else:
    os.mkdir(Path(registry_path, 'PROGRAMS', 'FILE_MANAGER'))
    os.mkdir(Path(registry_path, 'PROGRAMS', 'FILE_MANAGER','IMAGE_FILE'))
'''

def get_hdd(path):
    return f"{path.split(':')[0]}:{os.sep}"

def folder_size(path='.'):
    total = 0
    for entry in os.scandir(path):
        if entry.is_file():
            total += entry.stat().st_size
        elif entry.is_dir():
            total += folder_size(entry.path)
    return total

def folder_size_elements(path='.'):
    elements = []
    for entry in os.scandir(path):
        if entry.is_file():
            elements.append('1')
        elif entry.is_dir():
            elements.extend(folder_size_elements(entry.path))
            elements.append('1')
    return elements

class App():
    def __init__(self):
        def theme_update():
            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)
            self.theme_after = self.root1.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())

            color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                color_rgb_activebackground[0] = 0
            else:
                color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

            if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                color_rgb_activebackground[1] = 0
            else:
                color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

            if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                color_rgb_activebackground[2] = 0
            else:
                color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

            activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])


            #self.frameleft.configure(fg_color=bg_color)
            #self.frameleft.configure(scrollbar_fg_color=bg_color)
            #self.frameleft.configure(scrollbar_button_color=bg_color)
            #self.frameleft.configure(scrollbar_button_hover_color=selectbg)

            self.frameright.configure(fg_color=bg_color)
            #self.frameright.configure(scrollbar_fg_color=bg_color)
            #self.frameright.configure(scrollbar_button_color=bg_color)
            #self.frameright.configure(scrollbar_button_hover_color=selectbg)

            self.frame_main['bg'] = bg_color

            self.frame_file_man['bg'] = bg_color

            self.frame_path['bg'] = bg_color

            self.listbox['bg'] = bg_color
            self.listbox['fg'] = fg_color
            self.listbox['selectbackground'] = selectbg
            self.listbox['selectforeground'] = fg_color
            self.listbox['font'] = ('Cousine', font_size+3)
            self.listbox['highlightbackground'] = bg_color

            self.frame_info.configure(fg_color=bg_color)
            self.frame_info.configure(scrollbar_fg_color=bg_color)
            self.frame_info.configure(scrollbar_button_color=bg_color)
            self.frame_info.configure(scrollbar_button_hover_color=selectbg)

            self.scrollbar1.configure(fg_color=bg_color)
            self.scrollbar1.configure(button_color=bg_color)
            self.scrollbar1.configure(button_hover_color=selectbg)

            self.lab_not_found['bg'] = bg_color
            self.lab_not_found['fg'] = fg_color
            self.lab_not_found['font'] = (font_, font_size+3)

            self.lab_empty_folder['bg'] = bg_color
            self.lab_empty_folder['fg'] = fg_color
            self.lab_empty_folder['font'] = (font_, font_size+3)

        def exitapp():
            try:self.root1.after_cancel(self.theme_after)
            except:pass
            try:self.root1.after_cancel(self.global_after)
            except:pass
            self.root1.ExitDestroy()
        self.registry_path = ''
        with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','registry_path.txt'), 'r', encoding='utf-8') as hf:
            self.registry_path = hf.read()
        if sys.platform == 'win32':self.root1 = MaxOSTk2(exitfunc=exitapp, icon=Path(cwd, 'icon.png'))
        elif sys.platform == 'darwin':self.root1 = MaxOSTk(exitfunc=exitapp, icon=Path(cwd, 'icon.png'))
        self.root1.title2('Файловый Менеджер MaxOS')
        self.root1.geometry('1000x750')
        self.root1.minsize(1000, 750)
        self.root = self.root1.content
        self.frameleft = CTkScrollableFrame(self.root, width=200, corner_radius=0)
        #self.frameleft.pack(fill=Y, side=LEFT)


        #Separator(self.root, orient='vertical')

        self.frame_main = Frame(self.root)
        self.frame_main.pack(fill=BOTH, side=LEFT, expand=1)

        self.frame_file_man = Frame(self.frame_main)
        self.frame_file_man.pack(side=LEFT, fill=BOTH, expand=1)

        Separator(self.frame_main, orient='vertical')

        self.information = ''
        self.information_state = 0

        self.this_computer = ''
        self.this_computer_state = 0

        class FolderInfo():
            def destroy(self):
                self.main.after_cancel(self.theme_after)
                self.icon.after_cancel(self.global_after2)
                self.main.after_cancel(self.global_after)
                self.main.destroy()
            def __init__(self, master, file, path, this_path):
                def theme_update():
                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)
                    self.theme_after = self.main.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())

                    color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                        color_rgb_activebackground[0] = 0
                    else:
                        color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

                    if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                        color_rgb_activebackground[1] = 0
                    else:
                        color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

                    if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                        color_rgb_activebackground[2] = 0
                    else:
                        color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

                    activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])


                    #self.frameleft.configure(fg_color=bg_color)
                    #self.frameleft.configure(scrollbar_fg_color=bg_color)
                    #self.frameleft.configure(scrollbar_button_color=bg_color)
                    #self.frameleft.configure(scrollbar_button_hover_color=selectbg)

                    #self.frameright.configure(fg_color=bg_color)
                    #self.frameright.configure(scrollbar_fg_color=bg_color)
                    #self.frameright.configure(scrollbar_button_color=bg_color)
                    #self.frameright.configure(scrollbar_button_hover_color=selectbg)

                    self.main['bg'] = bg_color
                    self.icon['bg'] = bg_color

                    self.type['bg'] = bg_color
                    self.type['fg'] = fg_color
                    self.type['font'] = (font_, font_size-3)

                    self.name['bg'] = bg_color
                    self.name['fg'] = fg_color
                    self.name['font'] = (font_, font_size-3)

                    self.path['bg'] = bg_color
                    self.path['fg'] = fg_color
                    self.path['font'] = (font_, font_size-3)

                    self.size['bg'] = bg_color
                    self.size['fg'] = fg_color
                    self.size['font'] = (font_, font_size-3)

                    self.elements1['bg'] = bg_color
                    self.elements1['fg'] = fg_color
                    self.elements1['font'] = (font_, font_size-3)

                    self.create_date['bg'] = bg_color
                    self.create_date['fg'] = fg_color
                    self.create_date['font'] = (font_, font_size-3)

                def GlobalUpdate():
                    self.global_after = self.main.after(500, GlobalUpdate)

                    def check_size():
                        '''
                        size = 0
                        for dirpath, dirnames, filenames in os.walk(Path(path, file)):
                            for f in filenames:
                                fp = Path(dirpath, f)
                                size += os.path.getsize(fp)
                        '''
                        size = folder_size(Path(path, file))

                        if size == 0:
                            self.size['text'] = f"Размер: {size} байт"
                        else:
                            if size >= 1000 and size < 1000**2 and size < 1000**3 and size < 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000)} килобайт"
                            elif size >= 1000**2 and size < 1000**3 and size < 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000**2)} мегабайт"
                            elif size >= 1000**3 and size < 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000**3)} гигабайт"
                            elif size >= 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000**4)} терабайт"
                            else:
                                self.size['text'] = f"Размер: {size} байт"
                    Thread(target=check_size, daemon=1).start()

                    def check_elements():
                        '''
                        elements = []
                        for dirpath, dirnames, filenames in os.walk(Path(path, file)):
                            for f in filenames:
                                fp = Path(dirpath, f)
                                elements.append(fp)
                            for d in dirnames:
                                dp = Path(dirpath, d)
                                elements.append(dp)
                        '''
                        self.elements1['text'] = f"Кол-во элементов: {len(folder_size_elements(Path(path, file)))}"
                        #self.elements1['text'] = f"Кол-во элементов: {len(elements)}"
                    Thread(target=check_elements, daemon=1).start()

                def GlobalUpdate2():
                    self.global_after2 = self.icon.after(100, GlobalUpdate2)

                    def check_files():
                        dir1 = os.listdir(Path(path, file))
                        dir1 = len(dir1)
                        time.sleep(0.1)
                        dir2 = os.listdir(Path(path, file))
                        dir2 = len(dir2)

                        if dir1 != dir2:
                            self.size['text'] = f"Размер: Вычисление..."
                            self.elements1['text'] = f"Кол-во элементов: Вычисление..."
                            if len(os.listdir(Path(path, file))) == 0:
                                self.image = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','Folder.png'))
                                self.image = self.image.resize((100, 100), Image.ANTIALIAS)
                                self.image = ImageTk.PhotoImage(self.image)
                            else:
                                self.image = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','Folder2.png'))
                                self.image = self.image.resize((100, 100), Image.ANTIALIAS)
                                self.image = ImageTk.PhotoImage(self.image)

                            self.icon.image = self.image
                            self.icon['image'] = self.icon.image
                    Thread(target=check_files, daemon=1).start()
                self.main = Frame(master)
                self.main.pack(fill=BOTH, expand=1)

                if len(os.listdir(Path(path, file))) == 0:
                    self.image = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','Folder.png'))
                    self.image = self.image.resize((100, 100), Image.ANTIALIAS)
                    self.image = ImageTk.PhotoImage(self.image)
                else:
                    self.image = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','Folder2.png'))
                    self.image = self.image.resize((100, 100), Image.ANTIALIAS)
                    self.image = ImageTk.PhotoImage(self.image)

                self.icon = Label(self.main)
                self.icon.pack()
                self.icon.image = self.image
                self.icon['image'] = self.icon.image

                self.type = Label(self.main, text=f"Тип: Папка")
                self.type.pack(anchor=NW)

                self.name = Label(self.main, text=f"Имя: {file}")
                self.name.pack(anchor=NW)

                if path == '':
                    path1 = f"{hdd_word}{os.sep}"
                else:
                    if len(path) > 30:
                        path1 = f"...{os.sep}{os.path.split(path)[1]}"
                    else:
                        path1 = path

                self.path = Label(self.main, text=f"Путь: {path1}", justify='left')
                self.path.pack(anchor=NW)

                Separator(self.main, orient='horizontal')

                self.size = Label(self.main, text=f"Размер: Вычисление...")
                self.size.pack(anchor=NW)

                self.elements1 = Label(self.main, text=f"Кол-во элементов: Вычисление...")
                self.elements1.pack(anchor=NW)

                self.create_date = Label(self.main, text=f"Дата создания: {datetime.datetime.fromtimestamp(os.path.getctime(Path(path, file))).strftime('%d/%m/%Y %H:%M')}")
                self.create_date.pack(anchor=NW)

                Separator(self.main, orient='horizontal')

                if str(this_path) != str(Path(path, file)):ListButton(self.main, text='Открыть', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                ListButton(self.main, text='Добавить ярлык', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=lambda: run_program(D=Path('MaxOS','!SystemPrograms'), F='CreateShortcut.prog', fileopen=Path(path, file)), fontsize=10).pack(fill=X, anchor=NW, pady=5)
                ListButton(self.main, text='Копировать', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                if str(this_path) != str(Path(path, file)):ListButton(self.main, text='Дублировать', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                if str(this_path) != str(Path(path, file)):ListButton(self.main, text='Переименовать', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                if str(this_path) != str(Path(path, file)):ListButton(self.main, text='Переместить', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                if str(this_path) != str(Path(path, file)):ListButton(self.main, text='Удалить', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                if str(this_path) != str(Path(path, file)):ListButton(self.main, text='Переместить в мусорку', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)


                theme_update()
                GlobalUpdate()
                GlobalUpdate2()

        class ProgramInfo():
            def destroy(self):
                self.main.after_cancel(self.theme_after)
                self.main.after_cancel(self.global_after)
                self.main.destroy()
            def __init__(self, master, file, path, this_path):
                def theme_update():
                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)
                    self.theme_after = self.main.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())

                    color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                        color_rgb_activebackground[0] = 0
                    else:
                        color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

                    if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                        color_rgb_activebackground[1] = 0
                    else:
                        color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

                    if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                        color_rgb_activebackground[2] = 0
                    else:
                        color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

                    activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])


                    #self.frameleft.configure(fg_color=bg_color)
                    #self.frameleft.configure(scrollbar_fg_color=bg_color)
                    #self.frameleft.configure(scrollbar_button_color=bg_color)
                    #self.frameleft.configure(scrollbar_button_hover_color=selectbg)

                    #self.frameright.configure(fg_color=bg_color)
                    #self.frameright.configure(scrollbar_fg_color=bg_color)
                    #self.frameright.configure(scrollbar_button_color=bg_color)
                    #self.frameright.configure(scrollbar_button_hover_color=selectbg)

                    self.main['bg'] = bg_color
                    self.icon['bg'] = bg_color

                    self.type['bg'] = bg_color
                    self.type['fg'] = fg_color
                    self.type['font'] = (font_, font_size-3)

                    self.name['bg'] = bg_color
                    self.name['fg'] = fg_color
                    self.name['font'] = (font_, font_size-3)

                    self.path['bg'] = bg_color
                    self.path['fg'] = fg_color
                    self.path['font'] = (font_, font_size-3)

                    self.size['bg'] = bg_color
                    self.size['fg'] = fg_color
                    self.size['font'] = (font_, font_size-3)

                    self.elements1['bg'] = bg_color
                    self.elements1['fg'] = fg_color
                    self.elements1['font'] = (font_, font_size-3)

                    self.create_date['bg'] = bg_color
                    self.create_date['fg'] = fg_color
                    self.create_date['font'] = (font_, font_size-3)

                def GlobalUpdate():
                    self.global_after = self.main.after(500, GlobalUpdate)


                    def check_size():
                        '''
                        size = 0
                        for dirpath, dirnames, filenames in os.walk(Path(path, file)):
                            for f in filenames:
                                fp = Path(dirpath, f)
                                size += os.path.getsize(fp)
                        '''
                        size = folder_size(Path(path, file))

                        if size == 0:
                            self.size['text'] = f"Размер: {size} байт"
                        else:
                            if size >= 1000 and size < 1000**2 and size < 1000**3 and size < 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000)} килобайт"
                            elif size >= 1000**2 and size < 1000**3 and size < 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000**2)} мегабайт"
                            elif size >= 1000**3 and size < 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000**3)} гигабайт"
                            elif size >= 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000**4)} терабайт"
                            else:
                                self.size['text'] = f"Размер: {size} байт"
                    Thread(target=check_size, daemon=1).start()

                    def check_elements():
                        '''
                        elements = []
                        for dirpath, dirnames, filenames in os.walk(Path(path, file)):
                            for f in filenames:
                                fp = Path(dirpath, f)
                                elements.append(fp)
                            for d in dirnames:
                                dp = Path(dirpath, d)
                                elements.append(dp)
                        '''
                        self.elements1['text'] = f"Кол-во элементов: {len(folder_size_elements(Path(path, file)))}"
                        #self.elements1['text'] = f"Кол-во элементов: {len(elements)}"
                    Thread(target=check_elements, daemon=1).start()

                self.main = Frame(master)
                self.main.pack(fill=BOTH, expand=1)

                try:
                    self.image = Image.open(Path(path, file, 'icon.png'))
                    self.image = self.image.resize((100, 100), Image.ANTIALIAS)
                    self.image = ImageTk.PhotoImage(self.image)
                except:
                    self.image = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','NoImage.png'))
                    self.image = self.image.resize((100, 100), Image.ANTIALIAS)
                    self.image = ImageTk.PhotoImage(self.image)

                self.icon = Label(self.main)
                self.icon.pack()
                self.icon.image = self.image
                self.icon['image'] = self.icon.image

                self.type = Label(self.main, text=f"Тип: Программа")
                self.type.pack(anchor=NW)

                name1 = ''
                if os.path.isfile(Path(path, file, 'name.txt')):
                    with open(Path(path, file, 'name.txt'), 'r', encoding='utf-8') as f:
                        name1 = f.read()
                else:
                    name1 = os.path.splitext(file)[0]

                self.name = Label(self.main, text=f"Имя: {name1}")
                self.name.pack(anchor=NW)

                if path == '':
                    path1 = f"{hdd_word}{os.sep}"
                else:
                    if len(path) > 30:
                        path1 = f"...{os.sep}{os.path.split(path)[1]}"
                    else:
                        path1 = path

                self.path = Label(self.main, text=f"Путь: {path1}", justify='left')
                self.path.pack(anchor=NW)

                Separator(self.main, orient='horizontal')

                self.size = Label(self.main, text=f"Размер: Вычисление...")
                self.size.pack(anchor=NW)

                self.elements1 = Label(self.main, text=f"Кол-во элементов: Вычисление...")
                self.elements1.pack(anchor=NW)

                self.create_date = Label(self.main, text=f"Дата создания: {datetime.datetime.fromtimestamp(os.path.getctime(Path(path, file))).strftime('%d/%m/%Y %H:%M')}")
                self.create_date.pack(anchor=NW)

                Separator(self.main, orient='horizontal')

                if str(this_path) != str(Path(path, file)):ListButton(self.main, text='Открыть', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                ListButton(self.main, text='Добавить ярлык', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=lambda: run_program(D=Path('MaxOS','!SystemPrograms'), F='CreateShortcut.prog', fileopen=Path(path, file)), fontsize=10).pack(fill=X, anchor=NW, pady=5)
                ListButton(self.main, text='Копировать', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                if str(this_path) != str(Path(path, file)):ListButton(self.main, text='Дублировать', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                if str(this_path) != str(Path(path, file)):ListButton(self.main, text='Переименовать', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                if str(this_path) != str(Path(path, file)):ListButton(self.main, text='Переместить', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                if str(this_path) != str(Path(path, file)):ListButton(self.main, text='Удалить', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                if str(this_path) != str(Path(path, file)):ListButton(self.main, text='Переместить в мусорку', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)



                theme_update()
                GlobalUpdate()

        class FileInfo():
            def destroy(self):
                self.main.after_cancel(self.theme_after)
                self.icon.after_cancel(self.global_after2)
                self.main.after_cancel(self.global_after)
                self.main.destroy()
            def __init__(self, master, file, path, this_path):
                def theme_update():
                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)
                    self.theme_after = self.main.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())

                    color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                        color_rgb_activebackground[0] = 0
                    else:
                        color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

                    if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                        color_rgb_activebackground[1] = 0
                    else:
                        color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

                    if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                        color_rgb_activebackground[2] = 0
                    else:
                        color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

                    activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])


                    #self.frameleft.configure(fg_color=bg_color)
                    #self.frameleft.configure(scrollbar_fg_color=bg_color)
                    #self.frameleft.configure(scrollbar_button_color=bg_color)
                    #self.frameleft.configure(scrollbar_button_hover_color=selectbg)

                    #self.frameright.configure(fg_color=bg_color)
                    #self.frameright.configure(scrollbar_fg_color=bg_color)
                    #self.frameright.configure(scrollbar_button_color=bg_color)
                    #self.frameright.configure(scrollbar_button_hover_color=selectbg)

                    self.main['bg'] = bg_color
                    self.icon['bg'] = bg_color

                    self.type['bg'] = bg_color
                    self.type['fg'] = fg_color
                    self.type['font'] = (font_, font_size-3)

                    self.name['bg'] = bg_color
                    self.name['fg'] = fg_color
                    self.name['font'] = (font_, font_size-3)

                    self.path['bg'] = bg_color
                    self.path['fg'] = fg_color
                    self.path['font'] = (font_, font_size-3)

                    self.size['bg'] = bg_color
                    self.size['fg'] = fg_color
                    self.size['font'] = (font_, font_size-3)

                    self.create_date['bg'] = bg_color
                    self.create_date['fg'] = fg_color
                    self.create_date['font'] = (font_, font_size-3)

                    self.open_in_program_lbl['bg'] = bg_color
                    self.open_in_program_lbl['fg'] = fg_color
                    self.open_in_program_lbl['font'] = (font_, font_size-3)

                def GlobalUpdate():
                    self.global_after = self.main.after(500, GlobalUpdate)

                    def check_size():
                        size = 0
                        size += os.path.getsize(Path(path, file))

                        if size == 0:
                            self.size['text'] = f"Размер: {size} байт"
                        else:
                            if size >= 1000 and size < 1000**2 and size < 1000**3 and size < 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000)} килобайт"
                            elif size >= 1000**2 and size < 1000**3 and size < 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000**2)} мегабайт"
                            elif size >= 1000**3 and size < 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000**3)} гигабайт"
                            elif size >= 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000**4)} терабайт"
                            else:
                                self.size['text'] = f"Размер: {size} байт"
                    Thread(target=check_size, daemon=1).start()

                def GlobalUpdate2():
                    self.global_after2 = self.icon.after(100, GlobalUpdate2)

                    def check_files():
                        size1 = os.path.getsize(Path(path, file))
                        time.sleep(0.1)
                        size2 = os.path.getsize(Path(path, file))

                        if 1:
                            image1 = Image.open(Path(path, file))
                            image2 = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'))
                            image2 = image2.resize((image1.size[0], image1.size[0]), Image.ANTIALIAS)

                            image2.paste(image1, (0, 0))

                            image2 = image2.resize((100, 100), Image.ANTIALIAS)

                            self.image = ImageTk.PhotoImage(image2)

                            self.icon.image = self.image
                            self.icon['image'] = self.icon.image
                    if self.type == 'image':
                        Thread(target=check_files, daemon=1).start()
                self.main = Frame(master)
                self.main.pack(fill=BOTH, expand=1)

                self.registry_path = ''
                with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','registry_path.txt'), 'r', encoding='utf-8') as hf:
                    self.registry_path = hf.read()

                for i in os.listdir(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST')):
                    if i[0] != '.' or i[0] != '!':
                        name = ''
                        with open(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST', i,'name.txt'), 'r', encoding='utf-8') as f:
                            name = f.read()

                        if '|' in name:
                            name1 = name.split()
                            if os.path.splitext(file)[1].lower() in name1:
                                self.type = ''
                                with open(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST', i,'type.txt'), 'r', encoding='utf-8') as f:
                                    self.type = f.read()

                                self.icon_file = ''
                                with open(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST', i,'icon_file.txt'), 'r', encoding='utf-8') as f:
                                    self.icon_file = f.read()

                                self.open_in_program = ''
                                with open(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST',i,'open_in_program.txt'), 'r', encoding='utf-8') as f:
                                    self.open_in_program = f.read()

                                self.ext_folder = Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST',i)
                        else:
                            if os.path.splitext(file)[1].lower() == name:
                                self.type = ''
                                with open(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST', i,'type.txt'), 'r', encoding='utf-8') as f:
                                    self.type = f.read()

                                self.icon_file = ''
                                with open(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST', i,'icon_file.txt'), 'r', encoding='utf-8') as f:
                                    self.icon_file = f.read()

                                self.open_in_program = ''
                                with open(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST',i,'open_in_program.txt'), 'r', encoding='utf-8') as f:
                                    self.open_in_program = f.read()

                                self.ext_folder = Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST',i)


                if self.type == 'image':
                    try:
                        image1 = Image.open(Path(path, file))
                        if image1.size[0] > image1.size[1]:
                            image2 = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'))
                            image2 = image2.resize((image1.size[0], image1.size[0]), Image.ANTIALIAS)
                        elif image1.size[0] < image1.size[1]:
                            image2 = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'))
                            image2 = image2.resize((image1.size[1], image1.size[1]), Image.ANTIALIAS)
                        else:
                            image2 = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'))
                            image2 = image2.resize((image1.size[0], image1.size[0]), Image.ANTIALIAS)

                        image2.paste(image1, (0, 0))

                        image2 = image2.resize((100, 100), Image.ANTIALIAS)

                        self.image = ImageTk.PhotoImage(image2)
                    except:
                        import traceback
                        print(traceback.format_exc())
                        try:
                            self.image = Image.open(self.icon_file)
                            self.image = self.image.resize((100, 100), Image.ANTIALIAS)
                            self.image = ImageTk.PhotoImage(self.image)
                        except:
                            self.image = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','NoImage.png'))
                            self.image = self.image.resize((100, 100), Image.ANTIALIAS)
                            self.image = ImageTk.PhotoImage(self.image)
                else:
                    try:
                        self.image = Image.open(self.icon_file)
                        self.image = self.image.resize((100, 100), Image.ANTIALIAS)
                        self.image = ImageTk.PhotoImage(self.image)
                    except:
                        self.image = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','NoImage.png'))
                        self.image = self.image.resize((100, 100), Image.ANTIALIAS)
                        self.image = ImageTk.PhotoImage(self.image)

                self.icon = Label(self.main)
                self.icon.pack()
                self.icon.image = self.image
                self.icon['image'] = self.icon.image

                self.type = Label(self.main, text=f"Тип: {self.type.lower().title()}")
                self.type.pack(anchor=NW)

                self.name = Label(self.main, text=f"Имя: {file}")
                self.name.pack(anchor=NW)

                if path == '':
                    path1 = f"{hdd_word}{os.sep}"
                else:
                    if len(path) > 30:
                        path1 = f"...{os.sep}{os.path.split(path)[1]}"
                    else:
                        path1 = path

                self.path = Label(self.main, text=f"Путь: {path1}", justify='left')
                self.path.pack(anchor=NW)

                Separator(self.main, orient='horizontal')

                self.size = Label(self.main, text=f"Размер: Вычисление...")
                self.size.pack(anchor=NW)

                self.create_date = Label(self.main, text=f"Дата создания: {datetime.datetime.fromtimestamp(os.path.getctime(Path(path, file))).strftime('%d/%m/%Y %H:%M')}")
                self.create_date.pack(anchor=NW)

                if len(self.open_in_program) > 36:
                    open_in_program = f"...{os.sep}{os.path.split(path)[1]}"
                else:
                    open_in_program = self.open_in_program

                self.open_in_program_lbl = Label(self.main, text=f"Программа для открытия:\n{open_in_program}", justify='left')
                self.open_in_program_lbl.pack(anchor=NW)
                LabelButtonSystem(self.main, text='Изменить').pack(fill=X, anchor=NW, pady=5)

                Separator(self.main, orient='horizontal')

                try:
                    class ButtonContextMenu():
                        def __init__(self,main=self.main, i='', ext_folder=self.ext_folder, path=Path(path, file)):
                            self.main = main
                            self.ext_folder = ext_folder
                            self.i = i

                            self.name = ''
                            with open(Path(self.ext_folder,'CONTEXT_MENU',self.i,'name.txt'), 'r', encoding='utf-8') as f:
                                self.name = f.read()

                            self.command = ''
                            with open(Path(self.ext_folder,'CONTEXT_MENU',self.i,'command.txt'), 'r', encoding='utf-8') as f:
                                with open(Path(f.read()), 'r', encoding='utf-8') as c:
                                    self.command = c.read()

                            self.icon = ''
                            with open(Path(self.ext_folder,'CONTEXT_MENU',self.i,'icon_file.txt'), 'r', encoding='utf-8') as f:
                                self.icon = f.read().lower()

                            if self.icon == 'none':
                                self.icon = Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png')

                            #DialogWin(self.main, text=path)

                            def run():
                                try:
                                    run_program(D=os.path.split(self.command)[0], F=os.path.split(self.command)[1], fileopen=path)
                                except:
                                    pass

                            if len(self.name) > 20:
                                text2 = []
                                for i in range(len(self.name)):
                                    if i <= 17:
                                        text2.append(self.name[i])

                                text2 = ''.join(text2)
                                text2 = f"{text2}..."
                            else:
                                text2 = self.name

                            ListButton(self.main, text=text2, image=self.icon, size=20, command=run, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                    for i in sorted(os.listdir(Path(self.ext_folder,'CONTEXT_MENU'))):
                        ButtonContextMenu(i=i)

                except:
                    import traceback
                    DialogWin(self.main, text=traceback.format_exc())
                ListButton(self.main, text='Добавить ярлык', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=lambda: run_program(D=Path('MaxOS','!SystemPrograms'), F='CreateShortcut.prog', fileopen=Path(path, file)), fontsize=10).pack(fill=X, anchor=NW, pady=5)
                ListButton(self.main, text='Копировать', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                ListButton(self.main, text='Дублировать', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                ListButton(self.main, text='Переименовать', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                ListButton(self.main, text='Переместить', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                ListButton(self.main, text='Удалить', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                ListButton(self.main, text='Переместить в мусорку', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)


                theme_update()
                GlobalUpdate()
                GlobalUpdate2()

        class FileExtNoFoundInfo():
            def destroy(self):
                self.main.after_cancel(self.theme_after)
                self.icon.after_cancel(self.global_after2)
                self.main.after_cancel(self.global_after)
                self.main.destroy()
            def __init__(self, master, file, path, this_path):
                def theme_update():
                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)
                    self.theme_after = self.main.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())

                    color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                        color_rgb_activebackground[0] = 0
                    else:
                        color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

                    if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                        color_rgb_activebackground[1] = 0
                    else:
                        color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

                    if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                        color_rgb_activebackground[2] = 0
                    else:
                        color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

                    activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])


                    #self.frameleft.configure(fg_color=bg_color)
                    #self.frameleft.configure(scrollbar_fg_color=bg_color)
                    #self.frameleft.configure(scrollbar_button_color=bg_color)
                    #self.frameleft.configure(scrollbar_button_hover_color=selectbg)

                    #self.frameright.configure(fg_color=bg_color)
                    #self.frameright.configure(scrollbar_fg_color=bg_color)
                    #self.frameright.configure(scrollbar_button_color=bg_color)
                    #self.frameright.configure(scrollbar_button_hover_color=selectbg)

                    self.main['bg'] = bg_color
                    self.icon['bg'] = bg_color

                    self.type['bg'] = bg_color
                    self.type['fg'] = fg_color
                    self.type['font'] = (font_, font_size-3)

                    self.name['bg'] = bg_color
                    self.name['fg'] = fg_color
                    self.name['font'] = (font_, font_size-3)

                    self.path['bg'] = bg_color
                    self.path['fg'] = fg_color
                    self.path['font'] = (font_, font_size-3)

                    self.size['bg'] = bg_color
                    self.size['fg'] = fg_color
                    self.size['font'] = (font_, font_size-3)

                    self.create_date['bg'] = bg_color
                    self.create_date['fg'] = fg_color
                    self.create_date['font'] = (font_, font_size-3)

                def GlobalUpdate():
                    self.global_after = self.main.after(500, GlobalUpdate)

                    def check_size():
                        size = 0
                        size += os.path.getsize(Path(path, file))

                        if size == 0:
                            self.size['text'] = f"Размер: {size} байт"
                        else:
                            if size >= 1000 and size < 1000**2 and size < 1000**3 and size < 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000)} килобайт"
                            elif size >= 1000**2 and size < 1000**3 and size < 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000**2)} мегабайт"
                            elif size >= 1000**3 and size < 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000**3)} гигабайт"
                            elif size >= 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000**4)} терабайт"
                            else:
                                self.size['text'] = f"Размер: {size} байт"
                    Thread(target=check_size, daemon=1).start()

                def GlobalUpdate2():
                    self.global_after2 = self.icon.after(100, GlobalUpdate2)

                    def check_files():
                        dir1 = os.listdir(Path(path, file))
                        dir1 = len(dir1)
                        time.sleep(0.1)
                        dir2 = os.listdir(Path(path, file))
                        dir2 = len(dir2)

                        if dir1 != dir2:
                            self.size['text'] = f"Размер: Вычисление..."
                            self.elements1['text'] = f"Кол-во элементов: Вычисление..."
                            if len(os.listdir(Path(path, file))) == 0:
                                self.image = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','Folder.png'))
                                self.image = self.image.resize((100, 100), Image.ANTIALIAS)
                                self.image = ImageTk.PhotoImage(self.image)
                            else:
                                self.image = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','Folder2.png'))
                                self.image = self.image.resize((100, 100), Image.ANTIALIAS)
                                self.image = ImageTk.PhotoImage(self.image)

                            self.icon.image = self.image
                            self.icon['image'] = self.icon.image
                    #Thread(target=check_files, daemon=1).start()
                self.main = Frame(master)
                self.main.pack(fill=BOTH, expand=1)

                self.registry_path = ''
                with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','registry_path.txt'), 'r', encoding='utf-8') as hf:
                    self.registry_path = hf.read()


                self.image = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','NoImage.png'))
                self.image = self.image.resize((100, 100), Image.ANTIALIAS)
                self.image = ImageTk.PhotoImage(self.image)

                self.icon = Label(self.main)
                self.icon.pack()
                self.icon.image = self.image
                self.icon['image'] = self.icon.image

                self.type = Label(self.main, text=f"Тип: Неизвестен")
                self.type.pack(anchor=NW)

                self.name = Label(self.main, text=f"Имя: {file}")
                self.name.pack(anchor=NW)

                if path == '':
                    path1 = f"{hdd_word}{os.sep}"
                else:
                    if len(path) > 30:
                        path1 = f"...{os.sep}{os.path.split(path)[1]}"
                    else:
                        path1 = path

                self.path = Label(self.main, text=f"Путь: {path1}", justify='left')
                self.path.pack(anchor=NW)

                Separator(self.main, orient='horizontal')

                self.size = Label(self.main, text=f"Размер: Вычисление...")
                self.size.pack(anchor=NW)

                self.create_date = Label(self.main, text=f"Дата создания: {datetime.datetime.fromtimestamp(os.path.getctime(Path(path, file))).strftime('%d/%m/%Y %H:%M')}")
                self.create_date.pack(anchor=NW)

                Separator(self.main, orient='horizontal')

                ListButton(self.main, text='Переименовать', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                ListButton(self.main, text='Переместить', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                ListButton(self.main, text='Копировать', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                ListButton(self.main, text='Дублирование', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                ListButton(self.main, text='Удаление', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)
                ListButton(self.main, text='Переместить в мусорку', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=empty, fontsize=10).pack(fill=X, anchor=NW, pady=5)


                theme_update()
                GlobalUpdate()
                GlobalUpdate2()

        class HddInfo():
            def destroy(self):
                self.main.after_cancel(self.theme_after)
                self.main.after_cancel(self.global_after)
                self.main.destroy()
            def __init__(self, master, file, path, this_path, hdd_info):
                def theme_update():
                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)
                    self.theme_after = self.main.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())

                    color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                        color_rgb_activebackground[0] = 0
                    else:
                        color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

                    if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                        color_rgb_activebackground[1] = 0
                    else:
                        color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

                    if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                        color_rgb_activebackground[2] = 0
                    else:
                        color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

                    activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])


                    #self.frameleft.configure(fg_color=bg_color)
                    #self.frameleft.configure(scrollbar_fg_color=bg_color)
                    #self.frameleft.configure(scrollbar_button_color=bg_color)
                    #self.frameleft.configure(scrollbar_button_hover_color=selectbg)

                    #self.frameright.configure(fg_color=bg_color)
                    #self.frameright.configure(scrollbar_fg_color=bg_color)
                    #self.frameright.configure(scrollbar_button_color=bg_color)
                    #self.frameright.configure(scrollbar_button_hover_color=selectbg)

                    self.main['bg'] = bg_color
                    self.icon['bg'] = bg_color

                    self.type['bg'] = bg_color
                    self.type['fg'] = fg_color
                    self.type['font'] = (font_, font_size-3)

                    self.name['bg'] = bg_color
                    self.name['fg'] = fg_color
                    self.name['font'] = (font_, font_size-3)

                    self.path['bg'] = bg_color
                    self.path['fg'] = fg_color
                    self.path['font'] = (font_, font_size-3)

                    self.size['bg'] = bg_color
                    self.size['fg'] = fg_color
                    self.size['font'] = (font_, font_size-3)

                    self.used['bg'] = bg_color
                    self.used['fg'] = fg_color
                    self.used['font'] = (font_, font_size-3)

                    self.free['bg'] = bg_color
                    self.free['fg'] = fg_color
                    self.free['font'] = (font_, font_size-3)

                    self.filesys['bg'] = bg_color
                    self.filesys['fg'] = fg_color
                    self.filesys['font'] = (font_, font_size-3)

                def GlobalUpdate():
                    self.global_after = self.main.after(500, GlobalUpdate)

                    size_total = int(psutil.disk_usage(hdd_info.mountpoint).total)
                    size_used = int(psutil.disk_usage(hdd_info.mountpoint).used)
                    size_free = int(psutil.disk_usage(hdd_info.mountpoint).free)

                    if size_total == 0:
                        size_total = f"{int(size_total)} байт"
                    else:
                        if size_total >= 1000 and size_total < 1000**2 and size_total < 1000**3 and size_total < 1000**4:
                            size_total = f"{int(size_total/1000)} килобайт"
                        elif size_total >= 1000**2 and size_total < 1000**3 and size_total < 1000**4:
                            size_total = f"{int(size_total/1000**2)} мегабайт"
                        elif size_total >= 1000**3 and size_total < 1000**4:
                            size_total = f"{int(size_total/1000**3)} гигабайт"
                        elif size_total >= 1000**4:
                            size_total = f"{int(size_total/1000**4)} терабайт"
                        else:
                            size_total = f"{int(size_total)} байт"

                    if size_used == 0:
                        size_used = f"{int(size_used)} байт"
                    else:
                        if size_used >= 1000 and size_used < 1000**2 and size_used < 1000**3 and size_used < 1000**4:
                            size_used = f"{int(size_used/1000)} килобайт"
                        elif size_used >= 1000**2 and size_used < 1000**3 and size_used < 1000**4:
                            size_used = f"{int(size_used/1000**2)} мегабайт"
                        elif size_used >= 1000**3 and size_used < 1000**4:
                            size_used = f"{int(size_used/1000**3)} гигабайт"
                        elif size_used >= 1000**4:
                            size_used = f"{int(size_used/1000**4)} терабайт"
                        else:
                            size_used = f"{int(size_used)} байт"

                    if size_free == 0:
                        size_free = f"{int(size_free)} байт"
                    else:
                        if size_free >= 1000 and size_free < 1000**2 and size_free < 1000**3 and size_free < 1000**4:
                            size_free = f"{int(size_free/1000)} килобайт"
                        elif size_free >= 1000**2 and size_free < 1000**3 and size_free < 1000**4:
                            size_free = f"{int(size_free/1000**2)} мегабайт"
                        elif size_free >= 1000**3 and size_free < 1000**4:
                            size_free = f"{int(size_free/1000**3)} гигабайт"
                        elif size_free >= 1000**4:
                            size_free = f"{int(size_free/1000**4)} терабайт"
                        else:
                            size_free = f"{int(size_free)} байт"

                    self.size['text'] = f"Размер: {size_total}"
                    self.used['text'] = f"Занято: {size_used}"
                    self.free['text'] = f"Свободно: {size_free}"
                self.main = Frame(master)
                self.main.pack(fill=BOTH, expand=1)


                self.image = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','HDD_ICONS','sys_hdd.png'))
                self.image = self.image.resize((100, 100), Image.ANTIALIAS)
                self.image = ImageTk.PhotoImage(self.image)

                self.icon = Label(self.main)
                self.icon.pack()
                self.icon.image = self.image
                self.icon['image'] = self.icon.image

                self.type = Label(self.main, text=f"Тип: Локальный диск")
                self.type.pack(anchor=NW)

                if sys.platform == 'win32':
                    self.name = Label(self.main, text=f"Имя: {hdd_info.mountpoint}")
                elif sys.platform == 'darwin':
                    if hdd_info.mountpoint == '/':
                        self.name = Label(self.main, text=f"Имя: Macintosh HD")
                    else:
                        self.name = Label(self.main, text=f"Имя: {os.path.split(hdd_info.mountpoint)[1]}")
                self.name.pack(anchor=NW)

                if len(path) > 15:
                    path1 = f"...{os.sep}{os.path.split(hdd_info.mountpoint)[1]}"
                else:
                    path1 = hdd_info.mountpoint

                self.path = Label(self.main, text=f"Точка подключения: {path1}", justify='left')
                self.path.pack(anchor=NW)

                Separator(self.main, orient='horizontal')

                self.size = Label(self.main, text=f"Размер: Вычисление...")
                self.size.pack(anchor=NW)

                self.used = Label(self.main, text=f"Занято: Вычисление...")
                self.used.pack(anchor=NW)

                self.free = Label(self.main, text=f"Свободно: Вычисление...")
                self.free.pack(anchor=NW)

                self.filesys = Label(self.main, text=f"Файловая система: {hdd_info.fstype}")
                self.filesys.pack(anchor=NW)

                Separator(self.main, orient='horizontal')

                if sys.platform == 'win32':ListButton(self.main, text='Добавить ярлык', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=lambda: run_program(D=Path('MaxOS','!SystemPrograms'), F='CreateShortcut.prog', fileopen=f"{hdd_info.mountpoint}\\"), fontsize=10).pack(fill=X, anchor=NW, pady=5)
                elif sys.platform == 'darwin':ListButton(self.main, text='Добавить ярлык', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=lambda: run_program(D=Path('MaxOS','!SystemPrograms'), F='CreateShortcut.prog', fileopen=f"{hdd_info.mountpoint}"), fontsize=10).pack(fill=X, anchor=NW, pady=5)


                theme_update()
                GlobalUpdate()

        class MaxOSInfo():
            def destroy(self):
                self.main.after_cancel(self.theme_after)
                self.main.after_cancel(self.global_after)
                self.main.destroy()
            def __init__(self, master, file, path, this_path):
                def theme_update():
                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)
                    self.theme_after = self.main.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())

                    color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                        color_rgb_activebackground[0] = 0
                    else:
                        color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

                    if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                        color_rgb_activebackground[1] = 0
                    else:
                        color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

                    if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                        color_rgb_activebackground[2] = 0
                    else:
                        color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

                    activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])


                    #self.frameleft.configure(fg_color=bg_color)
                    #self.frameleft.configure(scrollbar_fg_color=bg_color)
                    #self.frameleft.configure(scrollbar_button_color=bg_color)
                    #self.frameleft.configure(scrollbar_button_hover_color=selectbg)

                    #self.frameright.configure(fg_color=bg_color)
                    #self.frameright.configure(scrollbar_fg_color=bg_color)
                    #self.frameright.configure(scrollbar_button_color=bg_color)
                    #self.frameright.configure(scrollbar_button_hover_color=selectbg)

                    self.main['bg'] = bg_color
                    self.icon['bg'] = bg_color

                    self.type['bg'] = bg_color
                    self.type['fg'] = fg_color
                    self.type['font'] = (font_, font_size-3)

                    self.name['bg'] = bg_color
                    self.name['fg'] = fg_color
                    self.name['font'] = (font_, font_size-3)

                    self.size['bg'] = bg_color
                    self.size['fg'] = fg_color
                    self.size['font'] = (font_, font_size-3)

                    self.elements1['bg'] = bg_color
                    self.elements1['fg'] = fg_color
                    self.elements1['font'] = (font_, font_size-3)

                    self.create_date['bg'] = bg_color
                    self.create_date['fg'] = fg_color
                    self.create_date['font'] = (font_, font_size-3)

                def GlobalUpdate():
                    self.global_after = self.main.after(500, GlobalUpdate)

                    def check_size():
                        '''
                        size = 0
                        for dirpath, dirnames, filenames in os.walk(Path(path, file)):
                            for f in filenames:
                                fp = Path(dirpath, f)
                                size += os.path.getsize(fp)
                        '''
                        size = folder_size(Path(path, file))

                        if size == 0:
                            self.size['text'] = f"Размер: {size} байт"
                        else:
                            if size >= 1000 and size < 1000**2 and size < 1000**3 and size < 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000)} килобайт"
                            elif size >= 1000**2 and size < 1000**3 and size < 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000**2)} мегабайт"
                            elif size >= 1000**3 and size < 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000**3)} гигабайт"
                            elif size >= 1000**4:
                                self.size['text'] = f"Размер: {int(size/1000**4)} терабайт"
                            else:
                                self.size['text'] = f"Размер: {size} байт"
                    Thread(target=check_size, daemon=1).start()

                    def check_elements():
                        '''
                        elements = []
                        for dirpath, dirnames, filenames in os.walk(Path(path, file)):
                            for f in filenames:
                                fp = Path(dirpath, f)
                                elements.append(fp)
                            for d in dirnames:
                                dp = Path(dirpath, d)
                                elements.append(dp)
                        '''
                        self.elements1['text'] = f"Кол-во элементов: {len(folder_size_elements(Path(path, file)))}"
                        #self.elements1['text'] = f"Кол-во элементов: {len(elements)}"
                    Thread(target=check_elements, daemon=1).start()

                self.main = Frame(master)
                self.main.pack(fill=BOTH, expand=1)


                self.image = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SystemFolder.png'))
                self.image = self.image.resize((100, 100), Image.ANTIALIAS)
                self.image = ImageTk.PhotoImage(self.image)

                self.icon = Label(self.main)
                self.icon.pack()
                self.icon.image = self.image
                self.icon['image'] = self.icon.image

                self.type = Label(self.main, text=f"Тип: Папка с MaxOS")
                self.type.pack(anchor=NW)

                self.name = Label(self.main, text=f"Имя: MaxOS System ({hdd_word}{os.sep})")
                self.name.pack(anchor=NW)

                Separator(self.main, orient='horizontal')

                self.size = Label(self.main, text=f"Размер: Вычисление...")
                self.size.pack(anchor=NW)

                self.elements1 = Label(self.main, text=f"Кол-во элементов: Вычисление...")
                self.elements1.pack(anchor=NW)

                self.create_date = Label(self.main, text=f"Дата создания: {datetime.datetime.fromtimestamp(os.path.getctime(Path(path, file))).strftime('%d/%m/%Y %H:%M')}")
                self.create_date.pack(anchor=NW)

                Separator(self.main, orient='horizontal')

                ListButton(self.main, text='Добавить ярлык', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=lambda: run_program(D=Path('MaxOS','!SystemPrograms'), F='CreateShortcut.prog', fileopen='MS160722'), fontsize=10).pack(fill=X, anchor=NW, pady=5)



                theme_update()
                GlobalUpdate()

        class CDROMInfo():
            def destroy(self):
                self.main.after_cancel(self.theme_after)
                self.main.after_cancel(self.global_after)
                self.main.destroy()
            def __init__(self, master, file, path, this_path, hdd_info):
                def theme_update():
                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)
                    self.theme_after = self.main.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())

                    color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                        color_rgb_activebackground[0] = 0
                    else:
                        color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

                    if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                        color_rgb_activebackground[1] = 0
                    else:
                        color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

                    if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                        color_rgb_activebackground[2] = 0
                    else:
                        color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

                    activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])


                    #self.frameleft.configure(fg_color=bg_color)
                    #self.frameleft.configure(scrollbar_fg_color=bg_color)
                    #self.frameleft.configure(scrollbar_button_color=bg_color)
                    #self.frameleft.configure(scrollbar_button_hover_color=selectbg)

                    #self.frameright.configure(fg_color=bg_color)
                    #self.frameright.configure(scrollbar_fg_color=bg_color)
                    #self.frameright.configure(scrollbar_button_color=bg_color)
                    #self.frameright.configure(scrollbar_button_hover_color=selectbg)

                    self.main['bg'] = bg_color
                    self.icon['bg'] = bg_color

                    self.type['bg'] = bg_color
                    self.type['fg'] = fg_color
                    self.type['font'] = (font_, font_size-3)

                    self.name['bg'] = bg_color
                    self.name['fg'] = fg_color
                    self.name['font'] = (font_, font_size-3)

                    if os.path.isdir(hdd_info.mountpoint):
                        self.path['bg'] = bg_color
                        self.path['fg'] = fg_color
                        self.path['font'] = (font_, font_size-3)

                        self.size['bg'] = bg_color
                        self.size['fg'] = fg_color
                        self.size['font'] = (font_, font_size-3)

                        self.used['bg'] = bg_color
                        self.used['fg'] = fg_color
                        self.used['font'] = (font_, font_size-3)

                        self.free['bg'] = bg_color
                        self.free['fg'] = fg_color
                        self.free['font'] = (font_, font_size-3)

                        self.filesys['bg'] = bg_color
                        self.filesys['fg'] = fg_color
                        self.filesys['font'] = (font_, font_size-3)

                def GlobalUpdate():
                    self.global_after = self.main.after(500, GlobalUpdate)
                    if os.path.isdir(hdd_info.mountpoint):
                        size_total = int(psutil.disk_usage(hdd_info.mountpoint).total)
                        size_used = int(psutil.disk_usage(hdd_info.mountpoint).used)
                        size_free = int(psutil.disk_usage(hdd_info.mountpoint).free)

                        if size_total == 0:
                            size_total = f"{int(size_total)} байт"
                        else:
                            if size_total >= 1000 and size_total < 1000**2 and size_total < 1000**3 and size_total < 1000**4:
                                size_total = f"{int(size_total/1000)} килобайт"
                            elif size_total >= 1000**2 and size_total < 1000**3 and size_total < 1000**4:
                                size_total = f"{int(size_total/1000**2)} мегабайт"
                            elif size_total >= 1000**3 and size_total < 1000**4:
                                size_total = f"{int(size_total/1000**3)} гигабайт"
                            elif size_total >= 1000**4:
                                size_total = f"{int(size_total/1000**4)} терабайт"
                            else:
                                size_total = f"{int(size_total)} байт"

                        if size_used == 0:
                            size_used = f"{int(size_used)} байт"
                        else:
                            if size_used >= 1000 and size_used < 1000**2 and size_used < 1000**3 and size_used < 1000**4:
                                size_used = f"{int(size_used/1000)} килобайт"
                            elif size_used >= 1000**2 and size_used < 1000**3 and size_used < 1000**4:
                                size_used = f"{int(size_used/1000**2)} мегабайт"
                            elif size_used >= 1000**3 and size_used < 1000**4:
                                size_used = f"{int(size_used/1000**3)} гигабайт"
                            elif size_used >= 1000**4:
                                size_used = f"{int(size_used/1000**4)} терабайт"
                            else:
                                size_used = f"{int(size_used)} байт"

                        if size_free == 0:
                            size_free = f"{int(size_free)} байт"
                        else:
                            if size_free >= 1000 and size_free < 1000**2 and size_free < 1000**3 and size_free < 1000**4:
                                size_free = f"{int(size_free/1000)} килобайт"
                            elif size_free >= 1000**2 and size_free < 1000**3 and size_free < 1000**4:
                                size_free = f"{int(size_free/1000**2)} мегабайт"
                            elif size_free >= 1000**3 and size_free < 1000**4:
                                size_free = f"{int(size_free/1000**3)} гигабайт"
                            elif size_free >= 1000**4:
                                size_free = f"{int(size_free/1000**4)} терабайт"
                            else:
                                size_free = f"{int(size_free)} байт"

                        self.size['text'] = f"Размер: {size_total}"
                        self.used['text'] = f"Занято: {size_used}"
                        self.free['text'] = f"Свободно: {size_free}"
                self.main = Frame(master)
                self.main.pack(fill=BOTH, expand=1)


                self.image = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','cd_dvd.png'))
                self.image = self.image.resize((100, 100), Image.ANTIALIAS)
                self.image = ImageTk.PhotoImage(self.image)

                self.icon = Label(self.main)
                self.icon.pack()
                self.icon.image = self.image
                self.icon['image'] = self.icon.image

                self.type = Label(self.main, text=f"Тип: CD-ROM")
                self.type.pack(anchor=NW)

                if sys.platform == 'win32':
                    self.name = Label(self.main, text=f"Имя: {hdd_info.mountpoint}")
                elif sys.platform == 'darwin':
                    self.name = Label(self.main, text=f"Имя: {os.path.split(hdd_info.mountpoint)[1]}")
                self.name.pack(anchor=NW)

                if len(path) > 15:
                    path1 = f"...{os.sep}{os.path.split(hdd_info.mountpoint)[1]}"
                else:
                    path1 = hdd_info.mountpoint

                if os.path.isdir(hdd_info.mountpoint):
                    self.path = Label(self.main, text=f"Точка подключения: {path1}", justify='left')
                    self.path.pack(anchor=NW)

                    Separator(self.main, orient='horizontal')

                    self.size = Label(self.main, text=f"Размер: Вычисление...")
                    self.size.pack(anchor=NW)

                    self.used = Label(self.main, text=f"Занято: Вычисление...")
                    self.used.pack(anchor=NW)

                    self.free = Label(self.main, text=f"Свободно: Вычисление...")
                    self.free.pack(anchor=NW)

                    self.filesys = Label(self.main, text=f"Файловая система: {hdd_info.fstype}")
                    self.filesys.pack(anchor=NW)

                    Separator(self.main, orient='horizontal')

                if sys.platform == 'win32':ListButton(self.main, text='Добавить ярлык', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=lambda: run_program(D=Path('MaxOS','!SystemPrograms'), F='CreateShortcut.prog', fileopen=f"{hdd_info.mountpoint}\\"), fontsize=10).pack(fill=X, anchor=NW, pady=5)
                elif sys.platform == 'darwin':ListButton(self.main, text='Добавить ярлык', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=lambda: run_program(D=Path('MaxOS','!SystemPrograms'), F='CreateShortcut.prog', fileopen=f"{hdd_info.mountpoint}"), fontsize=10).pack(fill=X, anchor=NW, pady=5)
                def open_disk():
                    import ctypes
                    ctypes.windll.WINMM.mciSendStringW(u"set cdaudio door open", None, 0, None)
                if sys.platform == 'win32':ListButton(self.main, text='Открыть лоток', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=open_disk, fontsize=10).pack(fill=X, anchor=NW, pady=5)



                theme_update()
                GlobalUpdate()

        class ThisPCInfo():
            def destroy(self):
                self.main.after_cancel(self.theme_after)
                self.main.after_cancel(self.global_after)
                self.main.destroy()
            def __init__(self, master, file, path, this_path):
                def theme_update():
                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)
                    self.theme_after = self.main.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())

                    color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                        color_rgb_activebackground[0] = 0
                    else:
                        color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

                    if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                        color_rgb_activebackground[1] = 0
                    else:
                        color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

                    if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                        color_rgb_activebackground[2] = 0
                    else:
                        color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

                    activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])


                    #self.frameleft.configure(fg_color=bg_color)
                    #self.frameleft.configure(scrollbar_fg_color=bg_color)
                    #self.frameleft.configure(scrollbar_button_color=bg_color)
                    #self.frameleft.configure(scrollbar_button_hover_color=selectbg)

                    #self.frameright.configure(fg_color=bg_color)
                    #self.frameright.configure(scrollbar_fg_color=bg_color)
                    #self.frameright.configure(scrollbar_button_color=bg_color)
                    #self.frameright.configure(scrollbar_button_hover_color=selectbg)

                    self.main['bg'] = bg_color
                    self.icon['bg'] = bg_color

                    self.name['bg'] = bg_color
                    self.name['fg'] = fg_color
                    self.name['font'] = (font_, font_size+5, 'bold')


                def GlobalUpdate():
                    self.global_after = self.main.after(500, GlobalUpdate)

                    def check_size():
                        size = 0
                        for dirpath, dirnames, filenames in os.walk(Path(path, file)):
                            for f in filenames:
                                fp = Path(dirpath, f)
                                size += os.path.getsize(fp)

                        self.size['text'] = f"Размер: {int(size/(1000**2))} мегабайт"

                    def check_elements():
                        elements = []
                        for dirpath, dirnames, filenames in os.walk(Path(path, file)):
                            for f in filenames:
                                fp = Path(dirpath, f)
                                elements.append(fp)
                            for d in dirnames:
                                dp = Path(dirpath, d)
                                elements.append(dp)

                        self.elements1['text'] = f"Кол-во элементов: {len(elements)}"
                    #Thread(target=check_elements, daemon=1).start()

                self.main = Frame(master)
                self.main.pack(fill=BOTH, expand=1)


                self.image = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','this_pc.png'))
                self.image = self.image.resize((100, 100), Image.ANTIALIAS)
                self.image = ImageTk.PhotoImage(self.image)

                self.icon = Label(self.main)
                self.icon.pack()
                self.icon.image = self.image
                self.icon['image'] = self.icon.image

                self.name = Label(self.main, text='Этот компьютер')
                self.name.pack()

                #Separator(self.main, orient='horizontal')

                #ListButton(self.main, text='Добавить ярлык', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), size=20, command=lambda: run_program(D=Path('MaxOS','!SystemPrograms'), F='CreateShortcut.prog', fileopen='MS160722'), fontsize=10).pack(fill=X, anchor=NW, pady=5)



                theme_update()
                GlobalUpdate()

        def change_info(e=''):
            try:
                if self.information_state:
                    self.information.destroy()
                path = self.path_entry.get()
                if hdd_word.lower() in path.lower():
                    path = self.path_entry.get().split(f':{os.sep}')[1]
                element = self.listbox.get(self.listbox.curselection()[0])
                name = os.path.splitext(element)[0]
                ext = os.path.splitext(element)[1].lower()

                if ext.lower() == '.<fold>':
                    ext = ''
                else:pass
                name_file = f"{' '.join(name.split())}{ext}"
                if os.path.isdir(Path(path, f"{name_file}")):
                    if ext.lower() == '.prog' or ext.lower() == '.prg':
                        self.information = ProgramInfo(self.frame_info, file=name_file, path=path, this_path=self.path_entry.get())
                        self.information_state = 1
                    else:
                        self.information = FolderInfo(self.frame_info, file=name_file, path=path, this_path=self.path_entry.get())
                        self.information_state = 1
                else:
                    list_ext = []
                    for i in os.listdir(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST')):
                        type = ''
                        with open(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST', i,'type.txt'), 'r', encoding='utf-8') as f:
                            type = f.read()
                        name = ''
                        with open(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST', i,'name.txt'), 'r', encoding='utf-8') as f:
                            name = f.read()
                        if i[0] != '.' or i[0] != '!':
                            if '|' in name:
                                for n in name.split('|'):
                                    list_ext.append(n)
                            else:
                                list_ext.append(name)

                    if os.path.splitext(name_file)[1].lower() in list_ext:
                        self.information = FileInfo(self.frame_info, file=name_file, path=path, this_path=self.path_entry.get())
                        self.information_state = 1
                    else:
                        self.information = FileExtNoFoundInfo(self.frame_info, file=name_file, path=path, this_path=self.path_entry.get())
                        self.information_state = 1
            except:
                try:
                    list_disks = []
                    for i in psutil.disk_partitions():
                        list_disks.append(i.mountpoint)
                    if self.information_state:
                        self.information.destroy()
                    path = self.path_entry.get()
                    if hdd_word.lower() in path.lower():
                        path = self.path_entry.get().split(f':{os.sep}')[1]
                    if path in list_disks:
                        hdd_info = ''
                        for i in psutil.disk_partitions():
                            if path == i.mountpoint:
                                hdd_info = i
                        if 'cdrom' in hdd_info.opts or 'ro' in hdd_info.opts.split(',') and hdd_info.mountpoint != '/':
                            self.information = CDROMInfo(self.frame_info, file=os.path.split(path)[1], path=os.path.split(path)[0], this_path=self.path_entry.get(), hdd_info=hdd_info)
                            self.information_state = 1
                        else:
                            self.information = HddInfo(self.frame_info, file=os.path.split(path)[1], path=os.path.split(path)[0], this_path=self.path_entry.get(), hdd_info=hdd_info)
                            self.information_state = 1
                    else:
                        if os.path.splitext(path)[1].lower() in ['.prog', '.prg']:
                            if path == '':
                                path = '.'
                            self.information = ProgramInfo(self.frame_info, file=os.path.split(path)[1], path=os.path.split(path)[0], this_path=self.path_entry.get())
                            self.information_state = 1
                        else:
                            if path == '':
                                self.information = MaxOSInfo(self.frame_info, file=os.path.split(path)[1], path=os.path.split(path)[0], this_path=self.path_entry.get())
                                self.information_state = 1
                            else:
                                self.information = FolderInfo(self.frame_info, file=os.path.split(path)[1], path=os.path.split(path)[0], this_path=self.path_entry.get())
                                self.information_state = 1
                except:
                    if self.information_state:
                        self.information.destroy()
                    self.information_state = 0
                    #import traceback
                    #print(traceback.format_exc())
        self.frame_info = CTkScrollableFrame(self.frame_main, corner_radius=0)
        self.frame_info.pack(side=LEFT, fill=BOTH, expand=0)

        self.frame_path = Frame(self.frame_file_man)
        self.frame_path.pack(fill=X)

        def update(e=''):
            path = self.path_entry.get()
            if path == '':
                if self.information_state:
                    self.information.destroy()
                    self.information_state = 0
                self.lab_not_found.pack_forget()
                self.lab_empty_folder.pack_forget()
                self.listbox.pack_forget()
                self.scrollbar1.pack_forget()
                if self.this_computer_state:
                    self.this_computer.destroy()
                    self.this_computer_state = 0
                self.this_computer = ThisComputer(self.frameright)
                self.this_computer_state = 1

                self.information = ThisPCInfo(self.frame_info, file='', path='', this_path='')
                self.information_state = 1
            else:
                self.lab_not_found.pack_forget()
                if self.this_computer_state:
                    self.this_computer.destroy()
                    self.this_computer_state = 0
                self.listbox.pack(fill=BOTH, expand=1, side=LEFT)
                self.scrollbar1.pack(fill=Y, side=RIGHT)
                try:
                    if hdd_word.lower() in path.lower():
                        path = self.path_entry.get().split(f':{os.sep}')[1]
                    if path == '':
                        path = '.'
                    if len(os.listdir(path)) == 0:
                        self.lab_not_found.pack_forget()
                        self.listbox.pack_forget()
                        self.scrollbar1.pack_forget()
                        self.lab_empty_folder.pack(fill=X, anchor=NW)
                    else:
                        self.lab_empty_folder.pack_forget()
                        def rjust(name, ext):
                            len1 = len(name) - len(ext)
                            return f"{name}{ext.rjust(30-len1)}"
                        self.listbox.delete(0, END)

                        for i in sorted(os.listdir(path)):
                            if i[0] == '!' or i[0] == '.':pass
                            else:
                                if os.path.isdir(Path(path, i)):
                                    if os.path.splitext(i)[1] == '':
                                        name = os.path.splitext(i)[0]
                                        ext = '.<FOLD>'
                                        self.listbox.insert(END, rjust(name, ext))

                        for i in sorted(os.listdir(path)):
                            if i[0] == '!' or i[0] == '.':pass
                            else:
                                if os.path.isdir(Path(path, i)):
                                    if os.path.splitext(i)[1] == '.prog' or os.path.splitext(i)[1] == '.prg':
                                        name = os.path.splitext(i)[0]
                                        ext = os.path.splitext(i)[1].upper()
                                        self.listbox.insert(END, rjust(name, ext))

                        for i in sorted(os.listdir(path)):
                            if i[0] == '!' or i[0] == '.':pass
                            else:
                                if os.path.isdir(Path(path, i)):
                                    pass
                                else:
                                    name = os.path.splitext(i)[0]
                                    ext = os.path.splitext(i)[1].upper()
                                    self.listbox.insert(END, rjust(name, ext))
                        change_info()
                except:
                    if self.information_state:
                        self.information.destroy()
                        self.information_state = 0

                    if self.this_computer_state:
                        self.this_computer.destroy()
                        self.this_computer_state = 0

                    self.lab_empty_folder.pack_forget()
                    self.listbox.pack_forget()
                    self.scrollbar1.pack_forget()
                    self.lab_not_found.pack(fill=X, anchor=NW)

        def back(e=''):
            path = self.path_entry.get()
            self.path_entry.delete(0, END)
            new_path = os.path.split(path)[1]
            new_path2 = os.path.split(path)[0]
            if new_path == '':
                self.path_entry.insert(END, f"")
            else:
                if new_path2.lower() == hdd_word.lower():
                    self.path_entry.insert(END, f"{hdd_word}{os.sep}")
                else:
                    self.path_entry.insert(END, os.path.split(path)[0])
            update()

        LabelButtonSystem(self.frame_path, text='<', command=back).pack(side=LEFT, padx=2, pady=2)

        self.path_entry = EntryAuto(self.frame_path, placeholder='placeholder')
        self.path_entry.pack(fill=X, side=LEFT, expand=1, padx=2, pady=2)
        self.path_entry.bind('<KeyRelease>', update)






        self.frameright = CTkFrame(self.frame_file_man, width=200, corner_radius=0)
        self.frameright.pack(fill=BOTH, expand=1)

        class ThisComputer():
            def destroy(self):
                self.content.after_cancel(self.theme_after)
                self.content.destroy()
            def __init__(self, mastertk, upd_func=update, path_entry=self.path_entry):
                def theme_update():
                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)
                    self.theme_after = self.content.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())

                    color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                        color_rgb_activebackground[0] = 0
                    else:
                        color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

                    if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                        color_rgb_activebackground[1] = 0
                    else:
                        color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

                    if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                        color_rgb_activebackground[2] = 0
                    else:
                        color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

                    activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

                    self.bg_ = bg_color
                    self.fg_ = fg_color
                    self.font_ = font_
                    self.font_size = font_size
                    self.selectbg_ = selectbg

                    self.main.configure(fg_color=bg_color)
                    self.main.configure(scrollbar_fg_color=bg_color)
                    self.main.configure(scrollbar_button_color=bg_color)
                    self.main.configure(scrollbar_button_hover_color=selectbg)

                    self.lbl1['bg'] = bg_color
                    self.lbl1['fg'] = fg_color
                    self.lbl1['font'] = (font_, font_size+10, 'bold')

                    self.lbl2['bg'] = bg_color
                    self.lbl2['fg'] = fg_color
                    self.lbl2['font'] = (font_, font_size+5, 'bold')

                    self.lbl3['bg'] = bg_color
                    self.lbl3['fg'] = fg_color
                    self.lbl3['font'] = (font_, font_size+5, 'bold')

                    self.content['bg'] = bg_color

                self.content = Frame(mastertk)
                self.content.pack(fill=BOTH, expand=1)
                self.main = CTkScrollableFrame(self.content, corner_radius=0)
                self.main.pack(fill=BOTH, expand=1)

                self.lbl1 = Label(self.main, text='Этот компьютер')
                self.lbl1.pack(anchor=NW)

                Separator(self.main, orient='horizontal')

                self.lbl2 = Label(self.main, text='MaxOS Systems (1):')
                self.lbl2.pack(anchor=NW)

                def ms(e=''):
                    path_entry.delete(0, END)
                    path_entry.insert(END, f"{hdd_word}{os.sep}")
                    upd_func()

                def fold(path):
                    path_entry.delete(0, END)
                    path_entry.insert(END, f"{hdd_word}{os.sep}{Path(path)}")
                    upd_func()

                ListButton(self.main, text=f"MaxOS System ({hdd_word}{os.sep})", image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SystemFolder.png'), size=35, command=ms).pack(anchor=NW, fill=X)

                Separator(self.main, orient='horizontal')

                self.lbl3 = Label(self.main, text='Места (8):')
                self.lbl3.pack(anchor=NW)

                ListButton(self.main, text=f"Домашняя папка", image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','Folder2.png'), size=35, command=lambda: fold(Path(homefolder))).pack(anchor=NW, fill=X)
                ListButton(self.main, text=f"Программы", image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','Folder2.png'), size=35, command=lambda: fold(Path(homefolder,'Programs'))).pack(anchor=NW, fill=X)
                ListButton(self.main, text=f"Игры", image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','Folder2.png'), size=35, command=lambda: fold(Path(homefolder,'Games'))).pack(anchor=NW, fill=X)
                ListButton(self.main, text=f"Системные программы", image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','Folder2.png'), size=35, command=lambda: fold(Path('MaxOS','!SysPrograms'))).pack(anchor=NW, fill=X)
                ListButton(self.main, text=f"Изображения", image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','Folder2.png'), size=35, command=lambda: fold(Path(homefolder,'Images'))).pack(anchor=NW, fill=X)
                ListButton(self.main, text=f"Снимки с экрана", image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','Folder2.png'), size=35, command=lambda: fold(Path(homefolder,'Screenshots'))).pack(anchor=NW, fill=X)
                ListButton(self.main, text=f"Звуки и музыка", image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','Folder2.png'), size=35, command=lambda: fold(Path(homefolder,'Sounds'))).pack(anchor=NW, fill=X)
                ListButton(self.main, text=f"Мусорка", image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','Trash.png'), size=35, command=ms).pack(anchor=NW, fill=X)

                Separator(self.main, orient='horizontal')

                class HddsMenu():
                    def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
                        self.side = side
                        self.anchor = anchor
                        self.expand = expand
                        self.fill = fill
                        self.padx, self.pady, self.ipadx, self.ipady = padx, pady, ipadx, ipady
                        self.Frame.pack(side=self.side,
                            anchor=self.anchor,
                            expand=self.expand,
                            fill=self.fill,
                            padx=self.padx,
                            pady=self.pady,
                            ipadx=self.ipadx,
                            ipady=self.ipady
                        )
                    def destroy(self):
                        self.Frame.after_cancel(self.theme_after)
                        self.Frame.after_cancel(self.global_after)
                        self.Frame.destroy()
                    def __init__(self, mastertk, upd_func=upd_func, path_entry=path_entry):
                        def theme_update():
                            bg_color = ''
                            fg_color = ''
                            font_ = ''
                            font_size = 0
                            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                                bg_color = bg.read()
                            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                                fg_color = fg.read()
                            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                                font_ = f.read()
                            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                                font_size = int(fs.read())
                            self.theme_after = self.Frame.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                            self.Frame['bg'] = bg_color

                            def get_hex(r, g, b):
                                return '#{:02x}{:02x}{:02x}'.format(r, g, b)

                            self.fg_ = fg_color
                            self.bg_ = bg_color
                            self.font_ = font_
                            self.font_size = font_size

                            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                                color_rgb_select[0] = 250
                            else:
                                color_rgb_select[0] = color_rgb_select[0]+10

                            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                                color_rgb_select[1] = 250
                            else:
                                color_rgb_select[1] = color_rgb_select[1]+10

                            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                                color_rgb_select[2] = 250
                            else:
                                color_rgb_select[2] = color_rgb_select[2]+10

                            selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

                            self.selectbg_ = selectbg

                            self.lbl2['bg'] = bg_color
                            self.lbl2['fg'] = fg_color
                            self.lbl2['font'] = (font_, font_size+5, 'bold')

                        class AddBTN():
                            def destroy(self):
                                self.btn.destroy()
                            def __init__(self, master, name, path, hdd_info, bg, fg, font, font_size, selectbg, upd_func=upd_func, path_entry=path_entry):
                                self.name = name
                                self.path = path
                                self.bg_ = bg
                                self.fg_ = fg
                                self.font_ = font
                                self.font_size = font_size
                                self.selectbg_ = selectbg
                                if self.name == '':
                                    self.name = 'Macintosh HD'

                                def cmd(e=''):
                                    if os.path.isdir(hdd_info.mountpoint):
                                        if sys.platform == 'win32':
                                            path_entry.delete(0, END)
                                            path_entry.insert(END, self.name)
                                        elif sys.platform == 'darwin':
                                            path_entry.delete(0, END)
                                            path_entry.insert(END, self.path)
                                        upd_func()
                                    else:
                                        DialogWin(title='Ошибка', text='Вставьте диск', type='error')
                                if 'cdrom' in hdd_info.opts or 'ro' in hdd_info.opts.split(',') and self.name != 'Macintosh HD':
                                    self.btn = ListButton(master, text=self.name, image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','cd_dvd.png'), size=35, command=cmd)
                                    self.btn.pack(fill=X)
                                    if sys.platform == 'win32':
                                        def eject(e=''):
                                            def open_disk():
                                                import ctypes
                                                ctypes.windll.WINMM.mciSendStringW(u"set cdaudio door open", None, 0, None)
                                            menu = Menu(background=self.bg_, foreground=self.fg_, relief='flat', cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur", tearoff=0, bd=0, font=(self.font_, self.font_size), activebackground=self.selectbg_, activeforeground=self.fg_)
                                            menu.add_command(label='Открыть лоток дисковода', command=open_disk)
                                            menu.post(x=e.x_root, y=e.y_root)
                                        self.btn.bind('<Button-3>', eject)
                                        self.btn.bind('<Control-Button-1>', eject)
                                else:
                                    self.btn = ListButton(master, text=self.name, image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','HDD_ICONS','sys_hdd.png'), size=35, command=cmd)
                                    self.btn.pack(fill=X)

                                def menubtn(e):
                                    menu = Menu(tearoff=0)
                                    def eject():
                                        os.system(f"diskutil eject {Path(self.path)}")
                                        PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','HDD Out.wav'))
                                        self.btn.destroy()
                                    menu.add_command(label='Извлечь', command=eject)
                                    menu.post(x=e.x_root, y=e.y_root)
                                if sys.platform == 'darwin':
                                    if self.name != 'Macintosh HD':
                                        self.btn.bind('<Button-2>', menubtn)
                                        self.btn.bind('<Control-Button-1>', menubtn)

                        def GlobalUpdate():
                            self.global_after = self.Frame.after(100, GlobalUpdate)
                            def check_disks(e=''):
                                disklist1 = []
                                for i in psutil.disk_partitions():
                                    disklist1.append(i.device)
                                time.sleep(0.1)
                                disklist2 = []
                                for i in psutil.disk_partitions():
                                    disklist2.append(i.device)

                                if len(disklist2) > len(disklist1):
                                    self.lbl2['text'] = f"Локальные диски ({len(disklist2)}):"
                                    for w in self.Frame.winfo_children():
                                        w.destroy()
                                    for i in psutil.disk_partitions():
                                        if sys.platform == 'darwin':AddBTN(self.Frame, os.path.split(i.mountpoint)[-1], path=i.mountpoint, hdd_info=i, bg=self.bg_, fg=self.fg_, font=self.font_, font_size=self.font_size, selectbg=self.selectbg_)
                                        elif sys.platform == 'win32':AddBTN(self.Frame, i.mountpoint, path=i.mountpoint, hdd_info=i, bg=self.bg_, fg=self.fg_, font=self.font_, font_size=self.font_size, selectbg=self.selectbg_)

                                elif len(disklist2) < len(disklist1):
                                    self.lbl2['text'] = f"Локальные диски ({len(disklist2)}):"
                                    for w in self.Frame.winfo_children():
                                        w.destroy()
                                    for i in psutil.disk_partitions():
                                        if sys.platform == 'darwin':AddBTN(self.Frame, os.path.split(i.mountpoint)[-1], path=i.mountpoint, hdd_info=i, bg=self.bg_, fg=self.fg_, font=self.font_, font_size=self.font_size, selectbg=self.selectbg_)
                                        elif sys.platform == 'win32':AddBTN(self.Frame, i.mountpoint, path=i.mountpoint, hdd_info=i, bg=self.bg_, fg=self.fg_, font=self.font_, font_size=self.font_size, selectbg=self.selectbg_)
                            Thread(target=check_disks, daemon=1).start()
                        homefolder = ''
                        with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'r', encoding='utf-8') as f:
                            homefolder = f.read()

                        disklist1 = []
                        for i in psutil.disk_partitions():
                            disklist1.append(i.device)

                        self.lbl2 = Label(mastertk, text=f"Локальные диски ({len(disklist1)}):")
                        self.lbl2.pack(anchor=NW)

                        self.Frame = Frame(mastertk)

                        theme_update()

                        for i in psutil.disk_partitions():
                            if sys.platform == 'darwin':AddBTN(self.Frame, os.path.split(i.mountpoint)[-1], path=i.mountpoint, hdd_info=i, bg=self.bg_, fg=self.fg_, font=self.font_, font_size=self.font_size, selectbg=self.selectbg_)
                            elif sys.platform == 'win32':AddBTN(self.Frame, i.mountpoint, path=i.mountpoint, hdd_info=i, bg=self.bg_, fg=self.fg_, font=self.font_, font_size=self.font_size, selectbg=self.selectbg_)

                        GlobalUpdate()

                HddsMenu(self.main).pack(fill=BOTH, anchor=NW)

                theme_update()


        def select(e=''):
            path = self.path_entry.get()
            if hdd_word.lower() in path.lower():
                path = self.path_entry.get().split(f':{os.sep}')[1]
            element = self.listbox.get(self.listbox.curselection()[0])
            name = os.path.splitext(element)[0]
            ext = os.path.splitext(element)[1].lower()

            if ext.lower() == '.<fold>':
                ext = ''
            else:pass
            name_file = f"{' '.join(name.split())}{ext}"
            if os.path.isdir(Path(path, f"{name_file}")):
                if ext.lower() == '.prog' or ext.lower() == '.prg':
                    run_program(D=path, F=f"{name_file}")
                else:
                    with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','root.txt'), 'r', encoding='utf-8') as f:
                        true = f.read().lower()
                        if true == 'true':
                            self.path_entry.delete(0, END)
                            list_disks = []
                            for i in psutil.disk_partitions():
                                if i.mountpoint in f"{Path(path)}":
                                    self.path_entry.insert(END, f"{Path(path, name_file)}")
                                    break
                            else:
                                self.path_entry.insert(END, f"{hdd_word}{os.sep}{Path(path, name_file)}")
                            update()
                        else:
                            if path.lower() == 'users':
                                if name_file == os.path.split(homefolder)[-1]:
                                    self.path_entry.delete(0, END)
                                    self.path_entry.delete(0, END)
                                    list_disks = []
                                    for i in psutil.disk_partitions():
                                        if i.mountpoint in f"{Path(path)}":
                                            self.path_entry.insert(END, f"{Path(path, name_file)}")
                                            break
                                    else:
                                        self.path_entry.insert(END, f"{hdd_word}{os.sep}{Path(path, name_file)}")
                                    update()
                                else:
                                    DialogWin(self.root1, text=f'Вы не имеете доступа к папке {name_file}', title='Ошибка', type='error')
                            else:
                                self.path_entry.delete(0, END)
                                for i in psutil.disk_partitions():
                                    if i.mountpoint in f"{Path(path)}":
                                        self.path_entry.insert(END, f"{Path(path, name_file)}")
                                        break
                                else:
                                    self.path_entry.insert(END, f"{hdd_word}{os.sep}{Path(path, name_file)}")
                                update()

            else:
                list_ext = []
                for i in os.listdir(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST')):
                    if i[0] != '.' or i[0] != '!':
                        type = ''
                        with open(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST', i,'type.txt'), 'r', encoding='utf-8') as f:
                            type = f.read()
                        name = ''
                        with open(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST', i,'name.txt'), 'r', encoding='utf-8') as f:
                            name = f.read()
                        if i[0] != '.' or i[0] != '!':
                            if '|' in name:
                                for n in name.split('|'):
                                    list_ext.append(n)
                            else:
                                list_ext.append(name)

                if os.path.splitext(name_file)[1].lower() in list_ext:
                    for n in os.listdir(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST')):
                        name = ''
                        with open(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST', n,'name.txt'), 'r', encoding='utf-8') as f:
                            name = f.read()
                        if '|' in name:
                            name1 = name.split()
                            if ext in name1:
                                program_open = ''
                                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_EXT_LIST',n, 'open_in_program.txt'), 'r', encoding='utf-8') as f:
                                    program_open = f.read()
                                run_program(D=os.path.split(program_open)[0], F=os.path.split(program_open)[1], fileopen=Path(path, name_file))
                        else:
                            if ext == name:
                                program_open = ''
                                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_EXT_LIST',n, 'open_in_program.txt'), 'r', encoding='utf-8') as f:
                                    program_open = f.read()
                                run_program(D=os.path.split(program_open)[0], F=os.path.split(program_open)[1], fileopen=Path(path, name_file))

        def files_menu(e=''):
            path = self.path_entry.get()
            if hdd_word.lower() in path.lower():
                path = self.path_entry.get().split(f':{os.sep}')[1]
            element = self.listbox.get(self.listbox.curselection()[0])
            name = element.split()[0]
            ext = element.split()[1].lower()

            if ext.lower() == '<fold>':
                ext = ''
            else:pass
            if os.path.isdir(Path(path, f"{name}{ext}")):pass

        self.listbox = Listbox(self.frameright, highlightthickness=0, exportselection=0, relief='flat', cursor='@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur')
        self.listbox.pack(fill=BOTH, expand=1, side=LEFT)
        self.listbox.bind('<Double-Button-1>', select)
        self.listbox.bind('<Return>', select)
        self.listbox.bind('<Control-Button-1>', files_menu)
        self.listbox.bind('<Button-2>', files_menu)
        self.listbox.bind('<Button-3>', files_menu)
        self.listbox.bind('<<ListboxSelect>>', change_info)

        self.scrollbar1 = CTkScrollbar(self.frameright, command=self.listbox.yview)
        self.scrollbar1.pack(fill=Y, side=RIGHT)

        self.lab_not_found = Label(self.frameright, text='Не удалось найти указанный путь')
        self.lab_empty_folder = Label(self.frameright, text='Эта папка пуста')

        self.lab_empty_folder.bind('<Control-Button-1>', files_menu)
        self.lab_empty_folder.bind('<Button-2>', files_menu)
        self.lab_empty_folder.bind('<Button-3>', files_menu)

        self.listbox['yscrollcommand'] = self.scrollbar1.set

        if fileopen == '':
            self.path_entry.insert(END, f"")
            update()
        else:
            if os.path.exists(fileopen):
                if os.path.isdir(fileopen):
                    list_disks = []
                    for i in psutil.disk_partitions():
                        if i.mountpoint in f"{Path(fileopen)}":
                            if os.path.splitext(fileopen)[1].lower() in ['.prog', '.prg']:
                                def rjust(name, ext):
                                    len1 = len(name) - len(ext)
                                    return f"{name}{ext.rjust(30-len1)}"
                                path = self.path_entry.get()
                                if path == '':
                                    path = '.'
                                self.path_entry.insert(END, f"{os.path.split(fileopen)[0]}")
                                update()
                                ext = os.path.splitext(os.path.split(fileopen)[1])[1].upper()
                                name = os.path.splitext(os.path.split(fileopen)[1])[0]

                                name_file = rjust(name, ext)

                                self.listbox.select_set(first=self.listbox.get(0, END).index(name_file))
                            else:
                                self.path_entry.insert(END, f"{Path(fileopen)}")
                                update()
                            break
                    else:
                        if fileopen == '.':
                            self.path_entry.insert(END, f"{hdd_word}{os.sep}")
                        else:
                            if os.path.splitext(fileopen)[1].lower() in ['.prog', '.prg']:
                                def rjust(name, ext):
                                    len1 = len(name) - len(ext)
                                    return f"{name}{ext.rjust(30-len1)}"
                                path = self.path_entry.get()
                                if path == '':
                                    path = '.'
                                self.path_entry.insert(END, f"{hdd_word}{os.sep}{os.path.split(fileopen)[0]}")
                                update()
                                ext = os.path.splitext(os.path.split(fileopen)[1])[1].upper()
                                name = os.path.splitext(os.path.split(fileopen)[1])[0]

                                name_file = rjust(name, ext)

                                self.listbox.select_set(first=self.listbox.get(0, END).index(name_file))
                            else:
                                self.path_entry.insert(END, f"{hdd_word}{os.sep}{Path(fileopen)}")
                                update()
                else:
                    def rjust(name, ext):
                        len1 = len(name) - len(ext)
                        return f"{name}{ext.rjust(30-len1)}"
                    path = self.path_entry.get()
                    if path == '':
                        path = '.'
                    for i in psutil.disk_partitions():
                        if i.mountpoint in f"{Path(fileopen)}":
                            self.path_entry.insert(END, f"{os.path.split(fileopen)[0]}")
                            update()
                            ext = os.path.splitext(os.path.split(fileopen)[1])[1].upper()
                            name = os.path.splitext(os.path.split(fileopen)[1])[0]

                            name_file = rjust(name, ext)

                            self.listbox.select_set(first=self.listbox.get(0, END).index(name_file))
                            break
                    else:
                        self.path_entry.insert(END, f"{hdd_word}{os.sep}{os.path.split(fileopen)[0]}")
                        update()
                        ext = os.path.splitext(os.path.split(fileopen)[1])[1].upper()
                        name = os.path.splitext(os.path.split(fileopen)[1])[0]

                        name_file = rjust(name, ext)

                        self.listbox.select_set(first=self.listbox.get(0, END).index(name_file))
                change_info()
            else:
                for i in psutil.disk_partitions():
                    if i.mountpoint in f"{Path(fileopen)}":
                        self.path_entry.insert(END, i.mountpoint)
                        path = self.path_entry.get()
                        if 'cdrom' in i.opts or 'ro' in i.opts.split(',') and i.mountpoint != '/':
                            self.information = CDROMInfo(self.frame_info, file=os.path.split(path)[1], path=os.path.split(path)[0], this_path=self.path_entry.get(), hdd_info=i)
                            self.information_state = 1
                        else:
                            self.information = HddInfo(self.frame_info, file=os.path.split(path)[1], path=os.path.split(path)[0], this_path=self.path_entry.get(), hdd_info=i)
                            self.information_state = 1
                        break

                else:
                    DialogWin(self.root, text=f"Не удалось найти путь: \"{Path(fileopen)}\"", title='Ошибка', type='error')
                    update()

        def GlobalUpdate():
            self.global_after = self.root.after(100, GlobalUpdate)
            def check_dir():
                path = self.path_entry.get()
                try:
                    if hdd_word.lower() in path.lower():
                        path = self.path_entry.get().split(f':{os.sep}')[1]
                    dir1 = os.listdir(Path(path))
                    dir1 = len(dir1)
                    time.sleep(0.1)
                    dir2 = os.listdir(Path(path))
                    dir2 = len(dir2)

                    if dir1 != dir2:
                        update()
                except:
                    if path == '':
                        pass
                    else:
                        pass
            Thread(target=check_dir, daemon=1).start()

            def check_path():
                path1 = self.path_entry.get()
                time.sleep(0.1)
                path2 = self.path_entry.get()

                if path1 != path2:
                    update()
            #Thread(target=check_path, daemon=1).start()


        #Files(self.frameright, path=self.path_entry).pack(fill=BOTH, expand=1)


        #self.root1.bind('<Map>', self.root1.center)

        theme_update()
        GlobalUpdate()
App()
