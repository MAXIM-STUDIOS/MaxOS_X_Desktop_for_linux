from pathlib import *
import os
from tkinter import *
import traceback
import sys
import shutil
import time
import os
import tkinter as tk
from tkinter import ttk
from PIL import ImageTk
from threading import Thread
import threading
import time
import random
from PIL import Image, ImageTk
from itertools import count
import zipfile
from PIL import ImageColor
import pyautogui
from customtkinter import *
import customtkinter as ctk
from playsound import *
from tkVideoPlayer import TkinterVideo
from pathlib import *
from tkinter import font
import tkmacosx as tkm
from audioplayer import AudioPlayer
from CTkListbox import *
import cv2
from tkinter_webcam.webcam import Box
import psutil

sys.path.append(Path('MaxOS','!OSX'))

from Components.RunProgram import run_program

hdd_word = ''
with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_INFO','hdd_word.txt'), 'r', encoding='utf-8') as hf:
    hdd_word = hf.read()

class PlaySound():
    def __init__(self, name):
        self.volume = ''

        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_OUTPUT','AUDIO_OUTPUT','volume.txt'), 'r', encoding='utf-8') as v:
            self.volume = int(v.readline())

        self.player = AudioPlayer(str(Path(name)))
        self.player.volume = self.volume
        Thread(target=lambda: self.player.play(block=True), daemon=1).start()

def empty(*args,**kwargs):pass

def write_file(file, text):
    o = open(file, 'w', encoding='utf-8')
    o.write(str(text))
    o.close()

def read_file(file):
    o = open(file, 'r', encoding='utf-8')
    text = o.read()
    o.close()
    return text


fontMaxOS = 'Montserrat'
def passDEF(*args,**kwargs):pass
bg_tb = 'white'
fg_tb = 'white'
system = sys.platform
class BUTTON_MENU():
    def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
        self.side = side
        self.anchor = anchor
        self.expand = expand
        self.fill = fill
        self.padx, self.pady, self.ipadx, self.ipady = padx, pady, ipadx, ipady
        self.btn_shutdown.pack(side=self.side,
            anchor=self.anchor,
            expand=self.expand,
            fill=self.fill,
            padx=self.padx,
            pady=self.pady,
            ipadx=self.ipadx,
            ipady=self.ipady
        )
    def delete(self):
        self.btn_shutdown.after_cancel(self.theme_after)
        self.btn_shutdown.pack_forget()
    def destroy(self):
        self.btn_shutdown.after_cancel(self.theme_after)
        self.btn_shutdown.destroy()
    def __init__(self, master, path, command, size=(50, 50)):
        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            self.theme_after = self.btn_shutdown.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            self.btn_shutdown['bg'] = bg_color
        Shutdown = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS',path,'normal.png'))
        Shutdown = Shutdown.resize(size, Image.ANTIALIAS)
        Shutdown = ImageTk.PhotoImage(Shutdown)
        self.shutactivestate = 0
        self.shuthoverstate = 0
        self.btn_shutdown = Label(master, bg='#EFFBFF')
        self.btn_shutdown.image = Shutdown
        self.btn_shutdown['image'] = self.btn_shutdown.image

        def hovershut(e=''):
            if self.shutactivestate:
                Shutdown = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS',path,'active.png'))
                Shutdown = Shutdown.resize(size, Image.ANTIALIAS)
                Shutdown = ImageTk.PhotoImage(Shutdown)
                self.btn_shutdown.image = Shutdown
                self.btn_shutdown['image'] = self.btn_shutdown.image
            else:
                Shutdown = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS',path,'hover.png'))
                Shutdown = Shutdown.resize(size, Image.ANTIALIAS)
                Shutdown = ImageTk.PhotoImage(Shutdown)
                self.btn_shutdown.image = Shutdown
                self.btn_shutdown['image'] = self.btn_shutdown.image
            self.btn_shutdown['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur"
            self.shuthoverstate = 1
        def unhovershut(e=''):
            Shutdown = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS',path,'normal.png'))
            Shutdown = Shutdown.resize(size, Image.ANTIALIAS)
            Shutdown = ImageTk.PhotoImage(Shutdown)
            self.btn_shutdown.image = Shutdown
            self.btn_shutdown['image'] = self.btn_shutdown.image
            self.btn_shutdown['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
            self.shuthoverstate = 0
        def startshut(e=''):
            if self.shuthoverstate:
                Shutdown = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS',path,'active.png'))
                Shutdown = Shutdown.resize(size, Image.ANTIALIAS)
                Shutdown = ImageTk.PhotoImage(Shutdown)
                self.btn_shutdown.image = Shutdown
                self.btn_shutdown['image'] = self.btn_shutdown.image
            self.btn_shutdown['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur"
            self.shutactivestate = 1
        def stopshut(e=''):
            if self.shuthoverstate:
                Shutdown = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS',path,'hover.png'))
                Shutdown = Shutdown.resize(size, Image.ANTIALIAS)
                Shutdown = ImageTk.PhotoImage(Shutdown)
                self.btn_shutdown.image = Shutdown
                self.btn_shutdown['image'] = self.btn_shutdown.image
                command()
            else:
                Shutdown = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS',path,'normal.png'))
                Shutdown = Shutdown.resize(size, Image.ANTIALIAS)
                Shutdown = ImageTk.PhotoImage(Shutdown)
                self.btn_shutdown.image = Shutdown
                self.btn_shutdown['image'] = self.btn_shutdown.image
            self.btn_shutdown['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur"
            self.shutactivestate = 0
        self.btn_shutdown.bind('<Enter>', hovershut)
        self.btn_shutdown.bind('<Leave>', unhovershut)
        self.btn_shutdown.bind('<ButtonPress-1>', startshut)
        self.btn_shutdown.bind('<ButtonRelease-1>', stopshut)
        theme_update()
class ListButton():
    def destroy(self):
        self.frame1.after_cancel(self.theme_after)
        self.frame1.destroy()
    def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
        self.side = side
        self.anchor = anchor
        self.expand = expand
        self.fill = fill
        self.padx, self.pady, self.ipadx, self.ipady = padx, pady, ipadx, ipady
        self.frame1.pack(side=self.side,
            anchor=self.anchor,
            expand=self.expand,
            fill=self.fill,
            padx=self.padx,
            pady=self.pady,
            ipadx=self.ipadx,
            ipady=self.ipady
        )

    def bind(self, key, command):
        self.frame1.bind(key, command)
        self.imagelabel.bind(key, command)
        self.textlabel.bind(key, command)

    def __init__(self, master, command, text, image, size, fontsize=15, multiple=False, listmultitype=[]):
        self.activebackground = ''
        self.selectbg = ''
        self.bg = ''
        self.fontsize = fontsize
        self.multiple = multiple
        self.listmultitype = listmultitype
        self.text = text
        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)


            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())

            font_size2 = self.fontsize - font_size

            self.theme_after = self.frame1.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())

            color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                color_rgb_activebackground[0] = 0
            else:
                color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

            if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                color_rgb_activebackground[1] = 0
            else:
                color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

            if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                color_rgb_activebackground[2] = 0
            else:
                color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

            self.activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            self.selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

            self.textlabel['fg'] = fg_color
            self.textlabel['font'] = (font_, font_size+font_size2)

            self.bg = bg_color

            if self.hoverstate != 1 and self.activestate != 1 and self.multitipestate != 1:
                self.frame1['bg'] = bg_color
                self.imagelabel['bg'] = bg_color
                self.textlabel['bg'] = bg_color

        self.frame1 = Frame(master, cursor='hand1')

        img = Image.open(image)
        img = img.resize((size, size), Image.ANTIALIAS)
        img = ImageTk.PhotoImage(img)

        self.hoverstate = 0
        self.activestate = 0
        self.multitipestate = 0

        def hover(e=''):
            if self.multitipestate != 1:
                if self.activestate:
                    self.frame1['bg'] = self.activebackground
                    self.imagelabel['bg'] = self.activebackground
                    self.textlabel['bg'] = self.activebackground
                else:
                    self.frame1['bg'] = self.selectbg
                    self.imagelabel['bg'] = self.selectbg
                    self.textlabel['bg'] = self.selectbg
            cursor = 'link.cur'
            self.frame1['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
            self.imagelabel['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
            self.textlabel['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
            self.hoverstate = 1
        def unhover(e=''):
            if self.multitipestate != 1:
                self.frame1['bg'] = self.bg
                self.imagelabel['bg'] = self.bg
                self.textlabel['bg'] = self.bg
            cursor = 'Default.cur'
            self.frame1['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
            self.imagelabel['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
            self.textlabel['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
            self.hoverstate = 0


        def start(e=''):
            self.frame1['bg'] = self.activebackground
            self.imagelabel['bg'] = self.activebackground
            self.textlabel['bg'] = self.activebackground
            cursor = 'link.cur'
            self.frame1['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
            self.imagelabel['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
            self.textlabel['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
            self.activestate = 1


        self.imagelabel = Label(self.frame1, cursor='hand1')
        self.imagelabel.image = img
        self.imagelabel['image'] = self.imagelabel.image
        self.imagelabel.pack(side=LEFT, padx=2, pady=2, fill=Y)

        self.textlabel = Label(self.frame1, text=text, cursor='hand1')
        self.textlabel.pack(side=LEFT, padx=2, pady=2, fill=Y)



        if self.multiple == False:
            def stop(e=''):
                if self.hoverstate:
                    self.frame1['bg'] = self.selectbg
                    self.imagelabel['bg'] = self.selectbg
                    self.textlabel['bg'] = self.selectbg
                    command()
                else:
                    self.frame1['bg'] = self.bg
                    self.imagelabel['bg'] = self.bg
                    self.textlabel['bg'] = self.bg
                cursor = 'link.cur'
                self.frame1['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
                self.imagelabel['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
                self.textlabel['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
                self.activestate = 0
            self.textlabel.bind("<Enter>", hover)
            self.textlabel.bind("<Leave>", unhover)
            self.imagelabel.bind("<Enter>", hover)
            self.imagelabel.bind("<Leave>", unhover)
            self.frame1.bind("<Enter>", hover)
            self.frame1.bind("<Leave>", unhover)

            self.textlabel.bind("<ButtonPress-1>", start)
            self.textlabel.bind("<ButtonRelease-1>", stop)
            self.imagelabel.bind("<ButtonPress-1>", start)
            self.imagelabel.bind("<ButtonRelease-1>", stop)
            self.frame1.bind("<ButtonPress-1>", start)
            self.frame1.bind("<ButtonRelease-1>", stop)
        elif self.multiple == True:
            def stop(e=''):
                if self.hoverstate:
                    self.frame1['bg'] = self.selectbg
                    self.imagelabel['bg'] = self.selectbg
                    self.textlabel['bg'] = self.selectbg
                else:
                    self.frame1['bg'] = self.bg
                    self.imagelabel['bg'] = self.bg
                    self.textlabel['bg'] = self.bg
                cursor = 'link.cur'
                self.frame1['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
                self.imagelabel['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
                self.textlabel['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
                self.activestate = 0

            def cmd(e=''):
                self.multitipestate = 0
                try:self.listmultitype.remove(self.text)
                except:pass
                if self.hoverstate:
                    self.frame1['bg'] = self.selectbg
                    self.imagelabel['bg'] = self.selectbg
                    self.textlabel['bg'] = self.selectbg
                    command()
                else:
                    self.frame1['bg'] = self.bg
                    self.imagelabel['bg'] = self.bg
                    self.textlabel['bg'] = self.bg
                cursor = 'link.cur'
                self.frame1['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
                self.imagelabel['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
                self.textlabel['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
                self.activestate = 0
            self.textlabel.bind("<Enter>", hover)
            self.textlabel.bind("<Leave>", unhover)
            self.imagelabel.bind("<Enter>", hover)
            self.imagelabel.bind("<Leave>", unhover)
            self.frame1.bind("<Enter>", hover)
            self.frame1.bind("<Leave>", unhover)

            self.textlabel.bind("<Double-Button-1>", cmd)
            self.imagelabel.bind("<Double-Button-1>", cmd)
            self.frame1.bind("<Double-Button-1>", cmd)

            self.textlabel.bind("<ButtonPress-1>", start)
            self.textlabel.bind("<ButtonRelease-1>", stop)
            self.imagelabel.bind("<ButtonPress-1>", start)
            self.imagelabel.bind("<ButtonRelease-1>", stop)
            self.frame1.bind("<ButtonPress-1>", start)
            self.frame1.bind("<ButtonRelease-1>", stop)

            def select(e=''):
                self.frame1['bg'] = self.selectbg
                self.imagelabel['bg'] = self.selectbg
                self.textlabel['bg'] = self.selectbg
                if self.multitipestate != 1:
                    self.listmultitype.append(self.text)
                print(self.multitipestate)
                print(self.listmultitype)
                self.multitipestate = 1

            self.textlabel.bind("<Shift-Button-1>", select)
            self.imagelabel.bind("<Shift-Button-1>", select)
            self.frame1.bind("<Shift-Button-1>", select)

        theme_update()
class CheckLabelButton(tk.Label):
    def delete(self):
        self.LblBtnFr.place_forget()
        self.LblBtnFr.pack_forget()
        self.LblBtnFr.grid_forget()
    def grid(self, row=None, column=None, sticky=None, padx=None, pady=None):
        self.row = row
        self.column = column
        self.sticky = sticky
        self.padx = padx
        self.pady = padx


        self.LblBtnFr.grid(row=self.row,
        column=self.column,
        sticky=self.sticky,
        padx=self.padx,
        pady=self.pady
        )
    def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
        self.side = side
    def place(self, x=None, anchor=None, y=None, relwidth=None, relx=None, rely=None, relheight=None, width=None, height=None):
        self.x = x
        self.y = y
        self.anchor = anchor
        self.relheight = relheight
        self.relwidth = relwidth
        self.width = width
        self.height = height
        self.rely = rely
        self.relx = relx
        self.LblBtnFr.place(x=self.x,
            anchor=self.anchor,
            relheight=self.relheight,
            width=self.width,
            rely=self.rely,
            relx=self.relx,
            y=self.y,
            relwidth=self.relwidth,
            height=self.height
        )
    def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
        self.side = side
        self.anchor = anchor
        self.expand = expand
        self.fill = fill
        self.padx, self.pady, self.ipadx, self.ipady = padx, pady, ipadx, ipady
        self.LblBtnFr.pack(side=self.side,
            anchor=self.anchor,
            expand=self.expand,
            fill=self.fill,
            padx=self.padx,
            pady=self.pady,
            ipadx=self.ipadx,
            ipady=self.ipady
        )
    def on(self, commandon=None, commandoff=None):
        self.commandon, self.commandoff = commandon, commandoff
        def activeoff(event=None):
            self.LblBtnFr['relief'] = self.reliefnormal
            self.LblBtn['bg'] = self.bg
            self.LblBtnFr['bg'] = self.bg
            self.LblBtn['fg'] = self.fg
            self.LblBtn.bind('<Button-1>', activeon)
            self.LblBtnFr.bind('<Button-1>', activeon)
            self.commandoff()
        def activeon(event=None):
            self.LblBtnFr['relief'] = self.reliefactive
            self.LblBtn['bg'] = self.activebackground
            self.LblBtnFr['bg'] = self.activebackground
            self.LblBtn['fg'] = self.activeforeground
            self.LblBtn.bind('<Button-1>', activeoff)
            self.LblBtnFr.bind('<Button-1>', activeoff)
            self.commandon()
        activeon()
    def off(self, commandon=None, commandoff=None):
        self.commandon, self.commandoff = commandon, commandoff
        def activeoff(event=None):
            self.LblBtnFr['relief'] = self.reliefnormal
            self.LblBtn['bg'] = self.bg
            self.LblBtnFr['bg'] = self.bg
            self.LblBtn['fg'] = self.fg
            self.LblBtn.bind('<Button-1>', activeon)
            self.LblBtnFr.bind('<Button-1>', activeon)
            self.commandoff()
        def activeon(event=None):
            self.LblBtnFr['relief'] = self.reliefactive
            self.LblBtn['bg'] = self.activebackground
            self.LblBtnFr['bg'] = self.activebackground
            self.LblBtn['fg'] = self.activeforeground
            self.LblBtn.bind('<Button-1>', activeoff)
            self.LblBtnFr.bind('<Button-1>', activeoff)
            self.commandon()
        activeoff()
    def __init__(self, master=None, bg='#ececec', fg='#000000', commandon=None, commandoff=None, reliefnormal=RAISED, reliefactive=SUNKEN, bd=1, text=None, font=None, height=None, width=None, cursor='hand1', activebackground=None, activeforeground=None, image=None, selectbg='#046ac9', selectfg='white', value='off'):
        self.master = master
        self.bg = bg
        self.fg = fg
        self.commandon = commandon
        self.commandoff = commandoff
        self.reliefnormal = FLAT
        self.reliefactive = SUNKEN
        self.bd = 0
        self.text = text
        self.font = font
        self.width, self.height = width, height
        self.cursor = 'arrow'
        self.activebackground = activebackground
        self.activeforeground = activeforeground
        self.image = image
        self.selectbg = selectbg
        self.selectfg = selectfg
        self.value = value

        def activeon(event):
            self.LblBtnFr['relief'] = self.reliefactive
            self.LblBtn['bg'] = self.activebackground
            self.LblBtnFr['bg'] = self.activebackground
            self.LblBtn['fg'] = self.activeforeground
            self.LblBtn.bind('<Button-1>', activeoff)
            self.LblBtnFr.bind('<Button-1>', activeoff)
            self.commandon()



        def activeoff(event):
            self.LblBtnFr['relief'] = self.reliefnormal
            self.LblBtn['bg'] = self.bg
            self.LblBtnFr['bg'] = self.bg
            self.LblBtn['fg'] = self.fg
            self.LblBtn.bind('<Button-1>', activeon)
            self.LblBtnFr.bind('<Button-1>', activeon)
            self.commandoff()


        def hover(event):
            if self.LblBtnFr['relief'] != self.reliefactive:
                self.LblBtn['fg'] = self.selectfg
                self.LblBtn['bg'] = self.selectbg
                self.LblBtnFr['bg'] = self.selectbg
            cursor = 'link.cur'
            self.LblBtnFr['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
            self.LblBtn['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
            self.LblBtn['relief'] = FLAT
        def unhover(event):
            if self.LblBtnFr['relief'] != self.reliefactive:
                self.LblBtn['fg'] = self.fg
                self.LblBtn['bg'] = self.bg
                self.LblBtnFr['bg'] = self.bg
                self.LblBtn['relief'] = FLAT
            cursor = 'Default.cur'
            self.LblBtnFr['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
            self.LblBtn['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"

        self.LblBtnFr = tk.Frame(self.master, bd=self.bd)

        if self.value == 'off':
            self.LblBtnFr['relief'] = self.reliefnormal
            self.LblBtnFr['bg'] = self.bg
            self.LblBtn = tk.Label(self.LblBtnFr, text=self.text, font=self.font, height=self.height, width=self.width, image=self.image, bg=self.bg, fg=self.fg)
            self.LblBtn.pack(fill=BOTH, expand=1)
            self.LblBtn.bind('<Button-1>', activeon)
            self.LblBtnFr.bind('<Button-1>', activeon)
            self.commandoff()
        elif self.value == 'on':
            self.LblBtn = tk.Label(self.LblBtnFr, text=self.text, font=self.font, height=self.height, width=self.width, image=self.image, bg=self.activebackground, fg=self.activeforeground)
            self.LblBtn.pack(fill=BOTH, expand=1)
            self.LblBtnFr['relief'] = self.reliefactive
            self.LblBtnFr['bg'] = self.activebackground
            self.LblBtn['relief'] = FLAT
            self.LblBtn.bind('<Button-1>', activeoff)
            self.LblBtnFr.bind('<Button-1>', activeoff)
            self.commandon()

        self.LblBtn.bind('<Enter>', hover)
        self.LblBtnFr.bind('<Enter>', hover)

        self.LblBtn.bind('<Leave>', unhover)
        self.LblBtnFr.bind('<Leave>', unhover)
        '''
        self.configure({key: value})
        return self._configure('configure', cnf, kw)
        self.tk.call(_flatten((self._w, cmd)) + self._options(cnf))
        '''
        self.LblBtn['bg'] = self.bg
        self.LblBtn['fg'] = self.fg
class CheckLabelButtonSystem(tk.Label):
    def delete(self):
        self.LblBtnFr.place_forget()
        self.LblBtnFr.pack_forget()
        self.LblBtnFr.grid_forget()
    def grid(self, row=None, column=None, sticky=None, padx=None, pady=None):
        self.row = row
        self.column = column
        self.sticky = sticky
        self.padx = padx
        self.pady = padx


        self.LblBtnFr.grid(row=self.row,
        column=self.column,
        sticky=self.sticky,
        padx=self.padx,
        pady=self.pady
        )
    def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
        self.side = side
    def place(self, x=None, anchor=None, y=None, relwidth=None, relx=None, rely=None, relheight=None, width=None, height=None):
        self.x = x
        self.y = y
        self.anchor = anchor
        self.relheight = relheight
        self.relwidth = relwidth
        self.width = width
        self.height = height
        self.rely = rely
        self.relx = relx
        self.LblBtnFr.place(x=self.x,
            anchor=self.anchor,
            relheight=self.relheight,
            width=self.width,
            rely=self.rely,
            relx=self.relx,
            y=self.y,
            relwidth=self.relwidth,
            height=self.height
        )
    def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
        self.side = side
        self.anchor = anchor
        self.expand = expand
        self.fill = fill
        self.padx, self.pady, self.ipadx, self.ipady = padx, pady, ipadx, ipady
        self.LblBtnFr.pack(side=self.side,
            anchor=self.anchor,
            expand=self.expand,
            fill=self.fill,
            padx=self.padx,
            pady=self.pady,
            ipadx=self.ipadx,
            ipady=self.ipady
        )
    def on(self, commandon=None, commandoff=None):
        self.commandon, self.commandoff = commandon, commandoff
        def activeoff(event=None):
            self.LblBtnFr['relief'] = self.reliefnormal
            self.LblBtn['bg'] = self.bg
            self.LblBtnFr['bg'] = self.bg
            self.LblBtn['fg'] = self.fg
            self.LblBtn.bind('<Button-1>', activeon)
            self.LblBtnFr.bind('<Button-1>', activeon)
            self.commandoff()
        def activeon(event=None):
            self.LblBtnFr['relief'] = self.reliefactive
            self.LblBtn['bg'] = self.activebackground
            self.LblBtnFr['bg'] = self.activebackground
            self.LblBtn['fg'] = self.activeforeground
            self.LblBtn.bind('<Button-1>', activeoff)
            self.LblBtnFr.bind('<Button-1>', activeoff)
            self.commandon()
        activeon()
    def off(self, commandon=None, commandoff=None):
        self.commandon, self.commandoff = commandon, commandoff
        def activeoff(event=None):
            self.LblBtnFr['relief'] = self.reliefnormal
            self.LblBtn['bg'] = self.bg
            self.LblBtnFr['bg'] = self.bg
            self.LblBtn['fg'] = self.fg
            self.LblBtn.bind('<Button-1>', activeon)
            self.LblBtnFr.bind('<Button-1>', activeon)
            self.commandoff()
        def activeon(event=None):
            self.LblBtnFr['relief'] = self.reliefactive
            self.LblBtn['bg'] = self.activebackground
            self.LblBtnFr['bg'] = self.activebackground
            self.LblBtn['fg'] = self.activeforeground
            self.LblBtn.bind('<Button-1>', activeoff)
            self.LblBtnFr.bind('<Button-1>', activeoff)
            self.commandon()
        activeoff()
    def __init__(self, master=None, bg='#ececec', fg='#000000', commandon=None, commandoff=None, reliefnormal=RAISED, reliefactive=SUNKEN, bd=0, text=None, font=None, height=None, width=None, cursor='hand1', activebackground=None, activeforeground=None, image=None, selectbg='#046ac9', selectfg='white', value='off'):
        self.master = master
        self.commandon = commandon
        self.commandoff = commandoff
        self.reliefnormal = reliefnormal
        self.reliefactive = reliefactive
        self.bd = bd
        self.text = text
        self.font = font
        self.width, self.height = width, height
        self.cursor = cursor
        self.activebackground = activebackground
        self.activeforeground = activeforeground
        self.image = image
        self.selectbg = selectbg
        self.selectfg = selectfg
        self.value = value
        self.bg = ''
        self.fg = ''

        self.selectstate = 0

        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg1:
            self.bg = bg1.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg1:
            self.fg = fg1.read()


        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)

            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            self.theme_after = self.LblBtnFr.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            #self.LblBtn['bg'] = bg_color
            self.LblBtn['fg'] = fg_color
            self.LblBtn['font'] = (font_, font_size+5)

            self.bg = bg_color
            self.fg = fg_color

            color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                color_rgb_activebackground[0] = 0
            else:
                color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

            if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                color_rgb_activebackground[1] = 0
            else:
                color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

            if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                color_rgb_activebackground[2] = 0
            else:
                color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

            self.activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            self.selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

            if self.value == 'off':
                if self.selectstate:
                    self.LblBtnFr['bg'] = self.selectbg
                    self.LblBtn['bg'] = self.selectbg
                else:
                    self.LblBtnFr['bg'] = bg_color
                    self.LblBtn['bg'] = bg_color
            elif self.value == 'on':
                self.LblBtnFr['bg'] = self.activebackground
                self.LblBtn['bg'] = self.activebackground
        def activeon(event):
            self.LblBtnFr['relief'] = self.reliefactive
            self.LblBtn['bg'] = self.activebackground
            self.LblBtnFr['bg'] = self.activebackground
            self.LblBtn.bind('<Button-1>', activeoff)
            self.LblBtnFr.bind('<Button-1>', activeoff)
            self.value = 'on'
            self.commandon()



        def activeoff(event):
            self.LblBtnFr['relief'] = self.reliefnormal
            self.LblBtn['bg'] = self.bg
            self.LblBtnFr['bg'] = self.bg
            self.LblBtn.bind('<Button-1>', activeon)
            self.LblBtnFr.bind('<Button-1>', activeon)
            self.value = 'off'
            self.commandoff()


        def hover(event):
            if self.value == 'off':
                self.LblBtn['bg'] = self.selectbg
                self.LblBtnFr['bg'] = self.selectbg
                self.LblBtn['relief'] = FLAT
            cursor = 'link.cur'
            self.LblBtnFr['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
            self.LblBtn['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
            self.selectstate = 1
        def unhover(event):
            if self.value == 'off':
                self.LblBtn['bg'] = self.bg
                self.LblBtnFr['bg'] = self.bg
                self.LblBtn['relief'] = FLAT
            cursor = 'link.cur'
            self.LblBtnFr['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
            self.LblBtn['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
            self.selectstate = 0

        self.LblBtnFr = tk.Frame(self.master, bd=self.bd)

        if self.value == 'off':
            self.LblBtnFr['relief'] = self.reliefnormal
            self.LblBtnFr['bg'] = self.bg
            self.LblBtn = tk.Label(self.LblBtnFr, text=self.text, font=self.font, height=self.height, width=self.width, image=self.image, bg=self.bg, fg=self.fg)
            self.LblBtn.pack(fill=BOTH, expand=1)
            self.LblBtn.bind('<Button-1>', activeon)
            self.LblBtnFr.bind('<Button-1>', activeon)

        elif self.value == 'on':
            self.LblBtn = tk.Label(self.LblBtnFr, text=self.text, font=self.font, height=self.height, width=self.width, image=self.image, bg=self.activebackground, fg=self.activeforeground)
            self.LblBtn.pack(fill=BOTH, expand=1)
            self.LblBtnFr['relief'] = self.reliefactive
            self.LblBtnFr['bg'] = self.bg
            self.LblBtn['relief'] = FLAT
            self.LblBtn.bind('<Button-1>', activeoff)
            self.LblBtnFr.bind('<Button-1>', activeoff)
            self.commandon()

        theme_update()

        self.LblBtn.bind('<Enter>', hover)
        self.LblBtnFr.bind('<Enter>', hover)

        self.LblBtn.bind('<Leave>', unhover)
        self.LblBtnFr.bind('<Leave>', unhover)
        '''
        self.configure({key: value})
        return self._configure('configure', cnf, kw)
        self.tk.call(_flatten((self._w, cmd)) + self._options(cnf))
        '''
        self.LblBtn['bg'] = self.bg
        self.LblBtn['fg'] = self.fg
class LabelProgressBar(tk.Label, tk.Frame):
    def start(self, time_bar=None, size=None, value=0):
        self.time_bar = time_bar
        self.size = size
        self.value = value
        def start_progress():
            while self.value < self.size:
                time.sleep(self.time_bar)
                self.value += 1
                tk.Label(self.ProgressBarFrame, font=('Monaco', self.bd_bar, 'normal'), bg=self.bg_bar, relief=SUNKEN).pack(side=LEFT, ipadx=2)
        Thread(target = start_progress, daemon=True).start()
    def place(self, x=None, anchor=None, y=None, relwidth=None, relx=None, rely=None, relheight=None, width=None, height=None):
        self.x = x
        self.y = y
        self.anchor = anchor
        self.relheight = relheight
        self.relwidth = relwidth
        self.width = width
        self.height = height
        self.rely = rely
        self.relx = relx
        self.frame.place(x=self.x,
            anchor=self.anchor,
            relheight=self.relheight,
            width=self.width,
            rely=self.rely,
            relx=self.relx,
            y=self.y,
            relwidth=self.relwidth,
            height=self.height
        )
    def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
        self.side = side
        self.anchor = anchor
        self.expand = expand
        self.fill = fill
        self.padx, self.pady, self.ipadx, self.ipady = padx, pady, ipadx, ipady
        self.frame.pack(side=self.side,
            anchor=self.anchor,
            expand=self.expand,
            fill=self.fill,
            padx=self.padx,
            pady=self.pady,
            ipadx=self.ipadx,
            ipady=self.ipady
        )
    def __init__(self, master=None, bg_bar='blue', bd_bar=5, bg='#ececec'):
        tk.Label.__init__(self, master)
        tk.Frame.__init__(self, master)

        self.master = master
        self.bg = bg
        self.bg_bar = bg_bar
        self.bd_bar = bd_bar

        self.frame = tk.Frame(self.master, bg=self.bg)
        #tk.Label(self.frame, bg=self.bg, font=('Monaco', self.bd_bar, 'normal')).pack()

        self.ProgressBarFrame = tk.Frame(self.frame, bg=self.bg)
        self.ProgressBarFrame.pack(side=LEFT)
        '''
        self.Progress = tk.Label(self.ProgressBarFrame, font=('Monaco', self.bd_bar, 'normal'), bg=self.bg_bar, relief=SUNKEN)
        self.Progress.pack(side=LEFT)
        '''
class LabelButtonClassic(tk.Label):
    def config(self, master=None, bg=None, fg=None, command=None, reliefnormal=None, reliefactive=None, bd=None, text=None, font=None, height=None, width=None, cursor=None, activebackground=None, activeforeground=None, image=None, selectbg=None, selectfg=None, hoverimage=None):
        self.master2 = master
        self.bg2 = bg
        self.fg2 = fg
        self.command2 = command
        self.reliefnormal2 = reliefnormal
        self.reliefactive2 = reliefactive
        self.bd2 = bd
        self.text2 = text
        self.font2 = font
        self.width2, self.height2 = width, height
        self.cursor2 = cursor
        self.activebackground2 = activebackground
        self.activeforeground2 = activeforeground
        self.image2 = image
        self.selectbg2 = selectbg
        self.selectfg2 = selectfg
        self.hoverimage2 = hoverimage

        if self.master2 != None:
            self.master = self.master2
            self.LblBtnFr['master'] = self.master
        elif self.bg2 != None:
            self.bg = self.bg
            self.LblBtnFr['bg'] = self.bg
            self.LblBtn['bg'] = self.bg
        elif self.reliefnormal2 != None:
            self.reliefnormal = self.reliefnormal2
            self.LblBtnFr['relief'] = self.reliefnormal
        elif self.bd2 != None:
            self.bd = self.bd2
            self.LblBtnFr['bd'] = self.bd
        elif self.cursor2 != None:
            self.cursor = self.cursor2
            self.LblBtnFr['cursor'] = self.cursor
            self.LblBtn['cursor'] = self.cursor
        elif self.fg2 != None:
            self.fg = self.fg2
            self.LblBtn['fg'] = self.fg
        elif self.text2 != None:
            self.text = self.text2
            self.LblBtn['text'] = self.text
        elif self.font2 != None:
            self.font = self.font2
            self.LblBtn['font'] = self.font
        elif self.width2 != None:
            self.width = self.width2
            self.LblBtn['width'] = self.width
        elif self.height2 != None:
            self.height = self.height2
            self.LblBtn['height'] = self.height
        elif self.image2 != None:
            self.image = self.image2
            self.LblBtn['image'] = self.image
        elif self.command2 != None:
            self.command = self.command2
        elif self.activebackground2 != None:
            self.activebackground = self.activebackground2
        elif self.activeforeground2 != None:
            self.activeforeground = self.activeforeground2
        elif self.reliefactive2 != None:
            self.reliefactive = self.reliefactive2
        elif self.selectbg2 != None:
            self.selectbg = self.selectbg2
        elif self.selectfg2 != None:
            self.selectfg = self.selectfg2
        elif self.hoverimage2 != None:
            self.hoverimage = self.hoverimage2

    def delete(self):
        self.LblBtnFr.place_forget()
        self.LblBtnFr.pack_forget()
        self.LblBtnFr.grid_forget()
    def grid(self, row=None, column=None, sticky=None, padx=None, pady=None):
        self.row = row
        self.column = column
        self.sticky = sticky
        self.padx = padx
        self.pady = padx


        self.LblBtnFr.grid(row=self.row,
        column=self.column,
        sticky=self.sticky,
        padx=self.padx,
        pady=self.pady
        )
    def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
        self.side = side
    def place(self, x=None, anchor=None, y=None, relwidth=None, relx=None, rely=None, relheight=None, width=None, height=None):
        self.x = x
        self.y = y
        self.anchor = anchor
        self.relheight = relheight
        self.relwidth = relwidth
        self.width = width
        self.height = height
        self.rely = rely
        self.relx = relx
        self.LblBtnFr.place(x=self.x,
            anchor=self.anchor,
            relheight=self.relheight,
            width=self.width,
            rely=self.rely,
            relx=self.relx,
            y=self.y,
            relwidth=self.relwidth,
            height=self.height
        )
    def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
        self.side = side
        self.anchor = anchor
        self.expand = expand
        self.fill = fill
        self.padx, self.pady, self.ipadx, self.ipady = padx, pady, ipadx, ipady
        self.LblBtnFr.pack(side=self.side,
            anchor=self.anchor,
            expand=self.expand,
            fill=self.fill,
            padx=self.padx,
            pady=self.pady,
            ipadx=self.ipadx,
            ipady=self.ipady
        )
    def __init__(self, master=None, bg='#ececec', fg='#000000', command=None, reliefnormal=RAISED, reliefactive=SUNKEN, bd=1, text=None, font=None, height=None, width=None, cursor='hand1', activebackground=None, activeforeground=None, image=None, selectbg='white', selectfg='black', hoverimage=None):
        self.master = master
        self.bg = bg
        self.fg = fg
        self.command = command
        self.reliefnormal = reliefnormal
        self.reliefactive = reliefactive
        self.bd = bd
        self.text = text
        self.font = font
        self.width, self.height = width, height
        self.cursor = cursor
        self.activebackground = activebackground
        self.activeforeground = activeforeground
        self.image = image
        self.selectbg = selectbg
        self.selectfg = selectfg
        self.hoverimage = hoverimage

        self.hoverstate = False

        def activeon(event):
            self.LblBtnFr['relief'] = self.reliefactive
            self.LblBtn['bg'] = self.activebackground
            self.LblBtnFr['bg'] = self.bg
            self.LblBtn['fg'] = self.activeforeground
            self.LblBtn['image'] = self.hoverimage



        def activeoff(event):
            if self.hoverstate:
                self.LblBtnFr['relief'] = self.reliefnormal
                self.LblBtn['bg'] = self.bg
                self.LblBtnFr['bg'] = self.bg
                self.LblBtn['fg'] = self.fg
                self.LblBtn['image'] = self.image
                self.command()


        def hover(event):
            self.LblBtn['fg'] = self.selectfg
            self.LblBtn['bg'] = self.selectbg
            self.LblBtnFr['bg'] = self.selectbg
            self.LblBtn['relief'] = FLAT
            self.LblBtn['image'] = self.hoverimage
            self.hoverstate = True
        def unhover(event):
            self.LblBtn['fg'] = self.fg
            self.LblBtn['bg'] = self.bg
            self.LblBtnFr['bg'] = self.bg
            self.LblBtn['relief'] = FLAT
            self.LblBtn['image'] = self.image
            self.hoverstate = False

        self.LblBtnFr = tk.Frame(self.master, bg=self.bg, relief=self.reliefnormal, bd=self.bd, cursor=self.cursor)
        self.LblBtn = tk.Label(self.LblBtnFr, bg=self.bg, fg=self.fg, text=self.text, font=self.font, cursor=self.cursor, height=self.height, width=self.width, image=self.image)
        self.LblBtn.pack(fill=BOTH, expand=1)

        self.LblBtn.bind('<ButtonPress-1>', activeon)
        self.LblBtn.bind('<ButtonRelease-1>', activeoff)
        self.LblBtnFr.bind('<ButtonPress-1>', activeon)
        self.LblBtnFr.bind('<ButtonRelease-1>', activeoff)

        self.LblBtn.bind('<Enter>', hover)
        self.LblBtnFr.bind('<Enter>', hover)

        self.LblBtn.bind('<Leave>', unhover)
        self.LblBtnFr.bind('<Leave>', unhover)
        '''
        self.configure({key: value})
        return self._configure('configure', cnf, kw)
        self.tk.call(_flatten((self._w, cmd)) + self._options(cnf))
        '''
        self.LblBtn['bg'] = self.bg
        self.LblBtn['fg'] = self.fg
class LabelButton(tk.Label):
    def config(self, master=None, bg=None, fg=None, command=None, reliefnormal=None, reliefactive=None, bd=None, text=None, font=None, height=None, width=None, cursor=None, activebackground=None, activeforeground=None, image=None, selectbg=None, selectfg=None, hoverimage=None):
        self.master2 = master
        self.bg2 = bg
        self.fg2 = fg
        self.command2 = command
        self.reliefnormal2 = reliefnormal
        self.reliefactive2 = reliefactive
        self.bd2 = bd
        self.text2 = text
        self.font2 = font
        self.width2, self.height2 = width, height
        self.cursor2 = cursor
        self.activebackground2 = activebackground
        self.activeforeground2 = activeforeground
        self.image2 = image
        self.selectbg2 = selectbg
        self.selectfg2 = selectfg
        self.hoverimage2 = hoverimage

        if self.master2 != None:
            self.master = self.master2
            self.LblBtnFr['master'] = self.master
        elif self.bg2 != None:
            self.bg = self.bg
            self.LblBtnFr['bg'] = self.bg
            self.LblBtn['bg'] = self.bg
        elif self.reliefnormal2 != None:
            self.reliefnormal = self.reliefnormal2
            self.LblBtnFr['relief'] = self.reliefnormal
        elif self.bd2 != None:
            self.bd = self.bd2
            self.LblBtnFr['bd'] = self.bd
        elif self.cursor2 != None:
            self.cursor = self.cursor2
            self.LblBtnFr['cursor'] = self.cursor
            self.LblBtn['cursor'] = self.cursor
        elif self.fg2 != None:
            self.fg = self.fg2
            self.LblBtn['fg'] = self.fg
        elif self.text2 != None:
            self.text = self.text2
            self.LblBtn['text'] = self.text
        elif self.font2 != None:
            self.font = self.font2
            self.LblBtn['font'] = self.font
        elif self.width2 != None:
            self.width = self.width2
            self.LblBtn['width'] = self.width
        elif self.height2 != None:
            self.height = self.height2
            self.LblBtn['height'] = self.height
        elif self.image2 != None:
            self.image = self.image2
            self.LblBtn['image'] = self.image
        elif self.command2 != None:
            self.command = self.command2
        elif self.activebackground2 != None:
            self.activebackground = self.activebackground2
        elif self.activeforeground2 != None:
            self.activeforeground = self.activeforeground2
        elif self.reliefactive2 != None:
            self.reliefactive = self.reliefactive2
        elif self.selectbg2 != None:
            self.selectbg = self.selectbg2
        elif self.selectfg2 != None:
            self.selectfg = self.selectfg2
        elif self.hoverimage2 != None:
            self.hoverimage = self.hoverimage2

    def delete(self):
        self.LblBtnFrame.place_forget()
        self.LblBtnFrame.pack_forget()
        self.LblBtnFrame.grid_forget()
    def grid(self, row=None, column=None, sticky=None, padx=None, pady=None):
        self.row = row
        self.column = column
        self.sticky = sticky
        self.padx = padx
        self.pady = padx


        self.LblBtnFrame.grid(row=self.row,
        column=self.column,
        sticky=self.sticky,
        padx=self.padx,
        pady=self.pady
        )
    def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
        self.side = side
    def place(self, x=None, anchor=None, y=None, relwidth=None, relx=None, rely=None, relheight=None, width=None, height=None):
        self.x = x
        self.y = y
        self.anchor = anchor
        self.relheight = relheight
        self.relwidth = relwidth
        self.width = width
        self.height = height
        self.rely = rely
        self.relx = relx
        self.LblBtnFrame.place(x=self.x,
            anchor=self.anchor,
            relheight=self.relheight,
            width=self.width,
            rely=self.rely,
            relx=self.relx,
            y=self.y,
            relwidth=self.relwidth,
            height=self.height
        )
    def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
        self.side = side
        self.anchor = anchor
        self.expand = expand
        self.fill = fill
        self.padx, self.pady, self.ipadx, self.ipady = padx, pady, ipadx, ipady
        self.LblBtnFrame.pack(side=self.side,
            anchor=self.anchor,
            expand=self.expand,
            fill=self.fill,
            padx=self.padx,
            pady=self.pady,
            ipadx=self.ipadx,
            ipady=self.ipady
        )
    def __init__(self, master=None, bg='#ececec', fg='#000000', command=None, reliefnormal=RAISED, reliefactive=SUNKEN, bd=1, text=None, font=None, height=1, width=1, cursor='hand1', activebackground='white', activeforeground='black', image=None, selectbg='white', selectfg='black', hoverimage=None):
        self.master = master
        self.bg = bg
        self.fg = fg
        self.command = command
        self.reliefnormal = reliefnormal
        self.reliefactive = reliefactive
        self.bd = bd
        self.text = text
        self.font = font
        self.width, self.height = width, height
        self.cursor = cursor
        self.activebackground = activebackground
        self.activeforeground = activeforeground
        self.image = image
        self.selectbg = selectbg
        self.selectfg = selectfg
        self.hoverimage = hoverimage

        self.hoverstate = False

        def activeon(event):
            self.LblBtn.configure(fg_color=self.activebackground)
            self.LblBtn.configure(text_color=self.activeforeground)

        def activeoff(event):
            if self.hoverstate:
                self.LblBtn.configure(fg_color=self.bg)
                self.LblBtn.configure(text_color=self.fg)
                self.command()


        def hover(event):
            self.LblBtn.configure(text_color=self.selectfg)
            self.LblBtn.configure(fg_color=self.selectbg)
            self.master['cursor'] = 'hand1'
            self.hoverstate = True
        def unhover(event):
            self.LblBtn.configure(text_color=self.fg)
            self.LblBtn.configure(fg_color=self.bg)
            self.master['cursor'] = 'arrow'
            self.hoverstate = False

        self.LblBtnFrame = CTkFrame(self.master, corner_radius=7, fg_color='#9e9e9e')
        self.LblBtn = CTkLabel(self.LblBtnFrame, fg_color=self.bg, text_color=self.fg, text=self.text, corner_radius=7, width=self.width, font=self.font)
        self.LblBtn.pack(fill=BOTH, expand=1, padx=1, pady=1)

        self.LblBtn.bind('<ButtonPress-1>', activeon)
        self.LblBtn.bind('<ButtonRelease-1>', activeoff)

        self.LblBtn.bind('<Enter>', hover)
        self.LblBtn.bind('<Leave>', unhover)

class LabelButtonSystem(tk.Label):
    def config(self, master=None, bg=None, fg=None, command=None, reliefnormal=None, reliefactive=None, bd=None, text=None, font=None, height=None, width=None, cursor=None, activebackground=None, activeforeground=None, image=None, selectbg=None, selectfg=None, hoverimage=None):
        self.master2 = master
        self.bg2 = bg
        self.fg2 = fg
        self.command2 = command
        self.reliefnormal2 = reliefnormal
        self.reliefactive2 = reliefactive
        self.bd2 = bd
        self.text2 = text
        self.font2 = font
        self.width2, self.height2 = width, height
        self.cursor2 = cursor
        self.activebackground2 = activebackground
        self.activeforeground2 = activeforeground
        self.image2 = image
        self.selectbg2 = selectbg
        self.selectfg2 = selectfg
        self.hoverimage2 = hoverimage

        if self.master2 != None:
            self.master = self.master2
            self.LblBtnFr['master'] = self.master
        elif self.bg2 != None:
            self.bg = self.bg
            self.LblBtnFr['bg'] = self.bg
            self.LblBtn['bg'] = self.bg
        elif self.reliefnormal2 != None:
            self.reliefnormal = self.reliefnormal2
            self.LblBtnFr['relief'] = self.reliefnormal
        elif self.bd2 != None:
            self.bd = self.bd2
            self.LblBtnFr['bd'] = self.bd
        elif self.cursor2 != None:
            self.cursor = self.cursor2
            self.LblBtnFr['cursor'] = self.cursor
            self.LblBtn['cursor'] = self.cursor
        elif self.fg2 != None:
            self.fg = self.fg2
            self.LblBtn['fg'] = self.fg
        elif self.text2 != None:
            self.text = self.text2
            self.LblBtn['text'] = self.text
        elif self.font2 != None:
            self.font = self.font2
            self.LblBtn['font'] = self.font
        elif self.width2 != None:
            self.width = self.width2
            self.LblBtn['width'] = self.width
        elif self.height2 != None:
            self.height = self.height2
            self.LblBtn['height'] = self.height
        elif self.image2 != None:
            self.image = self.image2
            self.LblBtn['image'] = self.image
        elif self.command2 != None:
            self.command = self.command2
        elif self.activebackground2 != None:
            self.activebackground = self.activebackground2
        elif self.activeforeground2 != None:
            self.activeforeground = self.activeforeground2
        elif self.reliefactive2 != None:
            self.reliefactive = self.reliefactive2
        elif self.selectbg2 != None:
            self.selectbg = self.selectbg2
        elif self.selectfg2 != None:
            self.selectfg = self.selectfg2
        elif self.hoverimage2 != None:
            self.hoverimage = self.hoverimage2

    def delete(self):
        self.LblBtnFrame.place_forget()
        self.LblBtnFrame.pack_forget()
        self.LblBtnFrame.grid_forget()
    def grid(self, row=None, column=None, sticky=None, padx=None, pady=None):
        self.row = row
        self.column = column
        self.sticky = sticky
        self.padx = padx
        self.pady = padx


        self.LblBtnFrame.grid(row=self.row,
        column=self.column,
        sticky=self.sticky,
        padx=self.padx,
        pady=self.pady
        )
    def place(self, x=None, anchor=None, y=None, relwidth=None, relx=None, rely=None, relheight=None, width=None, height=None):
        self.x = x
        self.y = y
        self.anchor = anchor
        self.relheight = relheight
        self.relwidth = relwidth
        self.width = width
        self.height = height
        self.rely = rely
        self.relx = relx
        self.LblBtnFrame.place(x=self.x,
            anchor=self.anchor,
            relheight=self.relheight,
            width=self.width,
            rely=self.rely,
            relx=self.relx,
            y=self.y,
            relwidth=self.relwidth,
            height=self.height
        )
    def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
        self.side = side
        self.anchor = anchor
        self.expand = expand
        self.fill = fill
        self.padx, self.pady, self.ipadx, self.ipady = padx, pady, ipadx, ipady
        self.LblBtnFrame.pack(side=self.side,
            anchor=self.anchor,
            expand=self.expand,
            fill=self.fill,
            padx=self.padx,
            pady=self.pady,
            ipadx=self.ipadx,
            ipady=self.ipady
        )
    def __init__(self, master=None, bg='#ececec', fg='#000000', command=None, reliefnormal=RAISED, reliefactive=SUNKEN, bd=1, text=None, font=None, height=1, width=1, cursor='hand1', activebackground='white', activeforeground='black', image=None, selectbg='white', selectfg='black', hoverimage=None):
        self.master = master
        self.bg = bg
        self.fg = fg
        self.command = command
        self.reliefnormal = reliefnormal
        self.reliefactive = reliefactive
        self.bd = bd
        self.text = text
        self.font = font
        self.width, self.height = width, height
        self.cursor = cursor
        self.activebackground = activebackground
        self.activeforeground = activeforeground
        self.image = image
        self.selectbg = selectbg
        self.selectfg = selectfg
        self.hoverimage = hoverimage

        self.hoverstate = False

        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg1:
            self.bg = bg1.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg1:
            self.fg = fg1.read()


        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)

            homefolder = ''
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','registry_path.txt'), 'r', encoding='utf-8') as hf:
                homefolder = hf.read()

            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            self.theme_after = self.LblBtnFrame.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            #self.LblBtn['bg'] = bg_color
            self.bg = bg_color
            self.fg = fg_color
            self.LblBtn.configure(text_color=fg_color)
            self.LblBtn.configure(font=(font_, font_size+5))

            color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                color_rgb_activebackground[0] = 0
            else:
                color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

            if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                color_rgb_activebackground[1] = 0
            else:
                color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

            if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                color_rgb_activebackground[2] = 0
            else:
                color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

            self.activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            self.selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

            if self.hoverstate != 1:
                self.LblBtnFrame['bg'] = self.bg
                self.LblBtn.configure(fg_color=self.bg)
            else:
                pass

        def activeon(event):
            self.LblBtn.configure(fg_color=self.activebackground)

        def activeoff(event):
            if self.hoverstate:
                self.LblBtn.configure(fg_color=self.bg)
                self.command()


        def hover(event):
            self.LblBtn.configure(fg_color=self.selectbg)
            cursor = 'link.cur'
            self.master['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
            self.hoverstate = True
        def unhover(event):
            self.LblBtn.configure(fg_color=self.bg)
            cursor = 'Default.cur'
            self.master['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/{cursor}"
            self.hoverstate = False

        self.LblBtnFrame = CTkFrame(self.master, corner_radius=7, fg_color='#9e9e9e')
        self.LblBtn = CTkLabel(self.LblBtnFrame, fg_color=self.bg, text_color=self.fg, text=self.text, corner_radius=7, width=self.width, font=self.font)
        self.LblBtn.pack(fill=BOTH, expand=1, padx=2, pady=2)

        self.LblBtn.bind('<ButtonPress-1>', activeon)
        self.LblBtn.bind('<ButtonRelease-1>', activeoff)

        self.LblBtn.bind('<Enter>', hover)
        self.LblBtn.bind('<Leave>', unhover)
        theme_update()

class DialogWin():
    def destroy(self):
        self.a = 0.95
        def exiting(event=None):
            after_exit = self.root.after(10, exiting)
            if self.a < 0:
                self.root.after_cancel(after_exit)
                self.root.destroy()
            self.a -= 0.05
            try:
                self.root.wm_attributes('-alpha', self.a)
            except Exception:
                pass
        exiting()
    def __init__(self, master=None, title='Всплывающее окно', command=empty, type='message', text='', global_update=1):
        if type == 'message':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','dialogwin.wav'))
        elif type == 'warning':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','warning.wav'))
        elif type == 'error':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','error.wav'))
        self.master = master
        self.title = title
        self.command = command

        bg_tb = ''
        fg_tb = ''
        fontMaxOS = ''
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg1:
            bg_tb = bg1.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg1:
            fg_tb = fg1.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f1:
            fontMaxOS = f1.read()


        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0

            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            self.theme_after = self.root.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            self.root0.configure(fg_color=bg_color)
            self.root1['bg'] = bg_color
            self.title2['bg'] = bg_color
            self.title2['fg'] = fg_color
            self.title2['font'] = (font_, font_size)
            self.frameimgdesktop['bg'] = bg_color

            self.textLab['bg'] = bg_color

            self.textLab['fg'] = fg_color

            self.textLab['font'] = (font_, font_size)

            self.framebtns['bg'] = bg_color

        def GlobalUpdate():
            self.global_after = self.root.after(100, GlobalUpdate)
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','exit_user.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.root.destroy()
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','sleep_mode.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.root.withdraw()
                elif text == 'false':
                    self.root.deiconify()

        self.root = Toplevel(self.master)
        self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.a = 0
        def showing(event=None):
            after_show = self.root.after(10, showing)
            x = (self.root.winfo_screenwidth() - self.root.winfo_reqwidth()) / 2
            y = (self.root.winfo_screenheight() - self.root.winfo_reqheight()) / 2
            self.root.geometry("+%d+%d" % (x, y))
            if self.a > 0.9:
                self.root.after_cancel(after_show)
            self.a += 0.05
            self.root.wm_attributes('-alpha', self.a)
        showing()
        def passDEF(event=None):pass
        self.root.protocol('WM_DELETE_WINDOW', passDEF)
        self.root.wm_attributes('-alpha', 0.95)
        self.root.resizable(0,0)

        def startMove(event):
            global x, y
            x = event.x
            y = event.y
            #if sys.platform == 'darwin':self.root.overrideredirect(1)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        def stopMove(event):
            global x, y
            x = None
            y = None
            #if sys.platform == 'darwin':self.root.overrideredirect(0)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        def moving(event):
            global x, y
            x_ = (event.x_root - x)
            y_ = (event.y_root - y)
            self.root.geometry("+%s+%s" % (x_, y_))
            #if sys.platform == 'darwin':self.root.overrideredirect(1)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"

        if system == 'darwin':
            self.root.wm_attributes("-transparent", True)
            self.root.config(bg='systemTransparent')
        elif system == 'win32':
            self.root.wm_attributes("-transparentcolor", '#123456')
            self.root['bg'] = '#123456'
        self.root['bd'] = 7
        def top():
            self.root.after(10, top)
            self.root.wm_attributes('-topmost', 1)
            self.root.lift()
        top()

        self.root0 = CTkFrame(self.root, fg_color=bg_tb, corner_radius=15)
        self.root0.pack(expand=1, fill=BOTH)

        self.root1 = Frame(self.root0, bg=bg_tb)
        self.root1.pack(fill=BOTH, expand=1, padx=10, pady=10)

        self.root.wm_attributes('-topmost', 1)
        self.root.wm_overrideredirect(True)
        #if sys.platform == 'win32':
        #    self.root.wm_overrideredirect(True)
        #elif sys.platform == 'darwin':
        #    self.root.wm_overrideredirect(False)
        self.root.wm_attributes('-topmost', 1)
        self.title2 = Label(self.root1, bg=bg_tb, fg=fg_tb, text=self.title, font=(fontMaxOS, 15))
        self.title2.pack(anchor=NW, fill=X)
        self.title2.bind("<Button-1>", startMove)
        self.title2.bind("<ButtonRelease-1>", stopMove)
        self.title2.bind("<B1-Motion>", moving)
        self.frameimgdesktop = Frame(self.root1, bg=bg_tb, bd=7)
        self.frameimgdesktop.pack(anchor=NW, fill=BOTH, expand=1)

        self.textLab = Label(self.frameimgdesktop, text=text, justify='left')
        self.textLab.pack(anchor=NW, padx=5, pady=5)

        def OK(e=''):
            self.command()
            self.destroy()

        self.framebtns = Frame(self.frameimgdesktop)
        self.framebtns.pack(side=BOTTOM, fill=X, expand=1, anchor=NW)

        self.okbtn = LabelButtonSystem(self.framebtns, font=(fontMaxOS, 15), text=' OK ', width=15, bg=bg_tb, command=OK)
        self.okbtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        #self.closebtn = LabelButtonSystem(self.frameimgdesktop, font=(fontMaxOS, 15), text=(' '+'Отмена'+' '), width=15, bg=bg_tb, command=self.destroy)
        #self.closebtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        theme_update()
        if global_update:GlobalUpdate()
class WhatDialogWin():
    def destroy(self):
        self.a = 0.95
        def exiting(event=None):
            after_exit = self.root.after(10, exiting)
            if self.a < 0:
                self.root.after_cancel(after_exit)
                self.root.destroy()
            self.a -= 0.05
            try:
                self.root.wm_attributes('-alpha', self.a)
            except Exception:
                pass
        exiting()
    def __init__(self, master=None, title='Всплывающее окно', command=empty, type='message', text='', commandclose=empty, textyes='OK', textno='Закрыть', global_update=1):
        if type == 'message':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','dialogwin.wav'))
        elif type == 'warning':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','warning.wav'))
        elif type == 'error':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','error.wav'))
        self.master = master
        self.title = title
        self.command = command
        self.commandclose = commandclose

        bg_tb = ''
        fg_tb = ''
        fontMaxOS = ''
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg1:
            bg_tb = bg1.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg1:
            fg_tb = fg1.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f1:
            fontMaxOS = f1.read()


        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0

            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            self.theme_after = self.root.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            self.root0.configure(fg_color=bg_color)
            self.root1['bg'] = bg_color
            self.title2['bg'] = bg_color
            self.title2['fg'] = fg_color
            self.title2['font'] = (font_, font_size)
            self.frameimgdesktop['bg'] = bg_color

            self.textLab['bg'] = bg_color

            self.textLab['fg'] = fg_color

            self.textLab['font'] = (font_, font_size)

            self.framebtns['bg'] = bg_color

        def GlobalUpdate():
            self.global_after = self.root.after(100, GlobalUpdate)
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','exit_user.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.root.destroy()
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','sleep_mode.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.root.withdraw()
                elif text == 'false':
                    self.root.deiconify()

        self.root = Toplevel(self.master)
        self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.a = 0
        def showing(event=None):
            after_show = self.root.after(10, showing)
            x = (self.root.winfo_screenwidth() - self.root.winfo_reqwidth()) / 2
            y = (self.root.winfo_screenheight() - self.root.winfo_reqheight()) / 2
            self.root.geometry("+%d+%d" % (x, y))
            if self.a > 0.9:
                self.root.after_cancel(after_show)
            self.a += 0.05
            self.root.wm_attributes('-alpha', self.a)
        showing()
        def passDEF(event=None):pass
        self.root.protocol('WM_DELETE_WINDOW', passDEF)
        self.root.wm_attributes('-alpha', 0.95)
        self.root.resizable(0,0)

        def startMove(event):
            global x, y
            x = event.x
            y = event.y
            #if sys.platform == 'darwin':self.root.overrideredirect(1)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        def stopMove(event):
            global x, y
            x = None
            y = None
            #if sys.platform == 'darwin':self.root.overrideredirect(0)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        def moving(event):
            global x, y
            x_ = (event.x_root - x)
            y_ = (event.y_root - y)
            self.root.geometry("+%s+%s" % (x_, y_))
            #if sys.platform == 'darwin':self.root.overrideredirect(1)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"

        if system == 'darwin':
            self.root.wm_attributes("-transparent", True)
            self.root.config(bg='systemTransparent')
        elif system == 'win32':
            self.root.wm_attributes("-transparentcolor", '#123456')
            self.root['bg'] = '#123456'
        self.root['bd'] = 7
        def top():
            self.root.after(10, top)
            self.root.wm_attributes('-topmost', 1)
            self.root.lift()
        top()

        self.root0 = CTkFrame(self.root, fg_color=bg_tb, corner_radius=15)
        self.root0.pack(expand=1, fill=BOTH)

        self.root1 = Frame(self.root0, bg=bg_tb)
        self.root1.pack(fill=BOTH, expand=1, padx=10, pady=10)

        self.root.wm_attributes('-topmost', 1)
        self.root.wm_overrideredirect(True)
        #if sys.platform == 'win32':
        #    self.root.wm_overrideredirect(True)
        #elif sys.platform == 'darwin':
        #    self.root.wm_overrideredirect(False)
        self.root.wm_attributes('-topmost', 1)
        self.title2 = Label(self.root1, bg=bg_tb, fg=fg_tb, text=self.title, font=(fontMaxOS, 15))
        self.title2.pack(anchor=NW, fill=X)
        self.title2.bind("<Button-1>", startMove)
        self.title2.bind("<ButtonRelease-1>", stopMove)
        self.title2.bind("<B1-Motion>", moving)
        self.frameimgdesktop = Frame(self.root1, bg=bg_tb, bd=7)
        self.frameimgdesktop.pack(anchor=NW, fill=BOTH, expand=1)

        self.textLab = Label(self.frameimgdesktop, text=text, justify='left')
        self.textLab.pack(anchor=NW, padx=5, pady=5)

        def OK(e=''):
            self.command()


        self.framebtns = Frame(self.frameimgdesktop)
        self.framebtns.pack(side=BOTTOM, fill=X, expand=1, anchor=NW)

        self.okbtn = LabelButtonSystem(self.framebtns, font=(fontMaxOS, 15), text=(' '+textyes+' '), width=15, bg=bg_tb, command=OK)
        self.okbtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        def close():
            self.commandclose()
            self.destroy()

        self.closebtn = LabelButtonSystem(self.framebtns, font=(fontMaxOS, 15), text=(' '+textno+' '), width=15, bg=bg_tb, command=close)
        self.closebtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        theme_update()
        if global_update:GlobalUpdate()
class ColorDialogWin():
    def destroy(self):
        self.a = 0.95
        def exiting(event=None):
            after_exit = self.root.after(10, exiting)
            if self.a < 0:
                self.root.after_cancel(after_exit)
                self.root.destroy()
            self.a -= 0.05
            try:
                self.root.wm_attributes('-alpha', self.a)
            except Exception:
                pass
        exiting()
    def getcolorhex(self):
        a = self.entryhex.get()
        return a
    def getcolor(self):
        a = self.entryhex.get()
        return a
    def getcolor_(self, event=''):
        try:
            self.a = ImageColor.getcolor(self.entryhex.get(), "RGB")
            self.RV.set(self.a[0])
            self.GV.set(self.a[1])
            self.BV.set(self.a[2])
            self.col.configure(fg_color=self.entryhex.get())
        except Exception:
            if len(list(self.entryhex.get())) > 6:
                DialogWin(self.master, title='Ошибка', text=f'Извините\nНеверный цвет: {self.entryhex.get()}')
            elif len(list(self.entryhex.get())) <= 0:
                self.entryhex.insert(0, '#')

    def __init__(self, master=None, title='Выбрать цвет', command=None, type='message', global_update=1, color="#000000"):
        if type == 'message':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','dialogwin.wav'))
        elif type == 'warning':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','warning.wav'))
        elif type == 'error':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','error.wav'))
        bg_tb = ''
        fg_tb = ''
        fontMaxOS = ''
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg1:
            bg_tb = bg1.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg1:
            fg_tb = fg1.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f1:
            fontMaxOS = f1.read()
        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0

            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            self.theme_after = self.root.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            self.root0.configure(fg_color=bg_color)
            self.root1['bg'] = bg_color
            self.title2['bg'] = bg_color
            self.title2['fg'] = fg_color
            self.title2['font'] = (font_, font_size)
            self.framecolorsrgb['bg'] = bg_color
            self.framecolorsrgb2['bg'] = bg_color
            self.framecolorshex['bg'] = bg_color
            self.framecolorshex2['bg'] = bg_color
            self.framebtns['bg'] = bg_color
            self.framecolordesktop['bg'] = bg_color

        def GlobalUpdate():
            self.global_after = self.root.after(100, GlobalUpdate)
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','exit_user.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.root.destroy()
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','sleep_mode.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.root.withdraw()
                elif text == 'false':
                    self.root.deiconify()

        self.RC, self.GC, self.BC = 0, 0, 0
        self.master = master
        self.title = title
        self.command = command
        def startMove(event):
            global x, y
            x = event.x
            y = event.y
            #if sys.platform == 'darwin':self.root.overrideredirect(1)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        def stopMove(event):
            global x, y
            x = None
            y = None
            #if sys.platform == 'darwin':self.root.overrideredirect(0)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        def moving(event):
            global x, y
            x_ = (event.x_root - x)
            y_ = (event.y_root - y)
            self.root.geometry("+%s+%s" % (x_, y_))
            #if sys.platform == 'darwin':self.root.overrideredirect(1)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.root = Toplevel(self.master)
        self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.ab = 0
        def showing(event=None):
            after_show = self.root.after(10, showing)
            x = (self.root.winfo_screenwidth() - self.root.winfo_reqwidth()) / 2
            y = (self.root.winfo_screenheight() - self.root.winfo_reqheight()) / 2
            self.root.geometry("+%d+%d" % (x, y))
            if self.ab > 0.9:
                self.root.after_cancel(after_show)
            self.ab += 0.05
            self.root.wm_attributes('-alpha', self.ab)
        showing()
        self.root.title('')
        self.root.wm_attributes('-alpha', 0.95)
        self.root.minsize(500, 500)
        self.root.resizable(0,0)
        self.root.overrideredirect(1)
        #self.selectcolorroot.wm_overrideredirect(True)
        if system == 'darwin':
            self.root.wm_attributes("-transparent", True)
            self.root.config(bg='systemTransparent')
        elif system == 'win32':
            self.root.wm_attributes("-transparentcolor", '#123456')
            self.root['bg'] = '#123456'
        self.root['bd'] = 7
        self.root.wm_attributes('-topmost', 1)
        def top():
            self.root.after(10, top)
            self.root.wm_attributes('-topmost', 1)
            self.root.lift()
        top()

        self.root0 = CTkFrame(self.root, fg_color=bg_tb, corner_radius=15)
        self.root0.pack(expand=1, fill=BOTH)

        self.root1 = Frame(self.root0, bg=bg_tb)
        self.root1.pack(fill=BOTH, expand=1, padx=10, pady=10)

        self.title2 = Label(self.root1, bg=bg_tb, fg='white', text=self.title, font=(fontMaxOS, 15))

        self.title2.pack(anchor=NW, fill=X)
        self.title2.bind("<Button-1>", startMove)
        self.title2.bind("<ButtonRelease-1>", stopMove)
        self.title2.bind("<B1-Motion>", moving)
        self.framecolordesktop = Frame(self.root1, bg=bg_tb, bd=7)
        self.framecolordesktop.pack(anchor=NW, fill=BOTH, expand=1)
        self.col = CTkLabel(self.framecolordesktop, width=10, fg_color='black', corner_radius=20, text='')
        self.col.pack(fill=X, expand=1, anchor=NW)
        self.framecolorsrgb = Frame(self.framecolordesktop, bg=bg_tb, bd=2, relief=FLAT)
        self.framecolorsrgb.pack(fill=BOTH, expand=1)
        Label(self.framecolorsrgb, bg=bg_tb, fg='white', text='RGB', font=(fontMaxOS, 15)).pack(anchor=NW, fill=X)
        self.framecolorsrgb2 = Frame(self.framecolorsrgb, bg=bg_tb, bd=7, relief=FLAT)
        self.framecolorsrgb2.pack(fill=BOTH, expand=1)

        def R(value):
            def get_rgb(rgb):
                return "#%02x%02x%02x" % rgb
            self.RC = int(value)
            self.col.configure(fg_color=get_rgb((self.RC, self.GC, self.BC)))
            self.entryhex.delete(0, END)
            self.entryhex.insert(END, get_rgb((self.RC, self.GC, self.BC)))
        def G(value):
            def get_rgb(rgb):
                return "#%02x%02x%02x" % rgb
            self.GC = int(value)
            self.col.configure(fg_color=get_rgb((self.RC, self.GC, self.BC)))
            self.entryhex.delete(0, END)
            self.entryhex.insert(END, get_rgb((self.RC, self.GC, self.BC)))
        def B(value):
            def get_rgb(rgb):
                return "#%02x%02x%02x" % rgb
            self.BC = int(value)
            self.col.configure(fg_color=get_rgb((self.RC, self.GC, self.BC)))
            self.entryhex.delete(0, END)
            self.entryhex.insert(END, get_rgb((self.RC, self.GC, self.BC)))

        self.RV = IntVar(value=self.RC)
        self.GV = IntVar(value=self.GC)
        self.BV = IntVar(value=self.BC)

        self.scalellR = Scale(self.framecolorsrgb2, variable=self.RV, from_=0, to=255, orient=HORIZONTAL, command=R, font=(fontMaxOS, 15), bd=2, bg='#ff0000', fg='white')
        self.scalellR.pack(anchor=NW, fill=BOTH, expand=1)
        self.scalellG = Scale(self.framecolorsrgb2, variable=self.GV, from_=0, to=255, orient=HORIZONTAL, command=G, font=(fontMaxOS, 15), bd=2, bg='#00ff00', fg='black')
        self.scalellG.pack(anchor=NW, fill=BOTH, expand=1)
        self.scalellB = Scale(self.framecolorsrgb2, variable=self.BV, from_=0, to=255, orient=HORIZONTAL, command=B, font=(fontMaxOS, 15), bd=2, bg='#0000ff', fg='white')
        self.scalellB.pack(anchor=NW, fill=BOTH, expand=1)

        self.framecolorshex = Frame(self.framecolordesktop, bg=bg_tb, bd=2, relief=FLAT)
        self.framecolorshex.pack(fill=BOTH, expand=1)
        Label(self.framecolorshex, bg=bg_tb, fg='white', text='HEX', font=(fontMaxOS, 15)).pack(anchor=NW, fill=X)
        self.framecolorshex2 = Frame(self.framecolorshex, bg=bg_tb, bd=7, relief=FLAT)
        self.framecolorshex2.pack(fill=BOTH, expand=1)

        self.entryhex = EntryAuto(self.framecolorshex, placeholder='placeholder')
        self.entryhex.pack(fill=BOTH, expand=1)
        self.entryhex.insert(END, color)

        self.getcolor_()



        self.entryhex.bind('<KeyPress>', self.getcolor_)
        self.entryhex.bind('<KeyRelease>', self.getcolor_)

        self.framebtns = Frame(self.framecolordesktop, bg=bg_tb)
        self.framebtns.pack(side=BOTTOM, fill=X, expand=1, anchor=NW)

        def OK(e=''):
            self.command()

        self.okbtn = LabelButtonSystem(self.framebtns, font=(fontMaxOS, 15), text=(' '+'OK'+' '), width=15, bg=bg_tb, command=OK)
        self.okbtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        self.closebtn = LabelButtonSystem(self.framebtns, font=(fontMaxOS, 15), text=(' '+'Закрыть'+' '), width=15, bg=bg_tb, command=self.destroy)
        self.closebtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)
        def focusroot(event=None):
            self.root.wm_overrideredirect(True)
            self.root.wm_attributes('-topmost', 1)
        self.root.bind('<Map>', focusroot)
        theme_update()
        if global_update:GlobalUpdate()

class DialogWinCustom():
    def destroy(self):
        self.a = 0.95
        def exiting(event=None):
            after_exit = self.root.after(10, exiting)
            if self.a < 0:
                self.root.after_cancel(after_exit)
                self.root.destroy()
            self.a -= 0.05
            try:
                self.root.wm_attributes('-alpha', self.a)
            except Exception:
                pass
        exiting()
    def title(self, text):
        self.title2['text'] = text
    def __init__(self, master=None, type='message', global_update=1):
        if type == 'message':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','dialogwin.wav'))
        elif type == 'warning':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','warning.wav'))
        elif type == 'error':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','error.wav'))
        self.master = master

        bg_tb = ''
        fg_tb = ''
        fontMaxOS = ''
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg1:
            bg_tb = bg1.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg1:
            fg_tb = fg1.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f1:
            fontMaxOS = f1.read()


        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0

            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            self.theme_after = self.root.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            self.root0.configure(fg_color=bg_color)
            self.root1['bg'] = bg_color
            self.title2['bg'] = bg_color
            self.title2['fg'] = fg_color
            self.title2['font'] = (font_, font_size)
            self.content['bg'] = bg_color


            self.framebtns['bg'] = bg_color

        def GlobalUpdate():
            self.global_after = self.root.after(100, GlobalUpdate)
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','exit_user.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.root.destroy()
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','sleep_mode.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.root.withdraw()
                elif text == 'false':
                    self.root.deiconify()

        self.root = Toplevel(self.master)
        self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.a = 0
        def showing(event=None):
            after_show = self.root.after(10, showing)
            x = (self.root.winfo_screenwidth() - self.root.winfo_reqwidth()) / 2
            y = (self.root.winfo_screenheight() - self.root.winfo_reqheight()) / 2
            self.root.geometry("+%d+%d" % (x, y))
            if self.a > 0.9:
                self.root.after_cancel(after_show)
            self.a += 0.05
            self.root.wm_attributes('-alpha', self.a)
        showing()
        def passDEF(event=None):pass
        self.root.protocol('WM_DELETE_WINDOW', passDEF)
        self.root.wm_attributes('-alpha', 0.95)
        self.root.resizable(0,0)

        def startMove(event):
            global x, y
            x = event.x
            y = event.y
            #if sys.platform == 'darwin':self.root.overrideredirect(1)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        def stopMove(event):
            global x, y
            x = None
            y = None
            #if sys.platform == 'darwin':self.root.overrideredirect(0)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        def moving(event):
            global x, y
            x_ = (event.x_root - x)
            y_ = (event.y_root - y)
            self.root.geometry("+%s+%s" % (x_, y_))
            #if sys.platform == 'darwin':self.root.overrideredirect(1)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"

        if system == 'darwin':
            self.root.wm_attributes("-transparent", True)
            self.root.config(bg='systemTransparent')
        elif system == 'win32':
            self.root.wm_attributes("-transparentcolor", '#123456')
            self.root['bg'] = '#123456'
        self.root['bd'] = 7
        def top():
            self.root.after(10, top)
            self.root.wm_attributes('-topmost', 1)
            self.root.lift()
        top()

        self.root0 = CTkFrame(self.root, fg_color=bg_tb, corner_radius=15)
        self.root0.pack(expand=1, fill=BOTH)

        self.root1 = Frame(self.root0, bg=bg_tb)
        self.root1.pack(fill=BOTH, expand=1, padx=10, pady=10)

        self.root.wm_attributes('-topmost', 1)
        self.root.wm_overrideredirect(True)
        #if sys.platform == 'win32':
        #    self.root.wm_overrideredirect(True)
        #elif sys.platform == 'darwin':
        #    self.root.wm_overrideredirect(False)
        self.root.wm_attributes('-topmost', 1)
        self.title2 = Label(self.root1, bg=bg_tb, fg=fg_tb, text='DialogWin', font=(fontMaxOS, 15))
        self.title2.pack(anchor=NW, fill=X)
        self.title2.bind("<Button-1>", startMove)
        self.title2.bind("<ButtonRelease-1>", stopMove)
        self.title2.bind("<B1-Motion>", moving)
        self.content = Frame(self.root1, bg=bg_tb, bd=7)
        self.content.pack(anchor=NW, fill=BOTH, expand=1)

        def OK(e=''):
            self.command()
            self.destroy()

        self.framebtns = Frame(self.content)
        self.framebtns.pack(side=BOTTOM, fill=X, expand=1, anchor=NW)

        #self.okbtn = LabelButtonSystem(self.framebtns, font=(fontMaxOS, 15), text=' OK ', width=15, bg=bg_tb, command=OK)
        #self.okbtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        #self.closebtn = LabelButtonSystem(self.frameimgdesktop, font=(fontMaxOS, 15), text=(' '+'Отмена'+' '), width=15, bg=bg_tb, command=self.destroy)
        #self.closebtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        theme_update()
        if global_update:GlobalUpdate()

class CameraBox():
    def destroy(self):
        self.frame1.destroy()
    def show_frames(self):
        self.box.show_frames()
    def __init__(self, master, width, height):
        self.frame1 = Frame(master)
        self.frame1.pack()

        self.box = Box(self.frame1, width=width, height=width)

class WebCamDialogWin():
    def destroy(self):
        self.a = 0.95
        if self.camera_box != '':self.camera_box.destroy()
        if self.camera != '':self.camera.release()
        def exiting(event=None):
            after_exit = self.root.after(10, exiting)
            if self.a < 0:
                self.root.after_cancel(after_exit)
                self.root.destroy()
            self.a -= 0.05
            try:
                self.root.wm_attributes('-alpha', self.a)
            except Exception:
                pass
        exiting()

    def getphoto(self):
        return Image.open(self.name)

    def getpath(self):
        return self.name

    def clean_clipboard(self):
        os.remove(self.name)

    def __init__(self, master=None, title='Сделать фото', command=empty, type='message', text='', commandclose=empty, textyes='OK', textno='Закрыть', global_update=1):
        if type == 'message':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','dialogwin.wav'))
        elif type == 'warning':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','warning.wav'))
        elif type == 'error':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','error.wav'))
        self.master = master
        self.title = title
        self.command = command
        self.commandclose = commandclose

        bg_tb = ''
        fg_tb = ''
        fontMaxOS = ''
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg1:
            bg_tb = bg1.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg1:
            fg_tb = fg1.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f1:
            fontMaxOS = f1.read()


        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0

            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            self.theme_after = self.root.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            self.root0.configure(fg_color=bg_color)
            self.root1['bg'] = bg_color
            self.title2['bg'] = bg_color
            self.title2['fg'] = fg_color
            self.title2['font'] = (font_, font_size)
            self.frameimgdesktop['bg'] = bg_color

            self.framebtns1['bg'] = bg_color
            self.framebtns2['bg'] = bg_color
            self.camera_frame1['bg'] = bg_color

        def GlobalUpdate():
            self.global_after = self.root.after(100, GlobalUpdate)
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','exit_user.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.root.destroy()
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','sleep_mode.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.root.withdraw()
                elif text == 'false':
                    self.root.deiconify()

        self.root = Toplevel(self.master)
        self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.a = 0
        def showing(event=None):
            after_show = self.root.after(10, showing)
            x = (self.root.winfo_screenwidth() - self.root.winfo_reqwidth()) / 2
            y = (self.root.winfo_screenheight() - self.root.winfo_reqheight()) / 2
            self.root.geometry("+%d+%d" % (x, y))
            if self.a > 0.9:
                self.root.after_cancel(after_show)
            self.a += 0.05
            self.root.wm_attributes('-alpha', self.a)
        def passDEF(event=None):pass
        self.root.protocol('WM_DELETE_WINDOW', passDEF)
        self.root.wm_attributes('-alpha', 0.95)
        self.root.resizable(0,0)

        def startMove(event):
            global x, y
            x = event.x
            y = event.y
            #if sys.platform == 'darwin':self.root.overrideredirect(1)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        def stopMove(event):
            global x, y
            x = None
            y = None
            #if sys.platform == 'darwin':self.root.overrideredirect(0)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        def moving(event):
            global x, y
            x_ = (event.x_root - x)
            y_ = (event.y_root - y)
            self.root.geometry("+%s+%s" % (x_, y_))
            #if sys.platform == 'darwin':self.root.overrideredirect(1)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"

        if system == 'darwin':
            self.root.wm_attributes("-transparent", True)
            self.root.config(bg='systemTransparent')
        elif system == 'win32':
            self.root.wm_attributes("-transparentcolor", '#123456')
            self.root['bg'] = '#123456'
        self.root['bd'] = 7
        def top():
            self.root.after(10, top)
            self.root.wm_attributes('-topmost', 1)
            self.root.lift()
        top()

        self.root0 = CTkFrame(self.root, fg_color=bg_tb, corner_radius=15)
        self.root0.pack(expand=1, fill=BOTH)

        self.root1 = Frame(self.root0, bg=bg_tb)
        self.root1.pack(fill=BOTH, expand=1, padx=10, pady=10)

        self.root.wm_attributes('-topmost', 1)
        self.root.wm_overrideredirect(True)
        #if sys.platform == 'win32':
        #    self.root.wm_overrideredirect(True)
        #elif sys.platform == 'darwin':
        #    self.root.wm_overrideredirect(False)
        self.root.wm_attributes('-topmost', 1)
        self.title2 = Label(self.root1, bg=bg_tb, fg=fg_tb, text=self.title, font=(fontMaxOS, 15))
        self.title2.pack(anchor=NW, fill=X)
        self.title2.bind("<Button-1>", startMove)
        self.title2.bind("<ButtonRelease-1>", stopMove)
        self.title2.bind("<B1-Motion>", moving)
        self.frameimgdesktop = Frame(self.root1, bg=bg_tb, bd=7)
        self.frameimgdesktop.pack(anchor=NW, fill=BOTH, expand=1)

        self.camera = cv2.VideoCapture(0)


        #for i in range(30):
        #    self.camera.read()

        self.camera_frame1 = Frame(self.frameimgdesktop, bg=bg_tb, bd=7)
        self.camera_frame1.pack(anchor=NW, fill=BOTH, expand=1)

        self.lab_photo = Label(self.camera_frame1)

        self.camera_box = CameraBox(self.camera_frame1, width=500, height=500)
        #self.camera_box.show_frames()

        def OK(e=''):
            self.command()
            self.destroy()


        self.name = ''

        self.save_state = 0

        def OKPhotoMake():
            self.camera_box.destroy()
            self.camera_box = ''
            ret, frame = self.camera.read()
            self.name = str(Path("MaxOS","!Registry","SYSTEM","SYSTEM_INPUT","WEB_CAMERA","CLIP_BOARD",f"webcam_photo_{random.randint(1000, 100000)}.png"))
            cv2.imwrite(self.name, frame)

            def crop_center(pil_img, crop_width: int, crop_height: int) -> Image:
                """
                Функция для обрезки изображения по центру.
                """
                img_width, img_height = pil_img.size
                return pil_img.crop(((img_width - crop_width) // 2,
                                     (img_height - crop_height) // 2,
                                     (img_width + crop_width) // 2,
                                     (img_height + crop_height) // 2))
            def crop_max_square(pil_img):
                return crop_center(pil_img, min(pil_img.size), min(pil_img.size))

            im = Image.open(self.name)
            im_new = crop_max_square(im)
            os.remove(self.name)
            im_new.save(self.name, quality=95)

            self.lab_photo.pack()
            photo = Image.open(self.name)
            photo = photo.resize((500, 500), Image.ANTIALIAS)
            photo = ImageTk.PhotoImage(photo)
            self.lab_photo.image = photo
            self.lab_photo['image'] = self.lab_photo.image
            self.framebtns1.pack_forget()
            self.framebtns2.pack(side=BOTTOM, fill=X, expand=1, anchor=NW)
            self.camera.release()
            self.camera = ''

        self.framebtns1 = Frame(self.frameimgdesktop)
        self.framebtns1.pack(side=BOTTOM, fill=X, expand=1, anchor=NW)

        self.okbtn1 = LabelButtonSystem(self.framebtns1, font=(fontMaxOS, 15), text=(' '+'Сделать фото'+' '), width=15, bg=bg_tb, command=OKPhotoMake)
        self.okbtn1.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        def close():
            self.commandclose()
            if self.save_state == 0:
                if self.name != '':
                    os.remove(self.name)
            if self.camera != '':self.camera.release()
            self.destroy()

        self.closebtn1 = LabelButtonSystem(self.framebtns1, font=(fontMaxOS, 15), text=(' '+'Закрыть'+' '), width=15, bg=bg_tb, command=close)
        self.closebtn1.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)



        self.framebtns2 = Frame(self.frameimgdesktop)

        self.okbtn2 = LabelButtonSystem(self.framebtns2, font=(fontMaxOS, 15), text=(' '+'OK'+' '), width=15, bg=bg_tb, command=OK)
        self.okbtn2.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        def back():
            self.save_state = 0
            os.remove(self.name)
            self.camera = cv2.VideoCapture(0)
            self.framebtns2.pack_forget()
            self.framebtns1.pack(side=BOTTOM, fill=X, expand=1, anchor=NW)
            self.lab_photo.pack_forget()
            self.name = ''
            self.camera_box = CameraBox(self.camera_frame1, width=500, height=500)
            self.camera_box.show_frames()

        self.backbtn = LabelButtonSystem(self.framebtns2, font=(fontMaxOS, 15), text=(' '+'Переснять'+' '), width=15, bg=bg_tb, command=back)
        self.backbtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        self.closebtn2 = LabelButtonSystem(self.framebtns2, font=(fontMaxOS, 15), text=(' '+'Закрыть'+' '), width=15, bg=bg_tb, command=close)
        self.closebtn2.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        theme_update()
        if global_update:GlobalUpdate()

        self.camera_box.show_frames()
        showing()

class ThemeButtons():
    def delete(self):
        self.icontheme4.after_cancel(self.theme_after)
        self.icontheme4.pack_forget()
    def destroy(self):
        self.icontheme4.after_cancel(self.theme_after)
        self.icontheme4.destroy()
    def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
        self.side = side
        self.anchor = anchor
        self.expand = expand
        self.fill = fill
        self.padx, self.pady, self.ipadx, self.ipady = padx, pady, ipadx, ipady
        self.icontheme4.pack(side=self.side,
            anchor=self.anchor,
            expand=self.expand,
            fill=self.fill,
            padx=self.padx,
            pady=self.pady,
            ipadx=self.ipadx,
            ipady=self.ipady
        )
    def __init__(self, master, bg, fg, command):
        def theme_update():
            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)
            self.theme_after = self.icontheme4.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())

            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

            self.icontheme4['bg'] = selectbg

        def color_img(img, color):
            img = Image.open(img)
            pixdata = img.load()
            r, g, b, = ImageColor.getcolor(color, "RGB")
            for y in range(img.size[1]):
                for x in range(img.size[0]):
                    alpha = pixdata[x, y][3]
                    if alpha:
                        pixdata[x, y] = (r, g, b, alpha)
            return img

        self.custom_user_icontheme = color_img(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','window.png'), color=bg)
        self.custom_user_icontheme.paste(color_img(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','title.png'), color=fg), (0,0), color_img(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','title.png'), color=fg))
        self.custom_user_icontheme.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','icon.png')), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','icon.png')))

        self.icontheme4_ = self.custom_user_icontheme
        self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
        #self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
        self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)
        self.HOVER_icontheme4_STATE = 0
        self.ACTIVE_icontheme4_STATE = 0
        def hover_up_tb(e=''):
            self.icontheme4_ = self.custom_user_icontheme
            self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
            self.icontheme4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
            self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)

            self.icontheme4.image = self.icontheme4_
            self.icontheme4['image'] = self.icontheme4.image
            self.HOVER_icontheme4_STATE = 1
        def unhover_up_tb(e=''):
            if self.ACTIVE_icontheme4_STATE:
                self.icontheme4_ = self.custom_user_icontheme
                self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
                self.icontheme4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)

                self.icontheme4.image = self.icontheme4_
                self.icontheme4['image'] = self.icontheme4.image
            else:
                self.icontheme4_ = self.custom_user_icontheme
                self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
                self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)

                self.icontheme4.image = self.icontheme4_
                self.icontheme4['image'] = self.icontheme4.image
            self.HOVER_icontheme4_STATE = 0
        self.icontheme4 = Label(master, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
        self.icontheme4.image = self.icontheme4_
        self.icontheme4['image'] = self.icontheme4.image
        self.icontheme4.bind('<Enter>', hover_up_tb)
        self.icontheme4.bind('<Leave>', unhover_up_tb)
        def cmd_up_tb1(e=''):
            self.icontheme4_ = self.custom_user_icontheme
            self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
            self.icontheme4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
            self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)

            self.icontheme4.image = self.icontheme4_
            self.icontheme4['image'] = self.icontheme4.image

            self.ACTIVE_icontheme4_STATE = 1
        def cmd_up_tb2(e=''):
            if self.HOVER_icontheme4_STATE:
                self.icontheme4_ = self.custom_user_icontheme
                self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
                self.icontheme4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)

                self.icontheme4.image = self.icontheme4_
                self.icontheme4['image'] = self.icontheme4.image
                command()
            else:
                self.icontheme4_ = self.custom_user_icontheme
                self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
                #self.icontheme4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)

                self.icontheme4.image = self.icontheme4_
                self.icontheme4['image'] = self.icontheme4.image

            self.ACTIVE_icontheme4_STATE = 0
        self.icontheme4.bind('<ButtonPress-1>', cmd_up_tb1)
        self.icontheme4.bind('<ButtonRelease-1>', cmd_up_tb2)

        theme_update()

class FileDialogWin():
    def destroy(self):
        self.a = 0.95
        def exiting(event=None):
            after_exit = self.root.after(10, exiting)
            if self.a < 0:
                self.root.after_cancel(after_exit)
                self.root.destroy()
            self.a -= 0.05
            try:
                self.root.wm_attributes('-alpha', self.a)
            except Exception:
                pass
        exiting()

    def getpath(self):
        path = self.path_entry.get()
        if hdd_word.lower() in path.lower():
            path = self.path_entry.get().split(f':{os.sep}')[1]
        if path == '':
            path = '.'
        element = self.listbox.get(self.listbox.curselection()[0])
        name = os.path.splitext(element)[0]
        ext = os.path.splitext(element)[1].lower()

        name_file = f"{' '.join(name.split())}{ext}"

        return str(Path(path,f"{name_file}"))

    def __init__(self, master=None, title='Всплывающее окно', command=empty, type='message', text='', commandclose=empty, textyes='OK', textno='Закрыть', ext_list='none', global_update=1, folder='.'):
        if type == 'message':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','dialogwin.wav'))
        elif type == 'warning':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','warning.wav'))
        elif type == 'error':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','error.wav'))
        self.master = master
        self.title = title
        self.command = command
        self.commandclose = commandclose

        bg_tb = ''
        fg_tb = ''
        fontMaxOS = ''
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg1:
            bg_tb = bg1.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg1:
            fg_tb = fg1.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f1:
            fontMaxOS = f1.read()


        def theme_update():
            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0

            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            self.theme_after = self.root.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            self.root0.configure(fg_color=bg_color)
            self.root1['bg'] = bg_color
            self.title2['bg'] = bg_color
            self.title2['fg'] = fg_color
            self.title2['font'] = (font_, font_size)
            self.frameimgdesktop['bg'] = bg_color

            self.framebtns['bg'] = bg_color


            color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                color_rgb_activebackground[0] = 0
            else:
                color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

            if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                color_rgb_activebackground[1] = 0
            else:
                color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

            if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                color_rgb_activebackground[2] = 0
            else:
                color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

            activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

            self.frameright.configure(fg_color=bg_color)

            self.frame_main['bg'] = bg_color

            self.frame_path['bg'] = bg_color

            self.listbox['bg'] = bg_color
            self.listbox['fg'] = fg_color
            self.listbox['selectbackground'] = selectbg
            self.listbox['selectforeground'] = fg_color
            self.listbox['font'] = ('Cousine', font_size+3)
            self.listbox['highlightbackground'] = bg_color

        def GlobalUpdate():
            self.global_after = self.root.after(100, GlobalUpdate)
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','exit_user.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.root.destroy()
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','sleep_mode.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.root.withdraw()
                elif text == 'false':
                    self.root.deiconify()

        self.root = Toplevel(self.master)
        self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.a = 0
        self.ext_list = ext_list
        def showing(event=None):
            after_show = self.root.after(10, showing)
            x = (self.root.winfo_screenwidth() - self.root.winfo_reqwidth()) / 2
            y = (self.root.winfo_screenheight() - self.root.winfo_reqheight()) / 2
            self.root.geometry("+%d+%d" % (x, y))
            if self.a > 0.9:
                self.root.after_cancel(after_show)
            self.a += 0.05
            self.root.wm_attributes('-alpha', self.a)
        showing()
        def passDEF(event=None):pass
        self.root.protocol('WM_DELETE_WINDOW', passDEF)
        self.root.wm_attributes('-alpha', 0.95)
        self.root.resizable(0,0)

        def startMove(event):
            global x, y
            x = event.x
            y = event.y
            #if sys.platform == 'darwin':self.root.overrideredirect(1)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        def stopMove(event):
            global x, y
            x = None
            y = None
            #if sys.platform == 'darwin':self.root.overrideredirect(0)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        def moving(event):
            global x, y
            x_ = (event.x_root - x)
            y_ = (event.y_root - y)
            self.root.geometry("+%s+%s" % (x_, y_))
            #if sys.platform == 'darwin':self.root.overrideredirect(1)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"

        if system == 'darwin':
            self.root.wm_attributes("-transparent", True)
            self.root.config(bg='systemTransparent')
        elif system == 'win32':
            self.root.wm_attributes("-transparentcolor", '#123456')
            self.root['bg'] = '#123456'
        self.root['bd'] = 7
        def top():
            self.root.after(10, top)
            self.root.wm_attributes('-topmost', 1)
            self.root.lift()
        top()

        self.root0 = CTkFrame(self.root, fg_color=bg_tb, corner_radius=15)
        self.root0.pack(expand=1, fill=BOTH)

        self.root1 = Frame(self.root0, bg=bg_tb)
        self.root1.pack(fill=BOTH, expand=1, padx=10, pady=10)

        self.root.wm_attributes('-topmost', 1)
        self.root.wm_overrideredirect(True)
        #if sys.platform == 'win32':
        #    self.root.wm_overrideredirect(True)
        #elif sys.platform == 'darwin':
        #    self.root.wm_overrideredirect(False)
        self.root.wm_attributes('-topmost', 1)
        self.title2 = Label(self.root1, bg=bg_tb, fg=fg_tb, text=self.title, font=(fontMaxOS, 15))
        self.title2.pack(anchor=NW, fill=X)
        self.title2.bind("<Button-1>", startMove)
        self.title2.bind("<ButtonRelease-1>", stopMove)
        self.title2.bind("<B1-Motion>", moving)
        self.frameimgdesktop = Frame(self.root1, bg=bg_tb, bd=7)
        self.frameimgdesktop.pack(anchor=NW, fill=BOTH, expand=1)

        self.frame_main = Frame(self.frameimgdesktop)
        self.frame_main.pack(fill=BOTH, side=TOP, expand=1, anchor=NW)

        self.frame_path = Frame(self.frame_main)
        self.frame_path.pack(fill=X)

        def update(e=''):
            def rjust(name, ext):
                len1 = len(name) - len(ext)
                return f"{name}{ext.rjust(25-len1)}"
            path = self.path_entry.get()
            if hdd_word.lower() in path.lower():
                path = self.path_entry.get().split(f':{os.sep}')[1]
            if path == '':
                path = '.'
            self.listbox.delete(0, END)
            try:
                for i in sorted(os.listdir(path)):
                    if i[0] == '!' or i[0] == '.':pass
                    else:
                        if os.path.isdir(Path(path, i)):
                            if os.path.splitext(i)[1] == '':
                                name = os.path.splitext(i)[0]
                                ext = '.<FOLD>'
                                self.listbox.insert(END, rjust(name, ext))

                for i in sorted(os.listdir(path)):
                    if i[0] == '!' or i[0] == '.':pass
                    else:
                        if os.path.isdir(Path(path, i)):
                            pass
                        else:
                            if self.ext_list == 'none':pass
                            else:
                                if os.path.splitext(i)[1].lower() in self.ext_list:
                                    name = os.path.splitext(i)[0]
                                    ext = os.path.splitext(i)[1].upper()
                                    self.listbox.insert(END, rjust(name, ext))
            except:
                pass

        def back(e=''):
            path = self.path_entry.get()
            self.path_entry.delete(0, END)
            new_path = os.path.split(path)[0]
            if new_path.lower() == hdd_word.lower():
                self.path_entry.insert(END, f"{hdd_word}{os.sep}")
            else:
                self.path_entry.insert(END, os.path.split(path)[0])
            update()

        LabelButtonSystem(self.frame_path, text='<', command=back).pack(side=LEFT, padx=2, pady=2)

        self.path_entry = EntryAuto(self.frame_path, placeholder='placeholder')
        self.path_entry.pack(fill=X, side=LEFT, expand=1, padx=2, pady=2)
        self.path_entry.bind('<KeyRelease>', update)
        for i in psutil.disk_partitions():
            if i.mountpoint in f"{Path(folder)}":
                self.path_entry.insert(END, f"{Path(folder)}")
                break
        else:
            if folder == '.':
                self.path_entry.insert(END, f"{hdd_word}{os.sep}")
            else:
                self.path_entry.insert(END, f"{hdd_word}{os.sep}{Path(folder)}")

        self.frameright = CTkFrame(self.frame_main, width=200, corner_radius=0)
        self.frameright.pack(fill=BOTH, expand=1)

        def select(e=''):
            try:
                path = self.path_entry.get()
                if hdd_word.lower() in path.lower():
                    path = self.path_entry.get().split(f':{os.sep}')[1]
                element = self.listbox.get(self.listbox.curselection()[0])
                name = os.path.splitext(element)[0]
                ext = os.path.splitext(element)[1].lower()



                if ext.lower() == '.<fold>':
                    ext = ''
                else:pass
                name_file = f"{' '.join(name.split())}{ext}"
                if os.path.isdir(Path(path, f"{name_file}{ext}")):
                    self.path_entry.delete(0, END)
                    for i in psutil.disk_partitions():
                        if i.mountpoint in f"{Path(path)}":
                            self.path_entry.insert(END, f"{Path(path, name_file)}")
                            break
                    else:
                        self.path_entry.insert(END, f"{hdd_word}{os.sep}{Path(path, name_file)}")
                    update()
                else:
                    self.command()
            except:
                pass

        def files_menu(e=''):
            path = self.path_entry.get()
            if hdd_word in path:
                path = self.path_entry.get().split(f':{os.sep}')[1]
            element = self.listbox.get(self.listbox.curselection()[0])
            name = element.split()[0]
            ext = element.split()[1].lower()

            if ext.lower() == '<fold>':
                ext = ''
            else:pass
            if os.path.isdir(Path(path, f"{name}{ext}")):pass

        self.listbox = Listbox(self.frameright, highlightthickness=0, exportselection=0, relief='flat', cursor='@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur', width=50, height=10)
        self.listbox.pack(fill=BOTH, expand=1)
        self.listbox.bind('<Double-Button-1>', select)
        self.listbox.bind('<Return>', select)
        self.listbox.bind('<Control-Button-1>', files_menu)
        self.listbox.bind('<Button-2>', files_menu)
        self.listbox.bind('<Button-3>', files_menu)

        update()

        def GlobalUpdate2():
            self.global_after = self.root.after(500, GlobalUpdate)
            def check_dir():
                dir1 = len(os.listdir())
                time.sleep(0.1)
                dir2 = len(os.listdir())

                if dir1 != dir2:
                    update()
            Thread(target=check_dir, daemon=1).start()

            def check_path():
                path1 = self.path_entry.get()
                time.sleep(0.1)
                path2 = self.path_entry.get()

                if path1 != path2:
                    update()
            #Thread(target=check_path, daemon=1).start()


        #Files(self.frameright, path=self.path_entry).pack(fill=BOTH, expand=1)


        #self.root1.bind('<Map>', self.root1.center)

        GlobalUpdate2()



        def OK(e=''):
            try:
                select()
            except:
                pass


        self.framebtns = Frame(self.frameimgdesktop)
        self.framebtns.pack(side=BOTTOM, fill=X, expand=1, anchor=NW)

        self.okbtn = LabelButtonSystem(self.framebtns, font=(fontMaxOS, 15), text=(' '+textyes+' '), width=15, bg=bg_tb, command=OK)
        self.okbtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        def close():
            self.commandclose()
            self.destroy()

        self.closebtn = LabelButtonSystem(self.framebtns, font=(fontMaxOS, 15), text=(' '+textno+' '), width=15, bg=bg_tb, command=close)
        self.closebtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        theme_update()
        if global_update:GlobalUpdate()

class FileNameDialogWin():
    def destroy(self):
        self.a = 0.95
        def exiting(event=None):
            after_exit = self.root.after(10, exiting)
            if self.a < 0:
                self.root.after_cancel(after_exit)
                self.root.destroy()
            self.a -= 0.05
            try:
                self.root.wm_attributes('-alpha', self.a)
            except Exception:
                pass
        exiting()

    def getpath(self):
        ext = os.path.splitext(self.entry.get())[1]
        path = self.folder
        if hdd_word.lower() in path.lower():
            path = self.folder.split(f':{os.sep}')[1]
        if path == '':
            path = '.'
        name = os.path.splitext(self.entry.get())[0]
        name_file = f"{' '.join(name.split())}{ext}"


        return str(Path(path,f"{name_file}"))

    def __init__(self, master=None, title='Всплывающее окно', command=empty, type='message', text='', commandclose=empty, textyes='OK', textno='Закрыть', ext_list='none', global_update=1, folder='.', name=''):
        if type == 'message':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','dialogwin.wav'))
        elif type == 'warning':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','warning.wav'))
        elif type == 'error':
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','error.wav'))
        self.master = master
        self.title = title
        self.command = command
        self.commandclose = commandclose
        self.name = name

        bg_tb = ''
        fg_tb = ''
        fontMaxOS = ''
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg1:
            bg_tb = bg1.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg1:
            fg_tb = fg1.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f1:
            fontMaxOS = f1.read()


        def theme_update():
            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0

            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            self.theme_after = self.root.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            self.root0.configure(fg_color=bg_color)
            self.root1['bg'] = bg_color
            self.title2['bg'] = bg_color
            self.title2['fg'] = fg_color
            self.title2['font'] = (font_, font_size)
            self.frameimgdesktop['bg'] = bg_color

            self.framebtns['bg'] = bg_color


            color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                color_rgb_activebackground[0] = 0
            else:
                color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

            if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                color_rgb_activebackground[1] = 0
            else:
                color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

            if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                color_rgb_activebackground[2] = 0
            else:
                color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

            activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

            self.frameright.configure(fg_color=bg_color)

            self.frame_main['bg'] = bg_color

            self.frame_path['bg'] = bg_color

            self.listbox['bg'] = bg_color
            self.listbox['fg'] = fg_color
            self.listbox['selectbackground'] = selectbg
            self.listbox['selectforeground'] = fg_color
            self.listbox['font'] = ('Cousine', font_size+3)
            self.listbox['highlightbackground'] = bg_color

            self.lab_path['bg'] = bg_color
            self.lab_path['fg'] = fg_color
            self.lab_path['font'] = (font_, font_size)

            self.lab_ext['bg'] = bg_color
            self.lab_ext['fg'] = fg_color
            self.lab_ext['font'] = (font_, font_size)

            self.lab_entry['bg'] = bg_color
            self.lab_entry['fg'] = fg_color
            self.lab_entry['font'] = (font_, font_size)

            self.frame_entry['bg'] = bg_color

        def GlobalUpdate():
            self.global_after = self.root.after(100, GlobalUpdate)
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','exit_user.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.root.destroy()
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','sleep_mode.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.root.withdraw()
                elif text == 'false':
                    self.root.deiconify()

        self.root = Toplevel(self.master)
        self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.a = 0
        self.ext_list = ext_list
        self.folder = folder
        def showing(event=None):
            after_show = self.root.after(10, showing)
            x = (self.root.winfo_screenwidth() - self.root.winfo_reqwidth()) / 2
            y = (self.root.winfo_screenheight() - self.root.winfo_reqheight()) / 2
            self.root.geometry("+%d+%d" % (x, y))
            if self.a > 0.9:
                self.root.after_cancel(after_show)
            self.a += 0.05
            self.root.wm_attributes('-alpha', self.a)
        showing()
        def passDEF(event=None):pass
        self.root.protocol('WM_DELETE_WINDOW', passDEF)
        self.root.wm_attributes('-alpha', 0.95)
        self.root.resizable(0,0)

        def startMove(event):
            global x, y
            x = event.x
            y = event.y
            #if sys.platform == 'darwin':self.root.overrideredirect(1)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        def stopMove(event):
            global x, y
            x = None
            y = None
            #if sys.platform == 'darwin':self.root.overrideredirect(0)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        def moving(event):
            global x, y
            x_ = (event.x_root - x)
            y_ = (event.y_root - y)
            self.root.geometry("+%s+%s" % (x_, y_))
            #if sys.platform == 'darwin':self.root.overrideredirect(1)
            #if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"

        if system == 'darwin':
            self.root.wm_attributes("-transparent", True)
            self.root.config(bg='systemTransparent')
        elif system == 'win32':
            self.root.wm_attributes("-transparentcolor", '#123456')
            self.root['bg'] = '#123456'
        self.root['bd'] = 7
        def top():
            self.root.after(10, top)
            self.root.wm_attributes('-topmost', 1)
            self.root.lift()
        top()

        self.root0 = CTkFrame(self.root, fg_color=bg_tb, corner_radius=15)
        self.root0.pack(expand=1, fill=BOTH)

        self.root1 = Frame(self.root0, bg=bg_tb)
        self.root1.pack(fill=BOTH, expand=1, padx=10, pady=10)

        self.root.wm_attributes('-topmost', 1)
        self.root.wm_overrideredirect(True)
        #if sys.platform == 'win32':
        #    self.root.wm_overrideredirect(True)
        #elif sys.platform == 'darwin':
        #    self.root.wm_overrideredirect(False)
        self.root.wm_attributes('-topmost', 1)
        self.title2 = Label(self.root1, bg=bg_tb, fg=fg_tb, text=self.title, font=(fontMaxOS, 15))
        self.title2.pack(anchor=NW, fill=X)
        self.title2.bind("<Button-1>", startMove)
        self.title2.bind("<ButtonRelease-1>", stopMove)
        self.title2.bind("<B1-Motion>", moving)
        self.frameimgdesktop = Frame(self.root1, bg=bg_tb, bd=7)
        self.frameimgdesktop.pack(anchor=NW, fill=BOTH, expand=1)

        self.frame_main = Frame(self.frameimgdesktop)
        self.frame_main.pack(fill=BOTH, side=TOP, expand=1, anchor=NW)

        self.frame_path = Frame(self.frame_main)
        self.frame_path.pack(fill=X)

        def select_folder(e=''):
            path = self.path_entry.get()
            if hdd_word.lower() in path.lower():
                path = self.path_entry.get().split(f':{os.sep}')[1]
            try:
                element = self.listbox.get(self.listbox.curselection()[0])
                name = os.path.splitext(element)[0]
                ext = os.path.splitext(element)[1].lower()

                if ext.lower() == '.<fold>':
                    ext = ''
                else:pass
                name_file = f"{' '.join(name.split())}{ext}"
                if os.path.isdir(Path(path, f"{name_file}{ext}")):
                    if element == '.':
                        self.folder = path
                        self.lab_path['text'] = f"Папка: {self.folder}"
                    else:
                        self.folder = Path(path, f"{name_file}{ext}")
                        self.lab_path['text'] = f"Папка: {self.folder}"
            except:
                print(traceback.format_exc())
                self.folder = path
                self.lab_path['text'] = f"Папка: {self.folder}"

        def update(e=''):
            def rjust(name, ext):
                len1 = len(name) - len(ext)
                return f"{name}{ext.rjust(25-len1)}"
            path = self.path_entry.get()
            if hdd_word.lower() in path.lower():
                path = self.path_entry.get().split(f':{os.sep}')[1]
            if path == '':
                path = '.'
            self.listbox.delete(0, END)
            select_folder()
            try:
                for i in sorted(os.listdir(path)):
                    if i[0] == '!' or i[0] == '.':pass
                    else:
                        if os.path.isdir(Path(path, i)):
                            if os.path.splitext(i)[1] == '':
                                name = os.path.splitext(i)[0]
                                ext = '.<FOLD>'
                                self.listbox.insert(END, rjust(name, ext))

            except:
                pass

        def back(e=''):
            path = self.path_entry.get()
            self.path_entry.delete(0, END)
            new_path = os.path.split(path)[0]
            if new_path.lower() == hdd_word.lower():
                self.path_entry.insert(END, f"{hdd_word}{os.sep}")
            else:
                self.path_entry.insert(END, os.path.split(path)[0])
            update()

        LabelButtonSystem(self.frame_path, text='<', command=back).pack(side=LEFT, padx=2, pady=2)

        self.path_entry = EntryAuto(self.frame_path, placeholder='placeholder')
        self.path_entry.pack(fill=X, side=LEFT, expand=1, padx=2, pady=2)
        self.path_entry.bind('<KeyRelease>', update)
        for i in psutil.disk_partitions():
            if i.mountpoint in f"{Path(folder)}":
                self.path_entry.insert(END, f"{Path(folder)}")
                break
        else:
            if folder == '.':
                self.path_entry.insert(END, f"{hdd_word}{os.sep}")
            else:
                self.path_entry.insert(END, f"{hdd_word}{os.sep}{Path(folder)}")


        self.frameright = CTkFrame(self.frame_main, width=200, corner_radius=0)
        self.frameright.pack(fill=BOTH, expand=1)

        def select(e=''):
            try:
                path = self.path_entry.get()
                if hdd_word.lower() in path.lower():
                    path = self.path_entry.get().split(f':{os.sep}')[1]
                if path == '':
                    path = '.'
                element = self.listbox.get(self.listbox.curselection()[0])
                if element != '.':
                    name = os.path.splitext(element)[0]
                    ext = os.path.splitext(element)[1].lower()

                    if ext.lower() == '.<fold>':
                        ext = ''
                    else:pass
                    name_file = f"{' '.join(name.split())}{ext}"
                    if os.path.isdir(Path(path, f"{name_file}{ext}")):
                        self.path_entry.delete(0, END)
                        self.path_entry.insert(END, Path(path, f"{name_file}{ext}"))
                        update()
            except:
                pass

        def files_menu(e=''):
            path = self.path_entry.get()
            element = self.listbox.get(self.listbox.curselection()[0])
            name = element.split()[0]
            ext = element.split()[1].lower()

            if ext.lower() == '<fold>':
                ext = ''
            else:pass
            if os.path.isdir(Path(path, f"{name}{ext}")):pass

        self.listbox = Listbox(self.frameright, highlightthickness=0, exportselection=0, relief='flat', cursor='@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur', width=50, height=10)
        self.listbox.pack(fill=BOTH, expand=1)
        self.listbox.bind('<Double-Button-1>', select)
        self.listbox.bind('<Return>', select)
        self.listbox.bind('<Control-Button-1>', files_menu)
        self.listbox.bind('<Button-2>', files_menu)
        self.listbox.bind('<Button-3>', files_menu)
        self.listbox.bind('<<ListboxSelect>>', select_folder)

        self.lab_path = Label(self.frameright, text=f"Папка: {self.folder}")
        self.lab_path.pack(anchor=NW)

        self.lab_ext = Label(self.frameright)
        if self.ext_list != 'none':
            self.lab_ext['text'] = f"Допустимые расширения: *{'; *'.join(self.ext_list).lower()}"
            self.lab_ext.pack(anchor=NW)
        self.frame_entry = Frame(self.frameright)
        self.frame_entry.pack(anchor=NW, fill=X)

        self.lab_entry = Label(self.frame_entry, text='Имя файла:')
        self.lab_entry.pack(side=LEFT)

        self.entry = EntryAuto(self.frame_entry, placeholder='placeholder')
        self.entry.pack(side=LEFT, fill=X)

        def OK(e=''):
            if self.ext_list == 'none':
                self.command()
            else:
                ext = os.path.splitext(self.entry.get())[1]
                if ext in self.ext_list:
                    self.command()
                else:
                    DialogWin(self.root, title='Ошибка', text=f"Расширение {ext}, не допускается", type='error')

        self.entry.bind('<Return>', OK)

        self.entry.insert(END, self.name)
        self.entry.focus()

        select_folder()

        update()

        def GlobalUpdate2():
            self.global_after = self.root.after(500, GlobalUpdate)
            def check_dir():
                dir1 = len(os.listdir())
                time.sleep(0.1)
                dir2 = len(os.listdir())

                if dir1 != dir2:
                    update()
            Thread(target=check_dir, daemon=1).start()

            def check_path():
                path1 = self.path_entry.get()
                time.sleep(0.1)
                path2 = self.path_entry.get()

                if path1 != path2:
                    update()
            #Thread(target=check_path, daemon=1).start()


        #Files(self.frameright, path=self.path_entry).pack(fill=BOTH, expand=1)


        #self.root1.bind('<Map>', self.root1.center)

        GlobalUpdate2()



        self.framebtns = Frame(self.frameimgdesktop)
        self.framebtns.pack(side=BOTTOM, fill=X, expand=1, anchor=NW)

        self.okbtn = LabelButtonSystem(self.framebtns, font=(fontMaxOS, 15), text=(' '+textyes+' '), width=15, bg=bg_tb, command=OK)
        self.okbtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        def close():
            self.commandclose()
            self.destroy()

        self.closebtn = LabelButtonSystem(self.framebtns, font=(fontMaxOS, 15), text=(' '+textno+' '), width=15, bg=bg_tb, command=close)
        self.closebtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        theme_update()
        if global_update:GlobalUpdate()

class maxOSShrt(tk.Button, tk.LabelFrame):
    def drag(self, event):
        #print(event.x_root, event.y_root)
        self.mouse_x = self.master.winfo_pointerx() - self.master.winfo_rootx()
        self.mouse_y = self.master.winfo_pointery() - self.master.winfo_rooty()
        X = self.AppFrame.winfo_x()
        Y = self.AppFrame.winfo_y()
        open(Path(self.shrt, 'coords.txt'), 'w', encoding='utf-8').write(f"{X} {Y}")
        #print(mouse_x, mouse_y)
        self.AppFrame.place(x=self.mouse_x, y=self.mouse_y, anchor=CENTER)
        self.AppFrameFantom.place_forget()
    def place_forget(self):
        self.AppFrame.place_forget()
        self.AppFrame.pack_forget()
    def place(self, x=None, anchor=None, y=None, relwidth=None, relx=None, rely=None, relheight=None, width=None, height=None):
        self.x = x
        self.y = y
        self.anchor = anchor
        self.relheight = relheight
        self.relwidth = relwidth
        self.width = width
        self.height = height
        self.rely = rely
        self.relx = relx
        self.AppFrame.place(x=self.x,
            anchor=self.anchor,
            relheight=self.relheight,
            width=self.width,
            rely=self.rely,
            relx=self.relx,
            y=self.y,
            relwidth=self.relwidth,
            height=self.height
        )
    def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
        self.side = side
        self.anchor = anchor
        self.expand = expand
        self.fill = fill
        self.padx, self.pady, self.ipadx, self.ipady = padx, pady, ipadx, ipady
        self.AppFrame.pack(side=self.side,
            anchor=self.anchor,
            expand=self.expand,
            fill=self.fill,
            padx=self.padx,
            pady=self.pady,
            ipadx=self.ipadx,
            ipady=self.ipady
        )


    def __init__(self, master=None, text=None, command=None, image=None, bg='#ececec', fg='black', path=None, shortcut=None, names=None, deletecommand=empty, type='program', commandopenwhen=''):
        tk.Button.__init__(self, master)
        tk.LabelFrame.__init__(self, master)
        self.master = master
        self.names = names
        self.command = command
        self.image = image
        self.bg, self.fg = bg, fg
        self.path = path
        self.shortcut = shortcut
        self.after_id_poisk = ''
        self.deletecommand = deletecommand
        self.commandopenwhen = commandopenwhen

        self.hoverstate = 0
        self.activebackground = '#9e9e9e'
        self.selectbg = '#9e9e9e'


        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)

            homefolder = ''
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','registry_path.txt'), 'r', encoding='utf-8') as hf:
                homefolder = hf.read()

            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            self.theme_after = self.AppFrame.after(10000, theme_update)#Thread(target=theme_update, daemon=1).start())
            #self.LblBtn['bg'] = bg_color
            self.bg = bg_color
            self.fg = fg_color

            self.Name['font'] = (font_, font_size)
            self.Name['fg'] = fg_color

            self.NameFantom['font'] = (font_, font_size)
            self.NameFantom['fg'] = fg_color


            color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                color_rgb_activebackground[0] = 0
            else:
                color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

            if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                color_rgb_activebackground[1] = 0
            else:
                color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

            if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                color_rgb_activebackground[2] = 0
            else:
                color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

            self.activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            self.selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

            self.bg_ = bg_color
            self.fg_ = fg_color
            self.font_ = font_
            self.font_size = font_size
            self.selectbg_ = self.selectbg

            if self.hoverstate != 1:
                self.AppFrame['bg'] = bg_color
                self.Name['bg'] = bg_color
                self.AppButton['bg'] = bg_color

                self.AppFrameFantom['bg'] = self.selectbg
                self.NameFantom['bg'] = self.selectbg
                self.AppButtonFantom['bg'] = self.selectbg
            else:
                pass

        self.shrt = self.shortcut
        self.text = text
        def startcommand(e=''):
            self.command()
        def delete():
            shutil.rmtree(self.shrt)
            self.master.after_cancel(self.after_id_poisk)
            self.AppFrame.after_cancel(self.theme_after)
            self.AppFrame.destroy()
            self.deletecommand()
        self.AppFrame = tk.Frame(self.master, relief=RAISED, bd=0, bg=self.bg, highlightthickness=0)
        def poiskfile(event=None):
            try:
                self.after_id_poisk = self.master.after(10, poiskfile)
                if os.path.exists(self.shrt):
                    pass
                else:
                    delete()

            except Exception:
                delete()
        poiskfile()
        def popup(event):
            global x, y
            def startcommand(e=''):
                self.command()



            menu = Menu(background=self.bg_, foreground=self.fg_, relief='flat', cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur", tearoff=0, bd=0, font=(self.font_, self.font_size), activebackground=self.selectbg_, activeforeground=self.fg_)
            if type == 'program' or type == 'folder':
                menu.add_command(label='Открыть', command=startcommand)
                default_fileman = ''
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_GLOBAL','GLOBAL_COMMANDS','DEFAULT_FILE_MANAGER','command.txt'), 'r', encoding='utf-8') as f:
                    default_fileman = f.read()
                menu.add_command(label=f"Показать в {read_file(Path(default_fileman,'name.txt'))}", command=lambda: run_program(D=os.path.split(default_fileman)[0], F=os.path.split(default_fileman)[1], fileopen=self.path))
            elif type == 'hdd':
                menu.add_command(label='Открыть', command=startcommand)
                if sys.platform == 'darwin':
                    def eject():
                        os.system(f"diskutil eject {Path(self.path)}")
                        PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','HDD Out.wav'))
                        delete()
                    menu.add_command(label='Извлечь', command=eject)
            elif type == 'cdrom':
                menu.add_command(label='Открыть', command=startcommand)
                if sys.platform == 'darwin':
                    def eject():
                        os.system(f"diskutil eject {Path(self.path)}")
                        PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','HDD Out.wav'))
                        delete()
                    menu.add_command(label='Извлечь', command=eject)
                elif sys.platform == 'win32':
                    def eject():
                        import ctypes
                        ctypes.windll.WINMM.mciSendStringW(u"set cdaudio door open", None, 0, None)
                    menu.add_command(label='Открыть лоток дисковода', command=eject)
            else:
                class MenuAdd():
                    def __init__(self, menu, i='', ext_folder='', path=''):
                        self.menu = menu
                        self.ext_folder = ext_folder
                        self.i = i
                        self.path = path

                        self.name = ''
                        with open(Path(self.ext_folder,'CONTEXT_MENU',self.i,'name.txt'), 'r', encoding='utf-8') as f:
                            self.name = f.read()

                        self.command = ''
                        with open(Path(self.ext_folder,'CONTEXT_MENU',self.i,'command.txt'), 'r', encoding='utf-8') as f:
                            with open(Path(f.read()), 'r', encoding='utf-8') as c:
                                self.command = c.read()

                        self.icon = ''
                        with open(Path(self.ext_folder,'CONTEXT_MENU',self.i,'icon_file.txt'), 'r', encoding='utf-8') as f:
                            self.icon = f.read().lower()

                        if self.icon == 'none':
                            self.icon = Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png')

                        #DialogWin(self.main, text=path)

                        def run():
                            try:
                                run_program(D=os.path.split(self.command)[0], F=os.path.split(self.command)[1], fileopen=self.path)
                            except:
                                pass

                        self.image = Image.open(self.icon)
                        self.image = self.image.resize((15, 15), Image.ANTIALIAS)
                        self.image = ImageTk.PhotoImage(self.image)

                        self.menu.add_command(label=self.name, command=run, image=self.image, compound=LEFT)


                for i in sorted(os.listdir(Path('MaxOS','!Registry','SYSTEM','SYSTEM_EXT_LIST',type,'CONTEXT_MENU'))):
                    MenuAdd(menu, i, ext_folder=Path('MaxOS','!Registry','SYSTEM','SYSTEM_EXT_LIST',type), path=self.path)

                default_fileman = ''
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_GLOBAL','GLOBAL_COMMANDS','DEFAULT_FILE_MANAGER','command.txt'), 'r', encoding='utf-8') as f:
                    default_fileman = f.read()
                menu.add_command(label=f"Показать в {read_file(Path(default_fileman,'name.txt'))}", command=lambda: run_program(D=os.path.split(default_fileman)[0], F=os.path.split(default_fileman)[1], fileopen=self.path))

            menu.add_separator()
            menu.add_command(label='Убрать с рабочего стола', command=delete)

            x = event.x
            y = event.y
            menu.post(event.x_root, event.y_root)



        self.Name = tk.Label(self.AppFrame, bg=self.bg, fg=self.fg, font=(fontMaxOS, 15), text=self.text)
        self.AppButton = Label(self.AppFrame, image=self.image, bg=self.bg, fg=self.fg)
        def motion(event):
            self.mouse_x = self.master.winfo_pointerx() - self.master.winfo_rootx()
            self.mouse_y = self.master.winfo_pointery() - self.master.winfo_rooty()
            X = self.AppFrameFantom.winfo_x()
            Y = self.AppFrameFantom.winfo_y()
            with open(Path(self.shrt, 'coords.txt'), 'w', encoding='utf-8') as f:
                f.write(f"{X} {Y}")
            self.AppFrameFantom.place(x=self.mouse_x, y=self.mouse_y, anchor=CENTER)
            self.NameFantom['text'] = self.text

            def XY(event, event2=event):
                self.drag(event=event2)
                X = self.AppFrameFantom.winfo_x()
                Y = self.AppFrameFantom.winfo_y()
                self.AppFrame['bg'] = self.bg
                self.Name['bg'] = self.bg
                self.Name['fg'] = self.fg
                self.AppButton['bg'] = self.bg

                self.AppFrame['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
                self.Name['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
                self.AppButton['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
                with open(Path(self.shrt, 'coords.txt'), 'w', encoding='utf-8') as f:
                    f.write(f"{X} {Y}")
            self.AppButton.bind('<ButtonRelease-1>', XY)
            self.Name.bind('<ButtonRelease-1>', XY)
            self.AppFrame.bind('<ButtonRelease-1>', XY)

        self.AppButton.bind('<B1-Motion>', motion)
        self.Name.pack(side=TOP, fill=X, expand=1)
        self.AppButton.pack(side=BOTTOM, fill=X, expand=1)
        self.AppFrame.bind('<B1-Motion>',motion)
        self.Name.bind('<B1-Motion>',motion)

        self.AppFrame.bind('<Control-Button-1>',popup)
        self.Name.bind('<Control-Button-1>',popup)
        self.AppFrame.bind('<Button-2>',popup)
        self.Name.bind('<Button-2>',popup)
        self.AppFrame.bind('<Button-3>',popup)
        self.Name.bind('<Button-3>',popup)

        self.AppButton.bind('<Control-Button-1>',popup)
        self.AppButton.bind('<Button-2>',popup)
        self.AppButton.bind('<Button-3>',popup)

        self.AppFrameFantom = tk.Frame(self.master, relief=RAISED, bd=0, bg=self.selectbg, highlightthickness=0)
        self.NameFantom = tk.Label(self.AppFrameFantom, bg=self.selectbg, fg=self.fg, font=(fontMaxOS, 15), text=self.text)
        self.AppButtonFantom = Label(self.AppFrameFantom, image=self.image, bg=self.selectbg, fg=self.fg)

        self.NameFantom.pack(side=TOP, fill=X, expand=1)
        self.AppButtonFantom.pack(side=BOTTOM, fill=X, expand=1)

        def press(event):
            self.AppFrame['bg'] = self.selectbg
            self.Name['bg'] = self.selectbg
            self.AppButton['bg'] = self.selectbg

            self.AppFrame['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Move.cur"
            self.Name['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Move.cur"
            self.AppButton['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Move.cur"
        def release(event):
            self.AppFrame['bg'] = self.bg
            self.Name['bg'] = self.bg
            self.Name['fg'] = self.fg
            self.AppButton['bg'] = self.bg

            self.AppFrame['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
            self.Name['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
            self.AppButton['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"

        self.AppFrame.bind('<ButtonPress-1>', press)
        self.AppFrame.bind('<ButtonRelease-1>', release)
        self.Name.bind('<ButtonPress-1>', press)
        self.Name.bind('<ButtonRelease-1>', release)
        self.AppButton.bind('<ButtonPress-1>', press)
        self.AppButton.bind('<ButtonRelease-1>', release)

        def hover(event):
            self.hoverstate = 1
            self.AppFrame['bg'] = self.selectbg
            self.Name['bg'] = self.selectbg
            self.AppButton['bg'] = self.selectbg
        def unhover(event):
            self.hoverstate = 0
            self.AppFrame['bg'] = self.bg
            self.Name['bg'] = self.bg
            self.Name['fg'] = self.fg
            self.AppButton['bg'] = self.bg

        self.AppFrame.bind('<Enter>', hover)
        self.AppFrame.bind('<Leave>', unhover)
        self.Name.bind('<Enter>', hover)
        self.Name.bind('<Leave>', unhover)
        self.AppButton.bind('<Enter>', hover)
        self.AppButton.bind('<Leave>', unhover)

        self.AppFrame.bind('<Double-Button-1>', startcommand)
        self.Name.bind('<Double-Button-1>', startcommand)
        self.AppButton.bind('<Double-Button-1>', startcommand)
        theme_update()
class maxOSFold(tk.Button, tk.LabelFrame):
    def drag(self, event):
        #print(event.x_root, event.y_root)
        self.mouse_x = self.master.winfo_pointerx() - self.master.winfo_rootx()
        self.mouse_y = self.master.winfo_pointery() - self.master.winfo_rooty()
        X = self.AppFrame.winfo_x()
        Y = self.AppFrame.winfo_y()
        open(Path(self.shrt, 'coords.txt'), 'w', encoding='utf-8').write(f"{X} {Y}")
        #print(mouse_x, mouse_y)
        self.AppFrame.place(x=self.mouse_x, y=self.mouse_y, anchor=CENTER)
        self.AppFrameFantom.place_forget()
    def place_forget(self):
        self.AppFrame.place_forget()
        self.AppFrame.pack_forget()
    def place(self, x=None, anchor=None, y=None, relwidth=None, relx=None, rely=None, relheight=None, width=None, height=None):
        self.x = x
        self.y = y
        self.anchor = anchor
        self.relheight = relheight
        self.relwidth = relwidth
        self.width = width
        self.height = height
        self.rely = rely
        self.relx = relx
        self.AppFrame.place(x=self.x,
            anchor=self.anchor,
            relheight=self.relheight,
            width=self.width,
            rely=self.rely,
            relx=self.relx,
            y=self.y,
            relwidth=self.relwidth,
            height=self.height
        )
    def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
        self.side = side
        self.anchor = anchor
        self.expand = expand
        self.fill = fill
        self.padx, self.pady, self.ipadx, self.ipady = padx, pady, ipadx, ipady
        self.AppFrame.pack(side=self.side,
            anchor=self.anchor,
            expand=self.expand,
            fill=self.fill,
            padx=self.padx,
            pady=self.pady,
            ipadx=self.ipadx,
            ipady=self.ipady
        )


    def __init__(self, master=None, text=None, command=None, image=None, bg='#ececec', fg='black', path=None, shortcut=None, names=None, deletecommand=empty, commandopenwhen=None):
        tk.Button.__init__(self, master)
        tk.LabelFrame.__init__(self, master)
        self.master = master
        self.names = names
        self.command = command
        self.image = image
        self.bg, self.fg = bg, fg
        self.path = path
        self.shortcut = shortcut
        self.after_id_poisk = ''
        self.deletecommand = deletecommand
        self.commandopenwhen = commandopenwhen

        self.hoverstate = 0
        self.activebackground = '#9e9e9e'
        self.selectbg = '#9e9e9e'

        self.img = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','Folder.png'))
        self.img = self.img.resize((105, 105), Image.ANTIALIAS)
        self.img = ImageTk.PhotoImage(self.img)


        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)

            homefolder = ''
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','registry_path.txt'), 'r', encoding='utf-8') as hf:
                homefolder = hf.read()

            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            self.theme_after = self.AppFrame.after(10000, theme_update)#Thread(target=theme_update, daemon=1).start())
            #self.LblBtn['bg'] = bg_color
            self.bg = bg_color
            self.fg = fg_color

            self.Name['font'] = (font_, font_size)
            self.Name['fg'] = fg_color

            self.NameFantom['font'] = (font_, font_size)
            self.NameFantom['fg'] = fg_color


            color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                color_rgb_activebackground[0] = 0
            else:
                color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

            if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                color_rgb_activebackground[1] = 0
            else:
                color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

            if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                color_rgb_activebackground[2] = 0
            else:
                color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

            self.activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            self.selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

            self.bg_ = bg_color
            self.fg_ = fg_color
            self.font_ = font_
            self.font_size = font_size
            self.selectbg_ = self.selectbg

            if self.hoverstate != 1:
                self.AppFrame['bg'] = bg_color
                self.Name['bg'] = bg_color
                self.AppButton['bg'] = bg_color

                self.AppFrameFantom['bg'] = self.selectbg
                self.NameFantom['bg'] = self.selectbg
                self.AppButtonFantom['bg'] = self.selectbg
            else:
                pass

        def GlobalUpdate():
            self.global_after = self.AppButton.after(100, GlobalUpdate)
            dirlist1 = os.listdir(self.path)
            if len(dirlist1) == 0:
                self.img = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','Folder.png'))
            else:
                self.img = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','Folder2.png'))
            self.img = self.img.resize((105, 105), Image.ANTIALIAS)
            self.img = ImageTk.PhotoImage(self.img)
            self.AppButton['image'] = self.img
            self.AppButtonFantom['image'] = self.img

        self.shrt = self.shortcut
        self.text = text
        def startcommand(e=''):
            self.command()
        def delete():
            shutil.rmtree(self.shrt)
            self.master.after_cancel(self.after_id_poisk)
            self.AppFrame.after_cancel(self.theme_after)
            self.AppFrame.destroy()
            self.deletecommand()
        self.AppFrame = tk.Frame(self.master, relief=RAISED, bd=0, bg=self.bg, highlightthickness=0)
        def poiskfile(event=None):
            try:
                self.after_id_poisk = self.master.after(10, poiskfile)
                if os.path.exists(self.shrt):
                    pass
                else:
                    delete()

            except Exception:
                delete()
        poiskfile()
        def popup(event):
            global x, y

            def startcommand(e=''):
                self.command()
            def opencommand():
                self.commandopenwhen()

            menu = Menu(background=self.bg_, foreground=self.fg_, relief='flat', cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur", tearoff=0, bd=0, font=(self.font_, self.font_size), activebackground=self.selectbg_, activeforeground=self.fg_)
            menu.add_command(label='Открыть', command=startcommand)
            menu.add_separator()
            menu.add_command(label='Убрать с рабочего стола', command=delete)

            x = event.x
            y = event.y
            menu.post(event.x_root, event.y_root)



        self.Name = tk.Label(self.AppFrame, bg=self.bg, fg=self.fg, font=(fontMaxOS, 15), text=self.text)
        self.AppButton = Label(self.AppFrame, image=self.img, bg=self.bg, fg=self.fg)
        def motion(event):

            self.mouse_x = self.master.winfo_pointerx() - self.master.winfo_rootx()
            self.mouse_y = self.master.winfo_pointery() - self.master.winfo_rooty()
            X = self.AppFrameFantom.winfo_x()
            Y = self.AppFrameFantom.winfo_y()
            with open(Path(self.shrt, 'coords.txt'), 'w', encoding='utf-8') as f:
                f.write(f"{X} {Y}")
            self.AppFrameFantom.place(x=self.mouse_x, y=self.mouse_y, anchor=CENTER)
            self.NameFantom['text'] = self.text

            def XY(event, event2=event):
                self.drag(event=event2)
                X = self.AppFrameFantom.winfo_x()
                Y = self.AppFrameFantom.winfo_y()
                self.AppFrame['bg'] = self.bg
                self.Name['bg'] = self.bg
                self.Name['fg'] = self.fg
                self.AppButton['bg'] = self.bg

                self.AppFrame['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
                self.Name['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
                self.AppButton['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
                with open(Path(self.shrt, 'coords.txt'), 'w', encoding='utf-8') as f:
                    f.write(f"{X} {Y}")
            self.AppButton.bind('<ButtonRelease-1>', XY)
            self.Name.bind('<ButtonRelease-1>', XY)
            self.AppFrame.bind('<ButtonRelease-1>', XY)

        self.AppButton.bind('<B1-Motion>', motion)
        self.Name.pack(side=TOP, fill=X, expand=1)
        self.AppButton.pack(side=BOTTOM, fill=X, expand=1)
        self.AppFrame.bind('<B1-Motion>',motion)
        self.Name.bind('<B1-Motion>',motion)

        self.AppFrame.bind('<Control-Button-1>',popup)
        self.Name.bind('<Control-Button-1>',popup)
        self.AppFrame.bind('<Button-2>',popup)
        self.Name.bind('<Button-2>',popup)
        self.AppFrame.bind('<Button-3>',popup)
        self.Name.bind('<Button-3>',popup)

        self.AppButton.bind('<Control-Button-1>',popup)
        self.AppButton.bind('<Button-2>',popup)
        self.AppButton.bind('<Button-3>',popup)

        self.AppFrameFantom = tk.Frame(self.master, relief=RAISED, bd=0, bg=self.selectbg, highlightthickness=0)
        self.NameFantom = tk.Label(self.AppFrameFantom, bg=self.selectbg, fg=self.fg, font=(fontMaxOS, 15), text=self.text)
        self.AppButtonFantom = Label(self.AppFrameFantom, image=self.img, bg=self.selectbg, fg=self.fg)

        self.NameFantom.pack(side=TOP, fill=X, expand=1)
        self.AppButtonFantom.pack(side=BOTTOM, fill=X, expand=1)

        def press(event):
            self.AppFrame['bg'] = self.selectbg
            self.Name['bg'] = self.selectbg
            self.AppButton['bg'] = self.selectbg

            self.AppFrame['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Move.cur"
            self.Name['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Move.cur"
            self.AppButton['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Move.cur"
        def release(event):
            self.AppFrame['bg'] = self.bg
            self.Name['bg'] = self.bg
            self.Name['fg'] = self.fg
            self.AppButton['bg'] = self.bg

            self.AppFrame['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
            self.Name['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
            self.AppButton['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"

        self.AppFrame.bind('<ButtonPress-1>', press)
        self.AppFrame.bind('<ButtonRelease-1>', release)
        self.Name.bind('<ButtonPress-1>', press)
        self.Name.bind('<ButtonRelease-1>', release)
        self.AppButton.bind('<ButtonPress-1>', press)
        self.AppButton.bind('<ButtonRelease-1>', release)

        def hover(event):
            self.hoverstate = 1
            self.AppFrame['bg'] = self.selectbg
            self.Name['bg'] = self.selectbg
            self.AppButton['bg'] = self.selectbg
        def unhover(event):
            self.hoverstate = 0
            self.AppFrame['bg'] = self.bg
            self.Name['bg'] = self.bg
            self.Name['fg'] = self.fg
            self.AppButton['bg'] = self.bg

        self.AppFrame.bind('<Enter>', hover)
        self.AppFrame.bind('<Leave>', unhover)
        self.Name.bind('<Enter>', hover)
        self.Name.bind('<Leave>', unhover)
        self.AppButton.bind('<Enter>', hover)
        self.AppButton.bind('<Leave>', unhover)

        self.AppFrame.bind('<Double-Button-1>', startcommand)
        self.Name.bind('<Double-Button-1>', startcommand)
        self.AppButton.bind('<Double-Button-1>', startcommand)
        theme_update()
        GlobalUpdate()

class Entry2(CTkEntry):

    def __init__(self, master, bg=bg_tb, fg=fg_tb, bd=1, font=(fontMaxOS, 15), insertbackground=fg_tb, insertwidth=3):
        def __init__(self, master, placeholder, bg=bg_tb, fg=fg_tb, bd=1, font=(fontMaxOS, 15), insertbackground=fg_tb, insertwidth=3):
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            def theme_update():
                bg_color1 = ''
                fg_color1 = ''
                font_1 = ''
                font_size1 = 0

                bg_color2 = ''
                fg_color2 = ''
                font_2 = ''
                font_size2 = 0
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                    bg_color1 = bg.read()
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                    fg_color1 = fg.read()
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                    font_1 = f.read()
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                    font_size1 = int(fs.read())
                time.sleep(0.1)
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                    bg_color2 = bg.read()
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                    fg_color2 = fg.read()
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                    font_2 = f.read()
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                    font_size2 = int(fs.read())

                if bg_color1 != bg_color2 or fg_color1 != fg_color2 or font_1 != font_2 or font_size1 != font_size2:
                    self.configure(fg_color=bg_color2)
                    self.configure(text_color=fg_color2)
                    self.configure(font=(font_2, font_size2))

                self.theme_after = self.after(500, lambda: Thread(target=theme_update, daemon=1).start())
            super().__init__(master, fg_color=bg_color, text_color=fg_color, font=(font_, font_size), insertwidth=3)
            theme_update()
class EntryAuto(CTkEntry):
    def __init__(self, master, placeholder, bg=bg_tb, fg=fg_tb, bd=1, font=(fontMaxOS, 15), insertbackground=fg_tb, insertwidth=3):
        bg_color = ''
        fg_color = ''
        font_ = ''
        font_size = 0
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
            bg_color = bg.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
            fg_color = fg.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
            font_ = f.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
            font_size = int(fs.read())
        def theme_update():
            bg_color1 = ''
            fg_color1 = ''
            font_1 = ''
            font_size1 = 0

            bg_color2 = ''
            fg_color2 = ''
            font_2 = ''
            font_size2 = 0
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color1 = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color1 = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_1 = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size1 = int(fs.read())
            time.sleep(0.1)
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color2 = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color2 = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_2 = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size2 = int(fs.read())

            if bg_color1 != bg_color2 or fg_color1 != fg_color2 or font_1 != font_2 or font_size1 != font_size2:
                self.configure(fg_color=bg_color2)
                self.configure(text_color=fg_color2)
                self.configure(font=('Cousine', font_size2))

            self.theme_after = self.after(500, lambda: Thread(target=theme_update, daemon=1).start())
        super().__init__(master, fg_color=bg_color, text_color=fg_color, font=('Cousine', font_size), insertwidth=3)

        self.placeholder = placeholder
        self._is_password = True if placeholder == 'password' else False

        self.bind('<FocusIn>', self.on_focus_in)
        self.bind('<FocusOut>', self.on_focus_out)
        self.master = master
        def hover(e=''):
            self.master['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/IBeam.cur"
        def unhover(e=''):
            self.master['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.bind('<Enter>', hover)
        self.bind('<Leave>', unhover)

        self._state = 'placeholder'

        theme_update()

    def on_focus_in(self, event):
        if self._is_password:
          self.configure(show='•')#＊

        if self._state == 'placeholder':
            self._state = ''

    def on_focus_out(self, event):
        if not self.get():
          if self._is_password:
            self.configure(show='')
        self._state = 'placeholder'
def barrier(val,min = 0, max = None,minrep = None,maxrep = None):
    if minrep is None:minrep = min
    if maxrep is None: maxrep = max
    if not min is None and val < min:return minrep
    elif not max is None and val > max: return maxrep
    else:return val

class loading_cursor():
    def stop(self):
        self.master.after_cancel(self.after)
        self.master['cursor'] = ''
    def __init__(self, master=None):
        self.master = master
        def loading():
            self.after = self.master.after(100, loading)
            if self.master['cursor'] == '':
                self.master['cursor'] = 'cross'
            elif self.master['cursor'] == 'cross':
                self.master['cursor'] = 'diamond_cross'
            elif self.master['cursor'] == 'diamond_cross':
                self.master['cursor'] = 'cross'
        loading()
# Просто пустая функция
# Класс усовершенстованого окна
BGCL = 'white'
BARCL = 'white'
wiget = Toplevel

class Separator(CTkFrame):
    def __init__(self, master='', orient='vertical'):
        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            self.theme_after = self.sep.after(10000, lambda: Thread(target=theme_update, daemon=1).start())
            self.sep.configure(fg_color=fg_color)

        if orient == 'vertical':
            self.sep = CTkFrame(master, fg_color='black', width=3, height=1)
            self.sep.pack(fill=Y, padx=1, pady=3, side=LEFT)
        elif orient == 'horizontal':
            self.sep = CTkFrame(master, fg_color='black', width=1, height=3)
            self.sep.pack(fill=X, padx=3, pady=1)

        theme_update()


class MaxOSTk2(wiget):
    def __init__(self, master=None,resizeable = True,exitfunc = empty,onresizefunc = empty, mingeometry=(75, 75), icon=None, resizefunc=empty):
        import sys
        from PIL import Image, ImageTk
        global BGCL, CANCELCL, CANCELHOVCL, INFOCL, INFOHOVCL, BARCL
        self.deiconify_state = 0

        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            self.theme_after = self.after(10000, lambda: Thread(target=theme_update, daemon=1).start())
            self.mainframe.configure(fg_color=bg_color)
            self.mainframe2.configure(fg_color=bg_color)

            self.bar['bg'] = bg_color
            self.tit['bg'] = bg_color
            self.FrameButtons['bg'] = bg_color
            self.closebtn['bg'] = bg_color
            self.zoombtn1['bg'] = bg_color
            self.zoombtn2['bg'] = bg_color
            self.content['bg'] = bg_color
            if self.resizeable:
                self.resizebtn['bg'] = bg_color
            self.iconlabel['bg'] = bg_color

            self.tit['fg'] = fg_color
            self.tit['font'] = (font_, font_size)

            def color_img(img, color):
                img = Image.open(img)
                pixdata = img.load()
                r, g, b, = ImageColor.getcolor(color, "RGB")
                for y in range(img.size[1]):
                    for x in range(img.size[0]):
                        alpha = pixdata[x, y][3]
                        if alpha:
                            pixdata[x, y] = (r, g, b, alpha)
                return img

            self.closeimage = color_img(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','CLOSE_BTN','normal.png')), color=fg_color)
            if system == 'darwin':self.closeimage = self.closeimage.resize((15, 15), Image.ANTIALIAS)
            elif system == 'win32':self.closeimage = self.closeimage.resize((15, 15), Image.ANTIALIAS)
            self.closeimage = ImageTk.PhotoImage(self.closeimage)
            if self.ACTIVECLSSTATE != 1 and self.LEAVECLSSTATE != 1:
                self.closebtn.image = self.closeimage
                self.closebtn['image'] = self.closebtn.image

            self.upimage = color_img(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_UP_BTN','normal.png')), color=fg_color)
            if system == 'darwin':self.upimage = self.upimage.resize((15, 15), Image.ANTIALIAS)
            elif system == 'win32':self.upimage = self.upimage.resize((15, 15), Image.ANTIALIAS)
            self.upimage = ImageTk.PhotoImage(self.upimage)
            if self.ACTIVEUPSTATE != 1 and self.LEAVEUPSTATE != 1:
                self.zoombtn1.image = self.upimage
                self.zoombtn1['image'] = self.zoombtn1.image

            self.downimage = color_img(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_DOWN_BTN','normal.png')), color=fg_color)
            if system == 'darwin':self.downimage = self.downimage.resize((15, 15), Image.ANTIALIAS)
            elif system == 'win32':self.downimage = self.downimage.resize((15, 15), Image.ANTIALIAS)
            self.downimage = ImageTk.PhotoImage(self.downimage)
            if self.ACTIVEDOWNSTATE != 1 and self.LEAVEDOWNSTATE != 1:
                self.zoombtn2.image = self.downimage
                self.zoombtn2['image'] = self.zoombtn2.image

            self.bg_ = bg_color
            self.fg_ = fg_color
            self.font_ = font_
            self.font_size = font_size
            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)
            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

            self.selectbg_ = selectbg

        def GlobalUpdate():
            self.global_after = self.after(100, GlobalUpdate)
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','exit_user.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.destroy()
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','sleep_mode.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.withdraw()
                    if self.deiconify_state != 0:
                        self.deiconify_state = 0
                elif text == 'false':
                    if self.deiconify_state != 1:
                        self.deiconify_state = 1
                    if self.deiconify_state:
                        #self.deiconify()
                        self.deiconify_state = 0
        wiget.__init__(self, master)
        self['bd'] = 7
        self['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.wm_attributes('-alpha', 0)
        self.mingeometry = mingeometry
        self.resize = False
        self.topstate = 0
        self.resizefunc = resizefunc
        print(self.mingeometry)
        Xmin = self.mingeometry[0]
        Ymin = self.mingeometry[1]
        self.resizable(0, 0)

        self.geosizex = int(open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','WINDOW_MANAGER','WINDOW_GEOMETRY','x.txt'), 'r', encoding='utf-8').readline())
        self.geosizey = int(open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','WINDOW_MANAGER','WINDOW_GEOMETRY','y.txt'), 'r', encoding='utf-8').readline())

        if system == 'darwin':
            self.wm_attributes("-transparent", True)
            self.config(bg='systemTransparent')
        elif system == 'win32':
            self.wm_attributes("-transparentcolor", '#123456')
            self['bg'] = '#123456'

        '''

        self.resizebottom = CTkLabel(self, fg_color='transparent', text='', height=10, width=5555)
        def hover_bottom(event=''):self['cursor'] = 'bottom_side'
        def unhover_bottom(event=''):self['cursor'] = ''
        self.resizebottom.bind('<Enter>', hover_bottom)
        self.resizebottom.bind('<Leave>', unhover_bottom)

        self.resizeleft = CTkLabel(self, fg_color='red', text='', height=5555, width=10)
        def hover_left(event=''):self['cursor'] = 'left_side'
        def unhover_left(event=''):self['cursor'] = ''
        self.resizeleft.bind('<Enter>', hover_left)
        self.resizeleft.bind('<Leave>', unhover_left)

        self.resizeright = CTkLabel(self, fg_color='transparent', text='', height=5555, width=10)
        def hover_right(event=''):self['cursor'] = 'right_side'
        def unhover_right(event=''):self['cursor'] = ''
        self.resizeright.bind('<Enter>', hover_right)
        self.resizeright.bind('<Leave>', unhover_right)


        self.resizebottomleft = CTkLabel(self, fg_color='transparent', text='', height=5555, width=10)
        def hover_bottomleft(event=''):self['cursor'] = 'bottom_left_corner'
        def unhover_bottomleft(event=''):self['cursor'] = ''
        self.resizebottomleft.bind('<Enter>', hover_bottomleft)
        self.resizebottomleft.bind('<Leave>', unhover_bottomleft)

        self.resizebottomright = CTkLabel(self, fg_color='transparent', text='', height=5555, width=10)
        def hover_bottomright(event=''):self['cursor'] = 'bottom_right_corner'
        def unhover_bottomright(event=''):self['cursor'] = ''
        self.resizebottomright.bind('<Enter>', hover_bottomright)
        self.resizebottomright.bind('<Leave>', unhover_bottomright)
        '''


        self.mainframe = CTkFrame(self, fg_color=BARCL, corner_radius=15)
        self.mainframe.pack(fill=BOTH, expand=1)

        '''
        self.resizebottom.place(relx=0, rely=0.99)
        self.resizeleft.place(x=0, y=0)
        self.resizeright.place(y=0, relx=0.99)


        self.resizebottomleft.place(x=0, rely=0.99)
        self.resizebottomright.place(relx=0.99, rely=0.99)
        '''

        self.mainframe.bind("<Double-Button-1>", self.wrap)
        self.mainframe.bind("<ButtonPress-1>", self.StartMove)
        self.mainframe.bind("<ButtonRelease-1>", self.StopMove)
        self.mainframe.bind("<B1-Motion>", self.OnMotion)


        self.mainframe2 = CTkFrame(self.mainframe, fg_color=BGCL, corner_radius=0)
        self.mainframe2.pack(fill=BOTH, expand=1, padx=10, pady=10)

        self.X = None
        self.Y = None
        self.Showing = True
        self.zoomstate = False
        self.wrapstate = False
        self['relief'] = FLAT
        def passDEF(event=None):pass
        self.protocol('WM_DELETE_WINDOW', passDEF)
        self.resizeable = resizeable
        self.exitfunc = exitfunc
        self.onresizefunc = onresizefunc
        #self.wm_attributes('-topmost', 1)
        #self.wm_attributes('-topmost',True) # приоритетный режим
        self.bar = Frame(self.mainframe2, bg = BARCL, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur") # Создаём свою панельку, как отдельный виджет


        self.closeimage = Image.open(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','CLOSE_BTN','normal.png')))
        if system == 'darwin':self.closeimage = self.closeimage.resize((15, 15), Image.ANTIALIAS)
        elif system == 'win32':self.closeimage = self.closeimage.resize((15, 15), Image.ANTIALIAS)
        self.closeimage = ImageTk.PhotoImage(self.closeimage)

        self.closeimagehover = Image.open(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','CLOSE_BTN','hover.png')))
        if system == 'darwin':self.closeimagehover = self.closeimagehover.resize((15, 15), Image.ANTIALIAS)
        elif system == 'win32':self.closeimagehover = self.closeimagehover.resize((15, 15), Image.ANTIALIAS)
        self.closeimagehover = ImageTk.PhotoImage(self.closeimagehover)

        self.closeimageactive = Image.open(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','CLOSE_BTN','active.png')))
        if system == 'darwin':self.closeimageactive = self.closeimageactive.resize((15, 15), Image.ANTIALIAS)
        elif system == 'win32':self.closeimageactive = self.closeimageactive.resize((15, 15), Image.ANTIALIAS)
        self.closeimageactive = ImageTk.PhotoImage(self.closeimageactive)



        self.upimage = Image.open(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_UP_BTN','normal.png')))
        if system == 'darwin':self.upimage = self.upimage.resize((15, 15), Image.ANTIALIAS)
        elif system == 'win32':self.upimage = self.upimage.resize((15, 15), Image.ANTIALIAS)
        self.upimage = ImageTk.PhotoImage(self.upimage)

        self.upimagehover = Image.open(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_UP_BTN','hover.png')))
        if system == 'darwin':self.upimagehover = self.upimagehover.resize((15, 15), Image.ANTIALIAS)
        elif system == 'win32':self.upimagehover = self.upimagehover.resize((15, 15), Image.ANTIALIAS)
        self.upimagehover = ImageTk.PhotoImage(self.upimagehover)

        self.upimageactive = Image.open(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_UP_BTN','active.png')))
        if system == 'darwin':self.upimageactive = self.upimageactive.resize((15, 15), Image.ANTIALIAS)
        elif system == 'win32':self.upimageactive = self.upimageactive.resize((15, 15), Image.ANTIALIAS)
        self.upimageactive = ImageTk.PhotoImage(self.upimageactive)



        self.downimage = Image.open(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_DOWN_BTN','normal.png')))
        if system == 'darwin':self.downimage = self.downimage.resize((15, 15), Image.ANTIALIAS)
        elif system == 'win32':self.downimage = self.downimage.resize((15, 15), Image.ANTIALIAS)
        self.downimage = ImageTk.PhotoImage(self.downimage)

        self.downimagehover = Image.open(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_DOWN_BTN','hover.png')))
        if system == 'darwin':self.downimagehover = self.downimagehover.resize((15, 15), Image.ANTIALIAS)
        elif system == 'win32':self.downimagehover = self.downimagehover.resize((15, 15), Image.ANTIALIAS)
        self.downimagehover = ImageTk.PhotoImage(self.downimagehover)

        self.downimageactive = Image.open(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_DOWN_BTN','active.png')))
        if system == 'darwin':self.downimageactive = self.downimageactive.resize((15, 15), Image.ANTIALIAS)
        elif system == 'win32':self.downimageactive = self.downimageactive.resize((15, 15), Image.ANTIALIAS)
        self.downimageactive = ImageTk.PhotoImage(self.downimageactive)


        self.bar.pack(anchor=NW, fill=X)
        self.FrameButtons = Frame(self.bar, bg = BARCL, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur")
        self.FrameButtons.pack(side=LEFT)
        self.closebtn = Label(self.FrameButtons, bg=BARCL, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
        self.closebtn.image = self.closeimage
        self.closebtn['image'] = self.closebtn.image
        self.LEAVECLSSTATE = 0
        self.ACTIVECLSSTATE = 0
        def hoverclose(event=''):
            if self.ACTIVECLSSTATE:
                self.closebtn.image = self.closeimageactive
                self.closebtn['image'] = self.closebtn.image
            else:
                self.closebtn.image = self.closeimagehover
                self.closebtn['image'] = self.closebtn.image
            self.LEAVECLSSTATE = 1
        def unhoverclose(event=''):
            self.closebtn.image = self.closeimage
            self.closebtn['image'] = self.closebtn.image
            self.LEAVECLSSTATE = 0
        self.closebtn.bind('<Enter>', hoverclose)
        self.closebtn.bind('<Leave>', unhoverclose)
        def cmdcls(event=''):
            if self.LEAVECLSSTATE:
                self.Exit()
            self.ACTIVECLSSTATE = 0
        def activecls(event=''):
            self.closebtn.image = self.closeimageactive
            self.closebtn['image'] = self.closebtn.image
            self.ACTIVECLSSTATE = 1
        self.closebtn.bind('<ButtonPress-1>', activecls)
        self.closebtn.bind('<ButtonRelease-1>', cmdcls)

        self.closebtn.pack(side=LEFT, padx=1, pady=0, expand=0)
        self.X1 = None
        self.Y1 = None


        self.zoombtn1 = Label(self.FrameButtons, bg=BARCL, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
        self.zoombtn1.image = self.upimage
        self.zoombtn1['image'] = self.zoombtn1.image
        self.LEAVEUPSTATE = 0
        self.ACTIVEUPSTATE = 0
        def hoverup(event=''):
            if self.ACTIVEUPSTATE:
                self.zoombtn1.image = self.upimageactive
                self.zoombtn1['image'] = self.zoombtn1.image
            else:
                self.zoombtn1.image = self.upimagehover
                self.zoombtn1['image'] = self.zoombtn1.image
            self.LEAVEUPSTATE = 1
        def unhoverup(event=''):
            self.zoombtn1.image = self.upimage
            self.zoombtn1['image'] = self.zoombtn1.image
            self.LEAVEUPSTATE = 0
        self.zoombtn1.bind('<Enter>', hoverup)
        self.zoombtn1.bind('<Leave>', unhoverup)
        def cmdup(event=''):
            if self.LEAVEUPSTATE:
                self.zoom()
            self.ACTIVECLSSTATE = 0
        def activeup(event=''):
            self.zoombtn1.image = self.upimageactive
            self.zoombtn1['image'] = self.zoombtn1.image
            self.ACTIVEUPSTATE = 1
        self.zoombtn1.bind('<ButtonPress-1>', activeup)
        self.zoombtn1.bind('<ButtonRelease-1>', cmdup)


        self.zoombtn2 = Label(self.FrameButtons, bg=BARCL, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
        self.zoombtn2.image = self.downimage
        self.zoombtn2['image'] = self.zoombtn2.image
        self.LEAVEDOWNSTATE = 0
        self.ACTIVEDOWNSTATE = 0
        def hoverdown(event=''):
            if self.ACTIVEDOWNSTATE:
                self.zoombtn2.image = self.downimageactive
                self.zoombtn2['image'] = self.zoombtn2.image
            else:
                self.zoombtn2.image = self.downimagehover
                self.zoombtn2['image'] = self.zoombtn2.image
            self.LEAVEDOWNSTATE = 1
        def unhoverdown(event=''):
            self.zoombtn2.image = self.downimage
            self.zoombtn2['image'] = self.zoombtn2.image
            self.LEAVEDOWNSTATE = 0
        self.zoombtn2.bind('<Enter>', hoverdown)
        self.zoombtn2.bind('<Leave>', unhoverdown)
        def cmddown(event=''):
            if self.LEAVEDOWNSTATE:
                self.unzoom()
            self.ACTIVEDOWNSTATE = 0
        def activedown(event=''):
            self.zoombtn2.image = self.downimageactive
            self.zoombtn2['image'] = self.zoombtn2.image
            self.ACTIVEDOWNSTATE = 1
        self.zoombtn2.bind('<ButtonPress-1>', activedown)
        self.zoombtn2.bind('<ButtonRelease-1>', cmddown)

        #self.zoombtn1.pack(side=LEFT, padx=3, pady=3, expand=0)
        self.tit = Label(self.bar, font=(fontMaxOS, 15), fg='white', bg=BARCL, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur")
        self.tit.pack(pady=3, expand=1, side=LEFT, fill=X)
        # Здесь биндятся функции, передвигающие окно
        self.bar.bind("<Double-Button-1>", self.wrap)
        self.tit.bind("<Double-Button-1>", self.wrap)
        self.bar.bind("<ButtonPress-1>", self.StartMove)
        self.bar.bind("<ButtonRelease-1>", self.StopMove)
        self.bar.bind("<B1-Motion>", self.OnMotion)

        self.tit.bind("<ButtonPress-1>", self.StartMove)
        self.tit.bind("<ButtonRelease-1>", self.StopMove)
        self.tit.bind("<B1-Motion>", self.OnMotion)

        # Обеспечиваем hover эффект кнопкам на нашей панельке
        #self.closebtn.bind("<Enter>",self.__closebtne)
        #self.closebtn.bind("<Leave>",self.__closebtnl)
        #self.wrapbtn.bind("<Enter>",self.__wrapbtne)
        #self.wrapbtn.bind("<Leave>",self.__wrapbtnl)
        # Запоминаем ширину и высоту окна
        self.width = self.winfo_reqwidth()
        self.height = self.winfo_reqheight()
        # В этом framе создавайте новые виджеты
        self.content = Frame(self.mainframe2, bg = BGCL,highlightthickness = 0, bd=15, relief=FLAT)
        self.content.pack(fill=BOTH, expand=1, anchor=NW, side=LEFT)

        if self.resizeable:
            # создаём кнопку изменения размера
            self.resizebtn = Label(self.mainframe, bg = BARCL,fg = 'white',text = '=',font = ('Cousine',1),cursor = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Cross.cur")#)'tcross')
            self.resizebtn.pack(side=RIGHT, anchor=S, pady=0, padx=0, expand=0)
            # Её hover эффект
            # Здесь биндятся функции, меняющие размер окна
            self.resizebtn.bind("<ButtonPress-1>", self.StartResize)
            self.resizebtn.bind("<ButtonRelease-1>", self.StopResize)
            self.resizebtn.bind("<B1-Motion>", self.OnResize)
            self.zoombtn1.pack(side=LEFT, padx=1, pady=0, expand=0)

        if icon != None:
            try:
                self.icon = icon
                img = Image.open(self.icon)
                img = img.resize((20, 20), Image.ANTIALIAS)
                img = ImageTk.PhotoImage(img)
                self.bar.image = img
                self.iconlabel = Label(self.bar, image=self.bar.image, bg=BARCL, relief=RAISED, bd=0)
                self.iconlabel.pack(pady=3, side=LEFT, padx=3)
            except Exception:
                self.icon = Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','NoImage.png')
                img = Image.open(self.icon)
                img = img.resize((20, 20), Image.ANTIALIAS)
                img = ImageTk.PhotoImage(img)
                self.bar.image = img
                self.iconlabel = Label(self.bar, image=self.bar.image, bg=BARCL, relief=RAISED, bd=0)
                self.iconlabel.pack(pady=3, side=LEFT, padx=3)
        else:
            self.icon = Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','NoImage.png')
            img = Image.open(self.icon)
            img = img.resize((20, 20), Image.ANTIALIAS)
            img = ImageTk.PhotoImage(img)
            self.bar.image = img
            self.iconlabel = Label(self.bar, image=self.bar.image, bg=BARCL, relief=RAISED, bd=0)
            self.iconlabel.pack(pady=3, side=LEFT, padx=3)
        def menupost(event):
            self.menu = Menu(background=self.bg_, foreground=self.fg_, relief='flat', cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur", tearoff=0, bd=0, font=(self.font_, self.font_size), activebackground=self.selectbg_, activeforeground=self.fg_)
            if self.wrapstate == False and self.zoomstate == False:
                image_wrap = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','MENU_ICONS','wrap_on.png'))
                image_wrap = image_wrap.resize((15, 15), Image.ANTIALIAS)
                image_wrap = ImageTk.PhotoImage(image_wrap)
                self.menu.add_command(label='Свернуть', command=self.wrap, image=image_wrap, compound=LEFT)
            elif self.wrapstate == True and self.zoomstate == False:
                image_wrap = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','MENU_ICONS','wrap_off.png'))
                image_wrap = image_wrap.resize((15, 15), Image.ANTIALIAS)
                image_wrap = ImageTk.PhotoImage(image_wrap)
                self.menu.add_command(label='Развернуть', command=self.wrapoff, image=image_wrap, compound=LEFT)
            if self.resizeable:
                if self.zoomstate == False and self.wrapstate == False:
                    image_zoom = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_UP_BTN','hover.png'))
                    image_zoom = image_zoom.resize((15, 15), Image.ANTIALIAS)
                    image_zoom = ImageTk.PhotoImage(image_zoom)
                    self.menu.add_command(label='Развернуть на весь экран', command=self.zoom, image=image_zoom, compound=LEFT)
                elif self.zoomstate == True and self.wrapstate == False:
                    image_zoom = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_DOWN_BTN','hover.png'))
                    image_zoom = image_zoom.resize((15, 15), Image.ANTIALIAS)
                    image_zoom = ImageTk.PhotoImage(image_zoom)
                    self.menu.add_command(label='Свернуть до последнего размера', command=self.unzoom, image=image_zoom, compound=LEFT)
            if self.zoomstate == False and self.wrapstate == False:
                image_center = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'))
                image_center = image_center.resize((15, 15), Image.ANTIALIAS)
                image_center = ImageTk.PhotoImage(image_center)
                self.menu.add_command(label='Выровнить по центру', command=self.center, image=image_center, compound=LEFT)

            if self.topstate == False:
                image_top = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','no.png'))
                image_top = image_top.resize((15, 15), Image.ANTIALIAS)
                image_top = ImageTk.PhotoImage(image_top)
                self.menu.add_command(label='Поверх других', command=self.top, image=image_top, compound=LEFT)
            elif self.topstate == True:
                image_top = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','yes.png'))
                image_top = image_top.resize((15, 15), Image.ANTIALIAS)
                image_top = ImageTk.PhotoImage(image_top)
                self.menu.add_command(label='Поверх других', command=self.topoff, image=image_top, compound=LEFT)
            self.menu.add_separator()
            image = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','CLOSE_BTN','hover.png'))
            image = image.resize((15, 15), Image.ANTIALIAS)
            image = ImageTk.PhotoImage(image)
            self.menu.add_command(label='Закрыть', command=self.Exit, image=image, compound=LEFT)
            #global x, y
            x = event.x
            y = event.y
            self.menu.post(event.x_root, event.y_root)
        self.iconlabel.bind('<Button-1>', menupost)
        # Событие развёртывания окна (Редкое)
        self.bind('<Map>',self.Show)
        theme_update()
        GlobalUpdate()
    # функции hover эффектов
    # Передвижение окна
    def bindcursors(self, e=''):
        try:e.widget['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        except:pass
    def StartMove(self, event=''):
        global x, y
        x = event.x
        y = event.y
        if sys.platform == 'darwin':self.overrideredirect(1)
        if sys.platform == 'darwin':self.resizable(0,0)
        self['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.wm_attributes('-topmost', 1)
        self.bindcursors(e=event)
    def StopMove(self, event=''):
        global x, y
        x = None
        y = None
        if sys.platform == 'darwin':
            if self.wrapstate:self.overrideredirect(1)
            else:self.overrideredirect(0)
        if sys.platform == 'darwin':self.resizable(0,0)
        self['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.wm_attributes('-topmost', 1)
        self.bindcursors(e=event)
    def OnMotion(self, event=''):
        global x, y
        x_ = (event.x_root - x)
        y_ = (event.y_root - y)
        self.geometry("+%s+%s" % (x_, y_))
        if sys.platform == 'darwin':self.overrideredirect(1)
        if sys.platform == 'darwin':self.resizable(0,0)
        self['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.wm_attributes('-topmost', 1)
        self.bindcursors(e=event)
        if self.zoomstate:
            self.unzoom()

    def StartResize(self, event = None):
        self.resizex = event.x
        self.resizey = event.y
        self.resize = True
        self['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Cross.cur"
        self.resizefunc()
        if self.zoomstate:
            self.unzoom()
    def StopResize(self, event = None):
        self.resizex = None
        self.resizey = None
        self.resize = False
        self['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.bindcursors(e=event)
        self.resizefunc()
    def OnResize(self, event = None):
        deltax = event.x - self.resizex
        deltay = event.y - self.resizey
        x = self.width + deltax
        y = self.height + deltay
        self.width = barrier(x,min=self.wm_minsize()[0])
        self.height = barrier(y,min=self.wm_minsize()[1])
        self.geometry("%sx%s" % (self.width,self.height))
        self.Resize()
        if self.zoomstate == True:
            self.unzoom()
        self['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Cross.cur"
        self.resizefunc()
    def zoom(self, event=None):
        self.resizefunc()
        def sizexy(size):
            l1 = list(size)
            self.l2 = list(size)
            for i in range(len(l1)):
                if l1[i] == 'x':
                    l1[i] = ' '
                    self.l2[i] = ' '
                elif l1[i] == '+':
                    l1[i] = ' '
                    self.l2[i] = ' '
                else:
                    pass
            l1 = ''.join(l1)
            l1 = l1.split()
            self.l2 = ''.join(self.l2)
            self.l2 = self.l2.split()
            try:l1.pop(2)
            except Exception:pass

            try:l1.pop(-1)
            except Exception:pass

            try:self.l2.pop(0)
            except Exception:pass
            try:self.l2.pop(0)
            except Exception:pass

            return l1
        lastgeometry = sizexy(self.wm_geometry())
        self.X1 = lastgeometry[0]
        self.Y1 = lastgeometry[1]
        #self.overrideredirect(False)
        sizeX, sizeY = self.winfo_screenwidth(), self.winfo_screenheight()
        self.wm_geometry(f'{sizeX}x{sizeY}+0+0')
        self.zoombtn1.pack_forget()
        self.zoombtn2.pack(side=LEFT, padx=1, pady=0, expand=0)
        self.zoomstate = True
        self.bindcursors(e=event)
        self.resizefunc()
    def unzoom(self, event=None):
        if self.resize == False:
            self.wm_geometry(f'{self.X1}x{self.Y1}+{self.l2[0]}+{self.l2[1]}')
        elif self.resize == True:
            self.wm_geometry(f'{self.X1}x{self.Y1}')
        self.zoombtn2.pack_forget()
        self.zoombtn1.pack(side=LEFT, padx=1, pady=0, expand=0)
        self.zoomstate = False
        self.bindcursors(e=event)
        self.resizefunc()

    def center(self, event=None):
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)
        self.geometry('+{}+{}'.format(x, y))
        self.bindcursors(e=event)

    def wrap(self, event=None):
        if self.zoomstate == False:
            def sizexy(size):
                l1 = list(size)
                for i in range(len(l1)):
                    if l1[i] == 'x':
                        l1[i] = ' '
                    elif l1[i] == '+':
                        l1[i] = ' '
                    else:
                        pass
                l1 = ''.join(l1)
                l1 = l1.split()
                try:l1.pop(2)
                except Exception:pass

                try:l1.pop(-1)
                except Exception:pass

                return l1
            lastgeometry = sizexy(self.wm_geometry())
            self.X = lastgeometry[0]
            self.Y = lastgeometry[1]
            self.wm_minsize(60, 60)
            self.wm_geometry(f'60x60')
            if self.resizeable:
                if self.zoomstate == True:
                    self.zoombtn2.pack_forget()
                elif self.zoomstate == False:
                    self.zoombtn1.pack_forget()

            self.closebtn.pack_forget()
            self.tit.pack_forget()
            self.FrameButtons.pack_forget()
            self.bar.bind("<Double-Button-1>", self.wrapoff)
            self.tit.bind("<Double-Button-1>", self.wrapoff)
            self.wrapstate = True
            if self.resizeable:
                self.resizebtn.place_forget()
            self.bindcursors(e=event)

    def wrapoff(self, event=None):
        self.wm_minsize(self.mingeometry[0], self.mingeometry[1])
        self.wm_geometry(f'{self.X}x{self.Y}')
        self.bar.bind("<Double-Button-1>", self.wrap)
        self.tit.bind("<Double-Button-1>", self.wrap)
        self.closebtn.pack(side=LEFT, padx=1, pady=0, expand=0)
        self.iconlabel.pack_forget()
        if self.resizeable:
            if self.zoomstate == True:
                self.zoombtn2.pack(side=LEFT, padx=1, pady=0, expand=0)
            elif self.zoomstate == False:
                self.zoombtn1.pack(side=LEFT, padx=1, pady=0, expand=0)
        self.FrameButtons.pack(side=LEFT)
        self.tit.pack(pady=3, expand=1, side=LEFT, fill=X)
        self.iconlabel.pack(pady=3, side=LEFT, padx=3)
        self.wrapstate = False
        if self.resizeable:
            self.resizebtn.place(rely=0.993, relx=0.993)
        self.bindcursors(e=event)

    def Resize(self,event = None):
        self.onresizefunc(self.width,self.height)
        if self.resizeable:
            self.resizebtn.pack(side=RIGHT, anchor=S, pady=0, padx=0, expand=0)
            #self.resizebtn.pack(side=RIGHT, anchor=S, pady=0, padx=0)
        self.closebtn.pack(side=LEFT, pady=0)
        self.bindcursors(e=event)
        #self.content.pack_forget()
    def Exit(self,event = None):
        if self.exitfunc != empty:
            self.exitfunc()
        else:
            self.a = 0.95
            def exiting(event=None):
                after_exit = self.after(10, exiting)
                if self.a < 0:
                    self.after_cancel(after_exit)
                    self.after_cancel(self.global_after)
                    self.after_cancel(self.theme_after)
                    self.destroy()
                self.a -= 0.05
                try:
                    self.wm_attributes('-alpha', self.a)
                except Exception:
                    pass
            exiting()

    def Show(self,event = None):
        self.overrideredirect(True)
        if self.Showing:
            self.wm_attributes('-topmost', 1)
            self.Showing = False
            self.center()
            self.a = 0
            def showing(event=None):
                after_show = self.after(10, showing)
                if self.a > 0.9:
                    self.after_cancel(after_show)
                self.a += 0.05
                self.wm_attributes('-alpha', self.a)
            showing()


    def rootshow(self, event=None):
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)
        self.geometry('+{}+{}'.format(x, y))

    def title2(self=None, text='MaxOSTk', event=None):
        self.tit['text'] = text
    def exitfunc(self=None, command=Exit):
        self.command2 = command
        self.closebtn.config(command=self.command2)
    def minsize(self, x, y):
        self.x, self.y = x, y
        self.wm_minsize(self.x-self.geosizex, self.y-self.geosizex)
        self.mingeometry = (self.x-self.geosizex, self.y-self.geosizex)
    def ExitDestroy(self=None, event=None):
        self.a = 0.95
        def exiting(event=None):
            after_exit = self.after(10, exiting)
            if self.a < 0:
                self.after_cancel(after_exit)
                self.destroy()
            self.a -= 0.05
            try:
                self.wm_attributes('-alpha', self.a)
            except Exception:
                pass
        exiting()
    def top(self):
        def topping():
            self.topstate = 1
            self.aftertop = self.after(10, topping)
            self.wm_attributes('-topmost',1)
            self.lift()
        topping()
    def topoff(self):
        self.topstate = 0
        self.after_cancel(self.aftertop)

    def resizefuncset(self, command):
        self.resizefunc = command
        self.resizefunc()
    def geometry(self, size):
        self.geo = size

        if '+' in size:
            if 'x' not in size:
                self.wm_geometry(size)
            else:
                self.wm_geometry(f"{int(size.split('x')[0])-self.geosizex}x{int(size.split('x')[1].split('+')[0])-self.geosizey}")#+{size.split('x')[1].split('+')[1]}+{size.split('x')[1].split('+')[2]}
        else:
            self.wm_geometry(f"{int(size.split('x')[0])-self.geosizex}x{int(size.split('x')[1])-self.geosizey}")

class MaxOSTk_(wiget):
    def __init__(self, master=None,resizeable = True,exitfunc = empty,onresizefunc = empty, mingeometry=(75, 75), icon=None, resizefunc=empty):
        import sys
        from PIL import Image, ImageTk
        global BGCL, CANCELCL, CANCELHOVCL, INFOCL, INFOHOVCL, BARCL
        self.deiconify_state = 0

        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            self.theme_after = self.after(10000, lambda: Thread(target=theme_update, daemon=1).start())
            self.mainframe.configure(fg_color=bg_color)
            self.mainframe2.configure(fg_color=bg_color)

            self.bar['bg'] = bg_color
            self.tit['bg'] = bg_color
            self.FrameButtons['bg'] = bg_color
            self.closebtn['bg'] = bg_color
            self.zoombtn1['bg'] = bg_color
            self.zoombtn2['bg'] = bg_color
            self.content['bg'] = bg_color
            if self.resizeable:
                self.resizebtn['bg'] = bg_color
            self.iconlabel['bg'] = bg_color

            self.tit['fg'] = fg_color
            self.tit['font'] = (font_, font_size)

            def color_img(img, color):
                img = Image.open(img)
                pixdata = img.load()
                r, g, b, = ImageColor.getcolor(color, "RGB")
                for y in range(img.size[1]):
                    for x in range(img.size[0]):
                        alpha = pixdata[x, y][3]
                        if alpha:
                            pixdata[x, y] = (r, g, b, alpha)
                return img

            self.closeimage = color_img(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','CLOSE_BTN','normal.png')), color=fg_color)
            if system == 'darwin':self.closeimage = self.closeimage.resize((15, 15), Image.ANTIALIAS)
            elif system == 'win32':self.closeimage = self.closeimage.resize((15, 15), Image.ANTIALIAS)
            self.closeimage = ImageTk.PhotoImage(self.closeimage)
            if self.ACTIVECLSSTATE != 1 and self.LEAVECLSSTATE != 1:
                self.closebtn.image = self.closeimage
                self.closebtn['image'] = self.closebtn.image

            self.upimage = color_img(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_UP_BTN','normal.png')), color=fg_color)
            if system == 'darwin':self.upimage = self.upimage.resize((15, 15), Image.ANTIALIAS)
            elif system == 'win32':self.upimage = self.upimage.resize((15, 15), Image.ANTIALIAS)
            self.upimage = ImageTk.PhotoImage(self.upimage)
            if self.ACTIVEUPSTATE != 1 and self.LEAVEUPSTATE != 1:
                self.zoombtn1.image = self.upimage
                self.zoombtn1['image'] = self.zoombtn1.image

            self.downimage = color_img(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_DOWN_BTN','normal.png')), color=fg_color)
            if system == 'darwin':self.downimage = self.downimage.resize((15, 15), Image.ANTIALIAS)
            elif system == 'win32':self.downimage = self.downimage.resize((15, 15), Image.ANTIALIAS)
            self.downimage = ImageTk.PhotoImage(self.downimage)
            if self.ACTIVEDOWNSTATE != 1 and self.LEAVEDOWNSTATE != 1:
                self.zoombtn2.image = self.downimage
                self.zoombtn2['image'] = self.zoombtn2.image

            self.bg_ = bg_color
            self.fg_ = fg_color
            self.font_ = font_
            self.font_size = font_size
            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)
            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

            self.selectbg_ = selectbg

        def GlobalUpdate():
            self.global_after = self.after(100, GlobalUpdate)
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','exit_user.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.destroy()
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','sleep_mode.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.withdraw()
                    if self.deiconify_state != 0:
                        self.deiconify_state = 0
                elif text == 'false':
                    if self.deiconify_state != 1:
                        self.deiconify_state = 1
                    if self.deiconify_state:
                        #self.deiconify()
                        self.deiconify_state = 0
        wiget.__init__(self, master)
        self['bd'] = 7
        self['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.wm_attributes('-alpha', 0)
        self.mingeometry = mingeometry
        self.resize = False
        self.topstate = 0
        self.resizefunc = resizefunc
        print(self.mingeometry)
        Xmin = self.mingeometry[0]
        Ymin = self.mingeometry[1]
        self.resizable(0, 0)

        self.geosizex = int(open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','WINDOW_MANAGER','WINDOW_GEOMETRY','x.txt'), 'r', encoding='utf-8').readline())
        self.geosizey = int(open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','WINDOW_MANAGER','WINDOW_GEOMETRY','y.txt'), 'r', encoding='utf-8').readline())

        if system == 'darwin':
            self.wm_attributes("-transparent", True)
            self.config(bg='systemTransparent')
        elif system == 'win32':
            self.wm_attributes("-transparentcolor", '#123456')
            self['bg'] = '#123456'

        '''

        self.resizebottom = CTkLabel(self, fg_color='transparent', text='', height=10, width=5555)
        def hover_bottom(event=''):self['cursor'] = 'bottom_side'
        def unhover_bottom(event=''):self['cursor'] = ''
        self.resizebottom.bind('<Enter>', hover_bottom)
        self.resizebottom.bind('<Leave>', unhover_bottom)

        self.resizeleft = CTkLabel(self, fg_color='red', text='', height=5555, width=10)
        def hover_left(event=''):self['cursor'] = 'left_side'
        def unhover_left(event=''):self['cursor'] = ''
        self.resizeleft.bind('<Enter>', hover_left)
        self.resizeleft.bind('<Leave>', unhover_left)

        self.resizeright = CTkLabel(self, fg_color='transparent', text='', height=5555, width=10)
        def hover_right(event=''):self['cursor'] = 'right_side'
        def unhover_right(event=''):self['cursor'] = ''
        self.resizeright.bind('<Enter>', hover_right)
        self.resizeright.bind('<Leave>', unhover_right)


        self.resizebottomleft = CTkLabel(self, fg_color='transparent', text='', height=5555, width=10)
        def hover_bottomleft(event=''):self['cursor'] = 'bottom_left_corner'
        def unhover_bottomleft(event=''):self['cursor'] = ''
        self.resizebottomleft.bind('<Enter>', hover_bottomleft)
        self.resizebottomleft.bind('<Leave>', unhover_bottomleft)

        self.resizebottomright = CTkLabel(self, fg_color='transparent', text='', height=5555, width=10)
        def hover_bottomright(event=''):self['cursor'] = 'bottom_right_corner'
        def unhover_bottomright(event=''):self['cursor'] = ''
        self.resizebottomright.bind('<Enter>', hover_bottomright)
        self.resizebottomright.bind('<Leave>', unhover_bottomright)
        '''


        self.mainframe = CTkFrame(self, fg_color=BARCL, corner_radius=15)
        self.mainframe.pack(fill=BOTH, expand=1)

        '''
        self.resizebottom.place(relx=0, rely=0.99)
        self.resizeleft.place(x=0, y=0)
        self.resizeright.place(y=0, relx=0.99)


        self.resizebottomleft.place(x=0, rely=0.99)
        self.resizebottomright.place(relx=0.99, rely=0.99)
        '''

        self.mainframe.bind("<Double-Button-1>", self.wrap)
        self.mainframe.bind("<ButtonPress-1>", self.StartMove)
        self.mainframe.bind("<ButtonRelease-1>", self.StopMove)
        self.mainframe.bind("<B1-Motion>", self.OnMotion)


        self.mainframe2 = CTkFrame(self.mainframe, fg_color=BGCL, corner_radius=0)
        self.mainframe2.pack(fill=BOTH, expand=1, padx=10, pady=10)

        self.X = None
        self.Y = None
        self.Showing = True
        self.zoomstate = False
        self.wrapstate = False
        self['relief'] = FLAT
        def passDEF(event=None):pass
        self.protocol('WM_DELETE_WINDOW', passDEF)
        self.resizeable = resizeable
        self.exitfunc = exitfunc
        self.onresizefunc = onresizefunc
        #self.wm_attributes('-topmost', 1)
        #self.wm_attributes('-topmost',True) # приоритетный режим
        self.bar = Frame(self.mainframe2, bg = BARCL, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur") # Создаём свою панельку, как отдельный виджет


        self.closeimage = Image.open(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','CLOSE_BTN','normal.png')))
        if system == 'darwin':self.closeimage = self.closeimage.resize((15, 15), Image.ANTIALIAS)
        elif system == 'win32':self.closeimage = self.closeimage.resize((15, 15), Image.ANTIALIAS)
        self.closeimage = ImageTk.PhotoImage(self.closeimage)

        self.closeimagehover = Image.open(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','CLOSE_BTN','hover.png')))
        if system == 'darwin':self.closeimagehover = self.closeimagehover.resize((15, 15), Image.ANTIALIAS)
        elif system == 'win32':self.closeimagehover = self.closeimagehover.resize((15, 15), Image.ANTIALIAS)
        self.closeimagehover = ImageTk.PhotoImage(self.closeimagehover)

        self.closeimageactive = Image.open(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','CLOSE_BTN','active.png')))
        if system == 'darwin':self.closeimageactive = self.closeimageactive.resize((15, 15), Image.ANTIALIAS)
        elif system == 'win32':self.closeimageactive = self.closeimageactive.resize((15, 15), Image.ANTIALIAS)
        self.closeimageactive = ImageTk.PhotoImage(self.closeimageactive)



        self.upimage = Image.open(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_UP_BTN','normal.png')))
        if system == 'darwin':self.upimage = self.upimage.resize((15, 15), Image.ANTIALIAS)
        elif system == 'win32':self.upimage = self.upimage.resize((15, 15), Image.ANTIALIAS)
        self.upimage = ImageTk.PhotoImage(self.upimage)

        self.upimagehover = Image.open(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_UP_BTN','hover.png')))
        if system == 'darwin':self.upimagehover = self.upimagehover.resize((15, 15), Image.ANTIALIAS)
        elif system == 'win32':self.upimagehover = self.upimagehover.resize((15, 15), Image.ANTIALIAS)
        self.upimagehover = ImageTk.PhotoImage(self.upimagehover)

        self.upimageactive = Image.open(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_UP_BTN','active.png')))
        if system == 'darwin':self.upimageactive = self.upimageactive.resize((15, 15), Image.ANTIALIAS)
        elif system == 'win32':self.upimageactive = self.upimageactive.resize((15, 15), Image.ANTIALIAS)
        self.upimageactive = ImageTk.PhotoImage(self.upimageactive)



        self.downimage = Image.open(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_DOWN_BTN','normal.png')))
        if system == 'darwin':self.downimage = self.downimage.resize((15, 15), Image.ANTIALIAS)
        elif system == 'win32':self.downimage = self.downimage.resize((15, 15), Image.ANTIALIAS)
        self.downimage = ImageTk.PhotoImage(self.downimage)

        self.downimagehover = Image.open(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_DOWN_BTN','hover.png')))
        if system == 'darwin':self.downimagehover = self.downimagehover.resize((15, 15), Image.ANTIALIAS)
        elif system == 'win32':self.downimagehover = self.downimagehover.resize((15, 15), Image.ANTIALIAS)
        self.downimagehover = ImageTk.PhotoImage(self.downimagehover)

        self.downimageactive = Image.open(os.path.abspath(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_DOWN_BTN','active.png')))
        if system == 'darwin':self.downimageactive = self.downimageactive.resize((15, 15), Image.ANTIALIAS)
        elif system == 'win32':self.downimageactive = self.downimageactive.resize((15, 15), Image.ANTIALIAS)
        self.downimageactive = ImageTk.PhotoImage(self.downimageactive)


        self.bar.pack(anchor=NW, fill=X)
        self.FrameButtons = Frame(self.bar, bg = BARCL, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur")
        self.FrameButtons.pack(side=LEFT)
        self.closebtn = Label(self.FrameButtons, bg=BARCL, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
        self.closebtn.image = self.closeimage
        self.closebtn['image'] = self.closebtn.image
        self.LEAVECLSSTATE = 0
        self.ACTIVECLSSTATE = 0
        def hoverclose(event=''):
            if self.ACTIVECLSSTATE:
                self.closebtn.image = self.closeimageactive
                self.closebtn['image'] = self.closebtn.image
            else:
                self.closebtn.image = self.closeimagehover
                self.closebtn['image'] = self.closebtn.image
            self.LEAVECLSSTATE = 1
        def unhoverclose(event=''):
            self.closebtn.image = self.closeimage
            self.closebtn['image'] = self.closebtn.image
            self.LEAVECLSSTATE = 0
        self.closebtn.bind('<Enter>', hoverclose)
        self.closebtn.bind('<Leave>', unhoverclose)
        def cmdcls(event=''):
            if self.LEAVECLSSTATE:
                self.Exit()
            self.ACTIVECLSSTATE = 0
        def activecls(event=''):
            self.closebtn.image = self.closeimageactive
            self.closebtn['image'] = self.closebtn.image
            self.ACTIVECLSSTATE = 1
        self.closebtn.bind('<ButtonPress-1>', activecls)
        self.closebtn.bind('<ButtonRelease-1>', cmdcls)

        self.closebtn.pack(side=LEFT, padx=1, pady=0, expand=0)
        self.X1 = None
        self.Y1 = None


        self.zoombtn1 = Label(self.FrameButtons, bg=BARCL, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
        self.zoombtn1.image = self.upimage
        self.zoombtn1['image'] = self.zoombtn1.image
        self.LEAVEUPSTATE = 0
        self.ACTIVEUPSTATE = 0
        def hoverup(event=''):
            if self.ACTIVEUPSTATE:
                self.zoombtn1.image = self.upimageactive
                self.zoombtn1['image'] = self.zoombtn1.image
            else:
                self.zoombtn1.image = self.upimagehover
                self.zoombtn1['image'] = self.zoombtn1.image
            self.LEAVEUPSTATE = 1
        def unhoverup(event=''):
            self.zoombtn1.image = self.upimage
            self.zoombtn1['image'] = self.zoombtn1.image
            self.LEAVEUPSTATE = 0
        self.zoombtn1.bind('<Enter>', hoverup)
        self.zoombtn1.bind('<Leave>', unhoverup)
        def cmdup(event=''):
            if self.LEAVEUPSTATE:
                self.zoom()
            self.ACTIVECLSSTATE = 0
        def activeup(event=''):
            self.zoombtn1.image = self.upimageactive
            self.zoombtn1['image'] = self.zoombtn1.image
            self.ACTIVEUPSTATE = 1
        self.zoombtn1.bind('<ButtonPress-1>', activeup)
        self.zoombtn1.bind('<ButtonRelease-1>', cmdup)


        self.zoombtn2 = Label(self.FrameButtons, bg=BARCL, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
        self.zoombtn2.image = self.downimage
        self.zoombtn2['image'] = self.zoombtn2.image
        self.LEAVEDOWNSTATE = 0
        self.ACTIVEDOWNSTATE = 0
        def hoverdown(event=''):
            if self.ACTIVEDOWNSTATE:
                self.zoombtn2.image = self.downimageactive
                self.zoombtn2['image'] = self.zoombtn2.image
            else:
                self.zoombtn2.image = self.downimagehover
                self.zoombtn2['image'] = self.zoombtn2.image
            self.LEAVEDOWNSTATE = 1
        def unhoverdown(event=''):
            self.zoombtn2.image = self.downimage
            self.zoombtn2['image'] = self.zoombtn2.image
            self.LEAVEDOWNSTATE = 0
        self.zoombtn2.bind('<Enter>', hoverdown)
        self.zoombtn2.bind('<Leave>', unhoverdown)
        def cmddown(event=''):
            if self.LEAVEDOWNSTATE:
                self.unzoom()
            self.ACTIVEDOWNSTATE = 0
        def activedown(event=''):
            self.zoombtn2.image = self.downimageactive
            self.zoombtn2['image'] = self.zoombtn2.image
            self.ACTIVEDOWNSTATE = 1
        self.zoombtn2.bind('<ButtonPress-1>', activedown)
        self.zoombtn2.bind('<ButtonRelease-1>', cmddown)

        #self.zoombtn1.pack(side=LEFT, padx=3, pady=3, expand=0)
        self.tit = Label(self.bar, font=(fontMaxOS, 15), fg='white', bg=BARCL, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur")
        self.tit.pack(pady=3, expand=1, side=LEFT, fill=X)
        # Здесь биндятся функции, передвигающие окно
        self.bar.bind("<Double-Button-1>", self.wrap)
        self.tit.bind("<Double-Button-1>", self.wrap)
        self.bar.bind("<ButtonPress-1>", self.StartMove)
        self.bar.bind("<ButtonRelease-1>", self.StopMove)
        self.bar.bind("<B1-Motion>", self.OnMotion)

        self.tit.bind("<ButtonPress-1>", self.StartMove)
        self.tit.bind("<ButtonRelease-1>", self.StopMove)
        self.tit.bind("<B1-Motion>", self.OnMotion)

        # Обеспечиваем hover эффект кнопкам на нашей панельке
        #self.closebtn.bind("<Enter>",self.__closebtne)
        #self.closebtn.bind("<Leave>",self.__closebtnl)
        #self.wrapbtn.bind("<Enter>",self.__wrapbtne)
        #self.wrapbtn.bind("<Leave>",self.__wrapbtnl)
        # Запоминаем ширину и высоту окна
        self.width = self.winfo_reqwidth()
        self.height = self.winfo_reqheight()
        # В этом framе создавайте новые виджеты
        self.content = Frame(self.mainframe2, bg = BGCL,highlightthickness = 0, bd=15, relief=FLAT)
        self.content.pack(fill=BOTH, expand=1, anchor=NW, side=LEFT)

        if self.resizeable:
            # создаём кнопку изменения размера
            self.resizebtn = Label(self.mainframe, bg = BARCL,fg = 'white',text = '=',font = ('Cousine',1),cursor = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Cross.cur")#)'tcross')
            self.resizebtn.pack(side=RIGHT, anchor=S, pady=0, padx=0, expand=0)
            # Её hover эффект
            # Здесь биндятся функции, меняющие размер окна
            self.resizebtn.bind("<ButtonPress-1>", self.StartResize)
            self.resizebtn.bind("<ButtonRelease-1>", self.StopResize)
            self.resizebtn.bind("<B1-Motion>", self.OnResize)
            self.zoombtn1.pack(side=LEFT, padx=1, pady=0, expand=0)

        if icon != None:
            try:
                self.icon = icon
                img = Image.open(self.icon)
                img = img.resize((20, 20), Image.ANTIALIAS)
                img = ImageTk.PhotoImage(img)
                self.bar.image = img
                self.iconlabel = Label(self.bar, image=self.bar.image, bg=BARCL, relief=RAISED, bd=0)
                self.iconlabel.pack(pady=3, side=LEFT, padx=3)
            except Exception:
                self.icon = Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','NoImage.png')
                img = Image.open(self.icon)
                img = img.resize((20, 20), Image.ANTIALIAS)
                img = ImageTk.PhotoImage(img)
                self.bar.image = img
                self.iconlabel = Label(self.bar, image=self.bar.image, bg=BARCL, relief=RAISED, bd=0)
                self.iconlabel.pack(pady=3, side=LEFT, padx=3)
        else:
            self.icon = Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','NoImage.png')
            img = Image.open(self.icon)
            img = img.resize((20, 20), Image.ANTIALIAS)
            img = ImageTk.PhotoImage(img)
            self.bar.image = img
            self.iconlabel = Label(self.bar, image=self.bar.image, bg=BARCL, relief=RAISED, bd=0)
            self.iconlabel.pack(pady=3, side=LEFT, padx=3)
        def menupost(event):
            self.menu = Menu(background=self.bg_, foreground=self.fg_, relief='flat', cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur", tearoff=0, bd=0, font=(self.font_, self.font_size), activebackground=self.selectbg_, activeforeground=self.fg_)
            if self.wrapstate == False and self.zoomstate == False:
                image_wrap = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','MENU_ICONS','wrap_on.png'))
                image_wrap = image_wrap.resize((15, 15), Image.ANTIALIAS)
                image_wrap = ImageTk.PhotoImage(image_wrap)
                self.menu.add_command(label='Свернуть', command=self.wrap, image=image_wrap, compound=LEFT)
            elif self.wrapstate == True and self.zoomstate == False:
                image_wrap = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','MENU_ICONS','wrap_off.png'))
                image_wrap = image_wrap.resize((15, 15), Image.ANTIALIAS)
                image_wrap = ImageTk.PhotoImage(image_wrap)
                self.menu.add_command(label='Развернуть', command=self.wrapoff, image=image_wrap, compound=LEFT)
            if self.resizeable:
                if self.zoomstate == False and self.wrapstate == False:
                    image_zoom = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_UP_BTN','hover.png'))
                    image_zoom = image_zoom.resize((15, 15), Image.ANTIALIAS)
                    image_zoom = ImageTk.PhotoImage(image_zoom)
                    self.menu.add_command(label='Развернуть на весь экран', command=self.zoom, image=image_zoom, compound=LEFT)
                elif self.zoomstate == True and self.wrapstate == False:
                    image_zoom = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','WRAP_DOWN_BTN','hover.png'))
                    image_zoom = image_zoom.resize((15, 15), Image.ANTIALIAS)
                    image_zoom = ImageTk.PhotoImage(image_zoom)
                    self.menu.add_command(label='Свернуть до последнего размера', command=self.unzoom, image=image_zoom, compound=LEFT)
            if self.zoomstate == False and self.wrapstate == False:
                image_center = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'))
                image_center = image_center.resize((15, 15), Image.ANTIALIAS)
                image_center = ImageTk.PhotoImage(image_center)
                self.menu.add_command(label='Выровнить по центру', command=self.center, image=image_center, compound=LEFT)

            if self.topstate == False:
                image_top = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','no.png'))
                image_top = image_top.resize((15, 15), Image.ANTIALIAS)
                image_top = ImageTk.PhotoImage(image_top)
                self.menu.add_command(label='Поверх других', command=self.top, image=image_top, compound=LEFT)
            elif self.topstate == True:
                image_top = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','yes.png'))
                image_top = image_top.resize((15, 15), Image.ANTIALIAS)
                image_top = ImageTk.PhotoImage(image_top)
                self.menu.add_command(label='Поверх других', command=self.topoff, image=image_top, compound=LEFT)
            self.menu.add_separator()
            image = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','MAXOSTK_BUTTONS','CLOSE_BTN','hover.png'))
            image = image.resize((15, 15), Image.ANTIALIAS)
            image = ImageTk.PhotoImage(image)
            self.menu.add_command(label='Закрыть', command=self.Exit, image=image, compound=LEFT)
            global x, y
            x = event.x
            y = event.y
            self.menu.post(event.x_root, event.y_root)
        self.iconlabel.bind('<Button-1>', menupost)
        # Событие развёртывания окна (Редкое)
        self.bind('<Map>',self.Show)
        theme_update()
        GlobalUpdate()
    # функции hover эффектов
    # Передвижение окна
    def bindcursors(self, e=''):
        try:e.widget['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        except:pass
    def StartMove(self, event=''):
        global x, y
        x = event.x
        y = event.y
        if sys.platform == 'darwin':self.overrideredirect(1)
        if sys.platform == 'darwin':self.resizable(0,0)
        self['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.wm_attributes('-topmost', 1)
        self.bindcursors(e=event)
    def StopMove(self, event=''):
        global x, y
        x = None
        y = None
        if sys.platform == 'darwin':
            if self.wrapstate:self.overrideredirect(1)
            else:self.overrideredirect(0)
        if sys.platform == 'darwin':self.resizable(0,0)
        self['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.wm_attributes('-topmost', 1)
        self.bindcursors(e=event)
    def OnMotion(self, event=''):
        global x, y
        x_ = (event.x_root - x)
        y_ = (event.y_root - y)
        self.geometry("+%s+%s" % (x_, y_))
        if sys.platform == 'darwin':self.overrideredirect(1)
        if sys.platform == 'darwin':self.resizable(0,0)
        self['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.wm_attributes('-topmost', 1)
        self.bindcursors(e=event)
        if self.zoomstate:
            self.unzoom()

    def StartResize(self, event = None):
        self.resizex = event.x
        self.resizey = event.y
        self.resize = True
        self['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Cross.cur"
        self.resizefunc()
        if self.zoomstate:
            self.unzoom()
    def StopResize(self, event = None):
        self.resizex = None
        self.resizey = None
        self.resize = False
        self['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.bindcursors(e=event)
        self.resizefunc()
    def OnResize(self, event = None):
        deltax = event.x - self.resizex
        deltay = event.y - self.resizey
        x = self.width + deltax
        y = self.height + deltay
        self.width = barrier(x,min=self.wm_minsize()[0])
        self.height = barrier(y,min=self.wm_minsize()[1])
        self.geometry("%sx%s" % (self.width,self.height))
        self.Resize()
        if self.zoomstate == True:
            self.unzoom()
        self['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Cross.cur"
        self.resizefunc()
    def zoom(self, event=None):
        self.resizefunc()
        def sizexy(size):
            l1 = list(size)
            self.l2 = list(size)
            for i in range(len(l1)):
                if l1[i] == 'x':
                    l1[i] = ' '
                    self.l2[i] = ' '
                elif l1[i] == '+':
                    l1[i] = ' '
                    self.l2[i] = ' '
                else:
                    pass
            l1 = ''.join(l1)
            l1 = l1.split()
            self.l2 = ''.join(self.l2)
            self.l2 = self.l2.split()
            try:l1.pop(2)
            except Exception:pass

            try:l1.pop(-1)
            except Exception:pass

            try:self.l2.pop(0)
            except Exception:pass
            try:self.l2.pop(0)
            except Exception:pass

            return l1
        lastgeometry = sizexy(self.wm_geometry())
        self.X1 = lastgeometry[0]
        self.Y1 = lastgeometry[1]
        #self.overrideredirect(False)
        sizeX, sizeY = self.winfo_screenwidth(), self.winfo_screenheight()
        self.wm_geometry(f'{sizeX}x{sizeY}+0+0')
        self.zoombtn1.pack_forget()
        self.zoombtn2.pack(side=LEFT, padx=1, pady=0, expand=0)
        self.zoomstate = True
        self.bindcursors(e=event)
        self.resizefunc()
    def unzoom(self, event=None):
        if self.resize == False:
            self.wm_geometry(f'{self.X1}x{self.Y1}+{self.l2[0]}+{self.l2[1]}')
        elif self.resize == True:
            self.wm_geometry(f'{self.X1}x{self.Y1}')
        self.zoombtn2.pack_forget()
        self.zoombtn1.pack(side=LEFT, padx=1, pady=0, expand=0)
        self.zoomstate = False
        self.bindcursors(e=event)
        self.resizefunc()

    def center(self, event=None):
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)
        self.geometry('+{}+{}'.format(x, y))
        self.bindcursors(e=event)

    def wrap(self, event=None):
        if self.zoomstate == False:
            def sizexy(size):
                l1 = list(size)
                for i in range(len(l1)):
                    if l1[i] == 'x':
                        l1[i] = ' '
                    elif l1[i] == '+':
                        l1[i] = ' '
                    else:
                        pass
                l1 = ''.join(l1)
                l1 = l1.split()
                try:l1.pop(2)
                except Exception:pass

                try:l1.pop(-1)
                except Exception:pass

                return l1
            lastgeometry = sizexy(self.wm_geometry())
            self.X = lastgeometry[0]
            self.Y = lastgeometry[1]
            self.wm_minsize(60, 60)
            self.wm_geometry(f'60x60')
            if self.resizeable:
                if self.zoomstate == True:
                    self.zoombtn2.pack_forget()
                elif self.zoomstate == False:
                    self.zoombtn1.pack_forget()

            self.closebtn.pack_forget()
            self.tit.pack_forget()
            self.FrameButtons.pack_forget()
            self.bar.bind("<Double-Button-1>", self.wrapoff)
            self.tit.bind("<Double-Button-1>", self.wrapoff)
            self.wrapstate = True
            if self.resizeable:
                self.resizebtn.place_forget()
            self.bindcursors(e=event)

    def wrapoff(self, event=None):
        self.wm_minsize(self.mingeometry[0], self.mingeometry[1])
        self.wm_geometry(f'{self.X}x{self.Y}')
        self.bar.bind("<Double-Button-1>", self.wrap)
        self.tit.bind("<Double-Button-1>", self.wrap)
        self.closebtn.pack(side=LEFT, padx=1, pady=0, expand=0)
        self.iconlabel.pack_forget()
        if self.resizeable:
            if self.zoomstate == True:
                self.zoombtn2.pack(side=LEFT, padx=1, pady=0, expand=0)
            elif self.zoomstate == False:
                self.zoombtn1.pack(side=LEFT, padx=1, pady=0, expand=0)
        self.FrameButtons.pack(side=LEFT)
        self.tit.pack(pady=3, expand=1, side=LEFT, fill=X)
        self.iconlabel.pack(pady=3, side=LEFT, padx=3)
        self.wrapstate = False
        if self.resizeable:
            self.resizebtn.place(rely=0.993, relx=0.993)
        self.bindcursors(e=event)

    def Resize(self,event = None):
        self.onresizefunc(self.width,self.height)
        if self.resizeable:
            self.resizebtn.pack(side=RIGHT, anchor=S, pady=0, padx=0, expand=0)
            #self.resizebtn.pack(side=RIGHT, anchor=S, pady=0, padx=0)
        self.closebtn.pack(side=LEFT, pady=0)
        self.bindcursors(e=event)
        #self.content.pack_forget()
    def Exit(self,event = None):
        if self.exitfunc != empty:
            self.exitfunc()
        else:
            self.a = 0.95
            def exiting(event=None):
                after_exit = self.after(10, exiting)
                if self.a < 0:
                    self.after_cancel(after_exit)
                    self.after_cancel(self.global_after)
                    self.after_cancel(self.theme_after)
                    self.destroy()
                self.a -= 0.05
                try:
                    self.wm_attributes('-alpha', self.a)
                except Exception:
                    pass
            exiting()

    def Show(self,event = None):
        self.overrideredirect(0)
        if self.Showing:
            self.wm_attributes('-topmost', 1)
            self.Showing = False
            self.center()
            self.a = 0
            def showing(event=None):
                after_show = self.after(10, showing)
                if self.a > 0.9:
                    self.after_cancel(after_show)
                self.a += 0.05
                self.wm_attributes('-alpha', self.a)
            showing()


    def rootshow(self, event=None):
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)
        self.geometry('+{}+{}'.format(x, y))

    def title2(self=None, text='MaxOSTk', event=None):
        self.tit['text'] = text
    def exitfunc(self=None, command=Exit):
        self.command2 = command
        self.closebtn.config(command=self.command2)
    def minsize(self, x, y):
        self.x, self.y = x, y
        self.wm_minsize(self.x-self.geosizex, self.y-self.geosizex)
        self.mingeometry = (self.x-self.geosizex, self.y-self.geosizex)
    def ExitDestroy(self=None, event=None):
        self.a = 0.95
        def exiting(event=None):
            after_exit = self.after(10, exiting)
            if self.a < 0:
                self.after_cancel(after_exit)
                self.destroy()
            self.a -= 0.05
            try:
                self.wm_attributes('-alpha', self.a)
            except Exception:
                pass
        exiting()
    def top(self):
        def topping():
            self.topstate = 1
            self.aftertop = self.after(10, topping)
            self.wm_attributes('-topmost',1)
            self.lift()
        topping()
    def topoff(self):
        self.topstate = 0
        self.after_cancel(self.aftertop)

    def resizefuncset(self, command):
        self.resizefunc = command
        self.resizefunc()
    def geometry(self, size):
        self.geo = size

        if '+' in size:
            if 'x' not in size:
                self.wm_geometry(size)
            else:
                self.wm_geometry(f"{int(size.split('x')[0])-self.geosizex}x{int(size.split('x')[1].split('+')[0])-self.geosizey}")#+{size.split('x')[1].split('+')[1]}+{size.split('x')[1].split('+')[2]}
        else:
            self.wm_geometry(f"{int(size.split('x')[0])-self.geosizex}x{int(size.split('x')[1])-self.geosizey}")

if sys.platform == 'win32':
    MaxOSTk = MaxOSTk2
elif sys.platform == 'darwin':
    MaxOSTk = MaxOSTk_

class MaxOSListbox(CTkListbox):
    def __init__(self, master='', multiple_selection=False):
        CTkListbox.__init__(self, master, multiple_selection)
        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)


            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())

            theme_after = master.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())

            color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                color_rgb_activebackground[0] = 0
            else:
                color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

            if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                color_rgb_activebackground[1] = 0
            else:
                color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

            if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                color_rgb_activebackground[2] = 0
            else:
                color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

            activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

            self.configure(fg_color=bg_color)
            self.configure(text_color=fg_color)
            self.configure(hover_color=selectbg)
            self.configure(highlight_color=activebackground)
            self.configure(font=(font_, font_size))
        theme_update()


class MaxOSWidget(CTkFrame):
    def __init__(self, corner_radius=10, title='MaxOSWidget', exitfunc=empty):
        self.Showing = True
        self.exitfunc = exitfunc
        self.widget = Toplevel()
        self.frame = CTkFrame(master=self.widget, fg_color='white', corner_radius=corner_radius)
        def startMove(event):
            global x, y
            x = event.x
            y = event.y
        def stopMove(event):
            global x, y
            x = None
            y = None
        def moving(event):
            global x, y
            x_ = (event.x_root - x)
            y_ = (event.y_root - y)
            self.widget.geometry("+%s+%s" % (x_, y_))
        self.widget.wm_attributes('-topmost',1)
        #self.widget.overrideredirect(1)
        #self.widget.wm_attributes('-topmost',1)

        if system == 'darwin':
            self.widget.wm_attributes("-transparent", True)
            self.widget.config(bg='systemTransparent')
        elif system == 'win32':
            self.widget.wm_attributes("-transparentcolor", self.widget['bg'])

        self.frame.pack(expand=1, fill=BOTH, padx=10, pady=10)
        self.frame.bind("<Button-1>", startMove)
        self.frame.bind("<ButtonRelease-1>", stopMove)
        self.frame.bind("<B1-Motion>", moving)


        def roothover(event=None):
            self.widget.wm_attributes('-alpha', 0.9)
            frametit.place(x=0, y=0)
        def rootunhover(event=None):
            self.widget.wm_attributes('-alpha', 0.5)
            frametit.place_forget()

        self.closeimage = Image.open(os.path.abspath(Path('!SysIcons','MaxOSTk','closewidget.png')))
        if system == 'darwin':self.closeimage = self.closeimage.resize((25, 25), Image.ANTIALIAS)
        elif system == 'win32':self.closeimage = self.closeimage.resize((25, 25), Image.ANTIALIAS)
        self.closeimage = ImageTk.PhotoImage(self.closeimage)

        self.closeimagehover = Image.open(os.path.abspath(Path('!SysIcons','MaxOSTk','closewidgethover.png')))
        if system == 'darwin':self.closeimagehover = self.closeimagehover.resize((25, 25), Image.ANTIALIAS)
        elif system == 'win32':self.closeimagehover = self.closeimagehover.resize((25, 25), Image.ANTIALIAS)
        self.closeimagehover = ImageTk.PhotoImage(self.closeimagehover)

        self.closeimageactive = Image.open(os.path.abspath(Path('!SysIcons','MaxOSTk','closewidgetactive.png')))
        if system == 'darwin':self.closeimageactive = self.closeimageactive.resize((25, 25), Image.ANTIALIAS)
        elif system == 'win32':self.closeimageactive = self.closeimageactive.resize((25, 25), Image.ANTIALIAS)
        self.closeimageactive = ImageTk.PhotoImage(self.closeimageactive)

        frametit = CTkFrame(self.widget, fg_color=BARCL)
        frametit.bind("<Button-1>", startMove)
        frametit.bind("<ButtonRelease-1>", stopMove)
        frametit.bind("<B1-Motion>", moving)

        self.closebtn = Label(frametit, bg=BARCL, cursor='hand1')
        self.closebtn.image = self.closeimage
        self.closebtn['image'] = self.closebtn.image
        self.LEAVECLSSTATE = 0
        self.ACTIVECLSSTATE = 0
        def hoverclose(event=''):
            if self.ACTIVECLSSTATE:
                self.closebtn.image = self.closeimageactive
                self.closebtn['image'] = self.closebtn.image
            else:
                self.closebtn.image = self.closeimagehover
                self.closebtn['image'] = self.closebtn.image
            self.LEAVECLSSTATE = 1
        def unhoverclose(event=''):
            self.closebtn.image = self.closeimage
            self.closebtn['image'] = self.closebtn.image
            self.LEAVECLSSTATE = 0
        self.closebtn.bind('<Enter>', hoverclose)
        self.closebtn.bind('<Leave>', unhoverclose)
        def cmdcls(event=''):
            if self.LEAVECLSSTATE:
                self.Exit()
            self.ACTIVECLSSTATE = 0
        def activecls(event=''):
            self.closebtn.image = self.closeimageactive
            self.closebtn['image'] = self.closebtn.image
            self.ACTIVECLSSTATE = 1
        self.closebtn.bind('<ButtonPress-1>', activecls)
        self.closebtn.bind('<ButtonRelease-1>', cmdcls)

        self.closebtn.pack(side=LEFT, padx=5, pady=5)

        #btnclose = LabelButton(frametit, text='✕', bg=BARCL, fg='white', selectbg='red', selectfg='white', font=(fontMaxOS, 14), command=self.Exit, activebackground='lightred' ,activeforeground='white')
        #btnclose.pack(side=LEFT, padx=5, pady=5)
        labeltit = CTkLabel(frametit, text=title, fg_color=BARCL, text_color='white', font=(fontMaxOS, 14), corner_radius=15)
        labeltit.pack(side=LEFT, padx=5, pady=5)
        labeltit.bind("<Button-1>", startMove)
        labeltit.bind("<ButtonRelease-1>", stopMove)
        labeltit.bind("<B1-Motion>", moving)
        self.widget.bind('<Enter>', roothover)
        self.widget.bind('<Leave>', rootunhover)
        self.widget.bind("<Button-1>", startMove)
        self.widget.bind("<ButtonRelease-1>", stopMove)
        self.widget.bind("<B1-Motion>", moving)
        self.widget.bind('<Map>', self.Show)

    def Exit(self,event = None):
        self.a = 0.95
        self.exitfunc()
        def exiting(event=None):
            after_exit = self.widget.after(10, exiting)
            if self.a < 0:
                self.widget.after_cancel(after_exit)
                self.widget.destroy()
            self.a -= 0.05
            try:
                self.widget.wm_attributes('-alpha', self.a)
            except Exception:
                pass
        exiting()

    def center(self, event=None):
        width = self.widget.winfo_width()
        height = self.widget.winfo_height()
        x = (self.widget.winfo_screenwidth() // 2) - (width // 2)
        y = (self.widget.winfo_screenheight() // 2) - (height // 2)
        self.widget.geometry('+{}+{}'.format(x, y))

    def Show(self,event = None):
        self.widget.overrideredirect(1)
        self.widget.wm_attributes('-topmost',1)
        if self.Showing == True:
            self.widget.wm_attributes('-topmost', 1)
            self.center()
            self.a = 0
            if sys.platform == 'darwin':
                self.widget.wm_attributes("-transparent", True)
                self.widget.config(bg='systemTransparent')
            elif sys.platform == 'win32':
                self.widget.wm_attributes("-transparentcolor", self.widget['bg'])
            def showing(event=None):
                after_show = self.widget.after(10, showing)
                if self.a > 0.9:
                    self.widget.after_cancel(after_show)
                self.a += 0.05
                self.widget.wm_attributes('-alpha', self.a)
            showing()
            self.Showing = False
