from audioplayer import *
from pathlib import Path
from threading import Thread

class PlaySound():
    def __init__(self, name):
        self.volume = ''

        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_OUTPUT','AUDIO_OUTPUT','volume.txt'), 'r', encoding='utf-8') as v:
            self.volume = int(v.readline())

        self.player = AudioPlayer(str(Path(name)))
        self.player.volume = self.volume
        Thread(target=lambda: self.player.play(block=True), daemon=1).start()
