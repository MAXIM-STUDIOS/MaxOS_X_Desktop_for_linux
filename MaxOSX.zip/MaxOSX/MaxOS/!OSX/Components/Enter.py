from tkinter import Frame, Label, BOTH
import time
from .Libraries.SoundPlayer import PlaySound
from pathlib import Path
import sys
import os

class EnterUser():
    def __init__(self, master, tb, sizeX, sizeY, system):
        self.sizeX = sizeX
        self.sizeY = sizeY
        self.system = system
        with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','exit_user.txt',), 'w', encoding='utf-8') as f:
            f.write('True')
        master.destroy()
        if sys.platform == 'win32':tb.destroy()
        PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','logon.wav'))
        self.sec = 0
        def after1():
            self.after = self.root.after(1000, after1)
            self.sec += 1
            if self.sec == 3:
                from .DE import DE
                self.root.after_cancel(self.after)
                self.root.destroy()
                DE(master=None, sizeX=self.sizeX, sizeY=self.sizeY, system=self.system)


        self.root = Frame(cursor='none')
        self.root.pack(fill=BOTH, expand=1)
        self.root['bg'] = 'black'

        self.lbl = Label(self.root, bg='black', fg='white', text='Добро пожаловать!', font=('Montserrat', 40, 'bold'))
        self.lbl.pack(expand=1)
        #self.lbl.place(relx=0.3)
        homefolder = ''
        with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'r', encoding='utf-8') as hf:
            homefolder = hf.read()
        for i in os.listdir(Path(homefolder,'!Desktop')):
            if os.path.isdir(Path(homefolder,'!Desktop',i)):
                if i[0] != '!' or i[0] != '.':
                    with open(Path(homefolder,'!Desktop',i, 'show.txt'), 'w', encoding='utf-8') as f:
                        f.write('False')
        after1()
