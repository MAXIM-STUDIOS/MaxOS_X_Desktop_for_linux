from tkinter import (
                        Frame,
                        Label,
                        Toplevel,
                        BOTH,
                        Y,
                        X,
                        NW,
                        N,
                        SW,
                        S,
                        W,
                        E,
                        NE,
                        LEFT,
                        RIGHT,
                        TOP,
                        BOTTOM,
                        Menu
                    )
from customtkinter import CTkFrame, CTkScrollableFrame
from PIL import Image, ImageTk, ImageColor
import sys
import time, datetime
from pathlib import Path
from threading import Thread
import os
import psutil
from .Shutdown import Shutdown
from .Exit import ExitUser

from .Libraries.MaxOSTkinter import CheckLabelButtonSystem, Separator, BUTTON_MENU, ListButton, WhatDialogWin, DialogWin
from .Libraries.SoundPlayer import PlaySound
from . import RunProgram



def empty(*args, **kwargs):pass

class MenuItem():
    def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
        self.side = side
        self.anchor = anchor
        self.expand = expand
        self.fill = fill
        self.padx, self.pady, self.ipadx, self.ipady = padx, pady, ipadx, ipady
        self.mainframe.pack(side=self.side,
            anchor=self.anchor,
            expand=self.expand,
            fill=self.fill,
            padx=self.padx,
            pady=self.pady,
            ipadx=self.ipadx,
            ipady=self.ipady
        )
    def __init__(self, master, text, cmdon=empty, cmdoff=empty):
        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            self.theme_after = self.mainframe.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())

            self.mainframe['bg'] = bg_color
            self.frame['bg'] = bg_color

            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)

            color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                color_rgb_activebackground[0] = 0
            else:
                color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

            if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                color_rgb_activebackground[1] = 0
            else:
                color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

            if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                color_rgb_activebackground[2] = 0
            else:
                color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

            activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])


            self.content.configure(fg_color=bg_color)
            self.content.configure(scrollbar_fg_color=bg_color)
            self.content.configure(scrollbar_button_color=bg_color)
            self.content.configure(scrollbar_button_hover_color=selectbg)



        self.mainframe = Frame(master)

        def open_(e=''):
            self.content.pack(fill=BOTH, expand=0)
            self.frame.pack(fill=BOTH, anchor=NW)
            cmdon()

        def close_(e=''):
            self.content.pack_forget()
            self.frame.pack_forget()
            cmdoff()

        self.Button = CheckLabelButtonSystem(self.mainframe, text=text, commandon=open_, commandoff=close_)
        self.Button.pack(fill=X, anchor=NW)

        self.frame = Frame(self.mainframe)

        self.content = CTkScrollableFrame(self.frame, corner_radius=0, height=150)

        theme_update()

class StartMenu():
    def start(self):
        def tb_upd():
            self.tb_upd_after = self.FrameMenu1.after(500, tb_upd)
            registry_path = ''
            tb = ''
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','registry_path.txt'), 'r', encoding='utf-8') as hf:
                registry_path = hf.read()
            with open(Path(registry_path,'SAVING','TASKBAR_CONFIG','tb_config.txt'), 'r', encoding='utf-8') as hf:
                tb = hf.read()

            if tb.lower() == 'false':
                self.FrameMenu1.pack_forget()
            else:
                self.FrameMenu1.pack(anchor=W, side=tb, padx=20, pady=0)
        tb_upd()
    def stop(self):
        self.FrameMenu1.after_cancel(self.tb_upd_after)
        self.FrameMenu1.after_cancel(self.theme_after)
        self.FrameMenu1.pack_forget()
        self.FrameMenu1.destroy()
    def __init__(self, master='', sizeX='', sizeY='', system='', DEMAIN=''):
        self.bg_ = ''
        self.fg_ = ''
        self.master = master
        self.DEMAIN = DEMAIN
        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            registry_path = ''
            self.DEMAIN = DEMAIN
            self.sizeX = sizeX
            self.sizeY = sizeY
            self.system = system
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','registry_path.txt'), 'r', encoding='utf-8') as hf:
                registry_path = hf.read()
            self.theme_after = self.FrameMenu1.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            self.FrameMenu1.configure(fg_color=bg_color)
            self.Frame['bg'] = bg_color
            self.frame['bg'] = bg_color
            self.name_sys['bg'] = bg_color
            self.name_sys['fg'] = fg_color
            self.name_sys['font'] = (font_, font_size+5)

            self.frameUser['bg'] = bg_color
            self.LabelUserIcon['bg'] = bg_color
            self.UserName['bg'] = bg_color
            self.UserName['fg'] = fg_color
            self.UserName['font'] = (font_, font_size-3)

            self.UserIcon = Image.open(Path('MaxOS','!Registry','USERS','USERS_ICONS',f"{os.path.split(registry_path)[1]}.png"))
            self.UserIcon = self.UserIcon.resize((40, 40), Image.ANTIALIAS)
            self.UserIcon = ImageTk.PhotoImage(self.UserIcon)
            self.LabelUserIcon.image = self.UserIcon
            self.LabelUserIcon['image'] = self.LabelUserIcon.image
            username = ''
            with open(Path(registry_path,'USER_NAME','user.txt'), 'r', encoding='utf-8') as usn:
                username = usn.read()
            if len(username) > 10:
                l2 = []
                for i in range(len(username)):
                    if len(l2) <= 7:
                        l2.append(username[i])

                username = ''.join(l2)+"..."
            self.UserName['text'] = username

            self.bg_ = bg_color
            self.fg_ = fg_color
            self.font_ = font_
            self.font_size = font_size

            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)

            color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                color_rgb_activebackground[0] = 0
            else:
                color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

            if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                color_rgb_activebackground[1] = 0
            else:
                color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

            if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                color_rgb_activebackground[2] = 0
            else:
                color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

            activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

            self.selectbg_ = selectbg


            self.Frame2.configure(fg_color=bg_color)
            self.Frame2.configure(scrollbar_fg_color=bg_color)
            self.Frame2.configure(scrollbar_button_color=bg_color)
            self.Frame2.configure(scrollbar_button_hover_color=selectbg)

        self.FrameMenu1 = CTkFrame(master, fg_color='#EFFBFF', corner_radius=15)

        self.Frame = Frame(self.FrameMenu1, bg='#EFFBFF')
        self.Frame.pack(fill=BOTH, expand=1, padx=10, pady=10)

        self.name_sys = Label(self.Frame, bg='#EFFBFF', text='MaxOS X', font=('Montserrat', 20), fg='black')
        self.name_sys.pack(expand=1, fill=X)

        self.frame = Frame(self.Frame, bg='#EFFBFF')
        self.frame.pack(fill=BOTH, expand=1, padx=0, pady=0)

        self.frameUser = Frame(self.frame, bg='#EFFBFF')
        self.frameUser.pack(fill=BOTH, expand=1, padx=0, pady=0, side=LEFT)

        self.UserIcon = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','UserIcon.png'))
        self.UserIcon = self.UserIcon.resize((40, 40), Image.ANTIALIAS)
        self.UserIcon = ImageTk.PhotoImage(self.UserIcon)

        def LOGOUT(e=''):
            def Ok(e=''):
                ExitUser(self.DEMAIN, self.master, self.sizeX, self.sizeY, sys.platform)
            w = WhatDialogWin(self.DEMAIN, title='Выйти', text='Вы точно хотите выйти?', textyes='Да', textno='Отмена', command=Ok, type='warning')

        self.LabelUserIcon = Label(self.frameUser, bg='#EFFBFF', cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
        self.LabelUserIcon.image = self.UserIcon
        self.LabelUserIcon['image'] = self.LabelUserIcon.image
        self.LabelUserIcon.pack(padx=2, pady=2)

        def menuusr(e):
            menu = Menu(background=self.bg_, foreground=self.fg_, relief='flat', cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur", tearoff=0, bd=0, font=(self.font_, self.font_size), activebackground=self.selectbg_, activeforeground=self.fg_)

            imagelogout = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','LOGOUT_BTN','normal.png'))
            imagelogout = imagelogout.resize((20, 20), Image.ANTIALIAS)
            imagelogout = ImageTk.PhotoImage(imagelogout)

            menu.add_command(label='Выйти', command=LOGOUT, image=imagelogout, compound=LEFT)

            menu.post(x=e.x_root, y=e.y_root)

        self.LabelUserIcon.bind('<Double-Button-1>', menuusr)

        self.UserName = Label(self.frameUser, bg='#EFFBFF', text='DKM100', font=('Montserrat', 12), fg='black')
        self.UserName.pack(padx=2, pady=2)

        Separator(self.frameUser, orient='horizontal')

        def shutdown():
            def Ok(e=''):
                Shutdown(self.DEMAIN, self.master)
                w.destroy()
            w = WhatDialogWin(self.DEMAIN, title='Выключение', text='Вы точно хотите выключить компьютер?', textyes='Да', textno='Отмена', command=Ok, type='warning')

        BUTTON_MENU(self.frameUser, path='SHUTDOWN_BTN', command=shutdown).pack(padx=3, pady=3)

        BUTTON_MENU(self.frameUser, path='RESTART_BTN', command=lambda: PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','dialogwin.wav'))).pack(padx=3, pady=3)

        BUTTON_MENU(self.frameUser, path='SLEEP_MODE_BTN', command=lambda: PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','logon.wav'))).pack(padx=3, pady=3)

        Separator(self.frame, orient='vertical')

        self.Frame2 = CTkScrollableFrame(self.frame, corner_radius=0, width=250)
        self.Frame2.pack(fill=BOTH, expand=1, padx=0, pady=0, side=LEFT)

        system_ = MenuItem(self.Frame2, text='Система')
        system_.pack(pady=5, fill=BOTH)

        self.l = []

        settings_ = ListButton(system_.content, text='Настройки', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','settings.png'), size=35, command=lambda: RunProgram.run_program(D=Path('MaxOS','!SysPrograms'), F='Settings.prog'))
        settings_.pack(fill=X)
        def menusettings(e=''):
            menu = Menu(background=self.bg_, foreground=self.fg_, relief='flat', cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur", tearoff=0, bd=0, font=(self.font_, self.font_size), activebackground=self.selectbg_, activeforeground=self.fg_)
            def add_shortcut():
                from random import randint
                homefolder = ''
                with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'r', encoding='utf-8') as hf:
                    homefolder = hf.read()
                RunProgram.run_program(D=Path('MaxOS','!SystemPrograms'), F='CreateShortcut.prog', fileopen=Path('MaxOS','!SysPrograms','Settings.prog'))
            menu.add_command(label='Создать ярлык на рабочем столе', command=add_shortcut)
            menu.post(x=e.x_root, y=e.y_root)

        settings_.bind('<Button-2>', menusettings)
        settings_.bind('<Button-3>', menusettings)
        settings_.bind('<Control-Button-1>', menusettings)

        explorer_ = ListButton(system_.content, text='Менеджер', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','FM_Icon.png'), size=35, command=lambda: RunProgram.run_program(D=Path('MaxOS','!SysPrograms'), F='MaxOS File Manager.prog'))
        explorer_.pack(fill=X)
        def menuexplorer(e=''):
            menu = Menu(background=self.bg_, foreground=self.fg_, relief='flat', cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur", tearoff=0, bd=0, font=(self.font_, self.font_size), activebackground=self.selectbg_, activeforeground=self.fg_)
            def add_shortcut():
                from random import randint
                homefolder = ''
                with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'r', encoding='utf-8') as hf:
                    homefolder = hf.read()
                RunProgram.run_program(D=Path('MaxOS','!SystemPrograms'), F='CreateShortcut.prog', fileopen=Path('MaxOS','!SysPrograms','MaxOS File Manager.prog'))
            menu.add_command(label='Создать ярлык на рабочем столе', command=add_shortcut)
            menu.post(x=e.x_root, y=e.y_root)

        explorer_.bind('<Button-2>', menuexplorer)
        explorer_.bind('<Button-3>', menuexplorer)
        explorer_.bind('<Control-Button-1>', menuexplorer)
        ListButton(system_.content, text='Информация', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','info.png'), size=35, command=lambda: RunProgram.run_program(D=Path('MaxOS','!SysPrograms'), F='Settings.prog', fileopen='information')).pack(fill=X)
        ListButton(system_.content, text='MaxDOS Shell', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','terminal.png'), size=35, command=lambda: PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','HDD Insert.wav'))).pack(fill=X)
        ListButton(system_.content, text='Выключение', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','SHUTDOWN_BTN','normal.png'), size=35, command=shutdown).pack(fill=X)
        ListButton(system_.content, text='Перезагрузка', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','RESTART_BTN','normal.png'), size=35, command=lambda: PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','dialogwin.wav'))).pack(fill=X)
        ListButton(system_.content, text='Режим сна', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','SLEEP_MODE_BTN','normal.png'), size=35, command=lambda: PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','logon.wav'))).pack(fill=X)
        ListButton(system_.content, text='Выйти', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','LOGOUT_BTN','normal.png'), size=35, command=LOGOUT).pack(fill=X)

        self.hddmenu = ''
        def openhdd(e=''):
            self.hddmenu = HddsMenu(mastertk=hdds.content)
            self.hddmenu.pack(fill=X)
        def closehdd(e=''):
            self.hddmenu.destroy()
            self.hddmenu = ''

        class HddsMenu():
            def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
                self.side = side
                self.anchor = anchor
                self.expand = expand
                self.fill = fill
                self.padx, self.pady, self.ipadx, self.ipady = padx, pady, ipadx, ipady
                self.Frame.pack(side=self.side,
                    anchor=self.anchor,
                    expand=self.expand,
                    fill=self.fill,
                    padx=self.padx,
                    pady=self.pady,
                    ipadx=self.ipadx,
                    ipady=self.ipady
                )
            def destroy(self):
                self.Frame.after_cancel(self.theme_after)
                self.Frame.after_cancel(self.global_after)
                self.Frame.destroy()
            def __init__(self, mastertk):
                def theme_update():
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())
                    self.theme_after = self.Frame.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    self.Frame['bg'] = bg_color

                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)

                    self.fg_ = fg_color
                    self.bg_ = bg_color
                    self.font_ = font_
                    self.font_size = font_size

                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

                    self.selectbg_ = selectbg

                class AddBTN():
                    def destroy(self):
                        self.btn.destroy()
                    def __init__(self, master, name, path, hdd_info, bg, fg, font, font_size, selectbg):
                        self.name = name
                        self.path = path
                        self.bg_ = bg
                        self.fg_ = fg
                        self.font_ = font
                        self.font_size = font_size
                        self.selectbg_ = selectbg
                        if self.name == '':
                            self.name = 'Macintosh HD'

                        def cmd(e=''):
                            if sys.platform == 'win32':
                                RunProgram.run_program(D=Path('MaxOS','!SysPrograms'), F='MaxOS File Manager.prog', fileopen=f"{self.name}\\")
                            elif sys.platform == 'darwin':
                                RunProgram.run_program(D=Path('MaxOS','!SysPrograms'), F='MaxOS File Manager.prog', fileopen=self.path)
                        if 'cdrom' in hdd_info.opts or 'ro' in hdd_info.opts.split(',') and self.name != 'Macintosh HD':
                            self.btn = ListButton(master, text=self.name, image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','cd_dvd.png'), size=35, command=cmd)
                            self.btn.pack(fill=X)
                            if sys.platform == 'win32':
                                def eject(e=''):
                                    def open_disk():
                                        import ctypes
                                        ctypes.windll.WINMM.mciSendStringW(u"set cdaudio door open", None, 0, None)
                                    menu = Menu(background=self.bg_, foreground=self.fg_, relief='flat', cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur", tearoff=0, bd=0, font=(self.font_, self.font_size), activebackground=self.selectbg_, activeforeground=self.fg_)
                                    menu.add_command(label='Открыть лоток дисковода', command=open_disk)
                                    menu.post(x=e.x_root, y=e.y_root)
                                self.btn.bind('<Button-3>', eject)
                                self.btn.bind('<Control-Button-1>', eject)
                        else:
                            self.btn = ListButton(master, text=self.name, image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','HDD_ICONS','sys_hdd.png'), size=35, command=cmd)
                            self.btn.pack(fill=X)

                        def menubtn(e):
                            menu = Menu(tearoff=0)
                            def eject():
                                os.system(f"diskutil eject {Path(self.path)}")
                                PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','HDD Out.wav'))
                                self.btn.destroy()
                            menu.add_command(label='Извлечь', command=eject)
                            menu.post(x=e.x_root, y=e.y_root)
                        if sys.platform == 'darwin':
                            if self.name != 'Macintosh HD':
                                self.btn.bind('<Button-2>', menubtn)
                                self.btn.bind('<Control-Button-1>', menubtn)

                def GlobalUpdate():
                    self.global_after = self.Frame.after(100, GlobalUpdate)
                    def check_disks(e=''):
                        disklist1 = []
                        for i in psutil.disk_partitions():
                            disklist1.append(i.device)
                        time.sleep(0.1)
                        disklist2 = []
                        for i in psutil.disk_partitions():
                            disklist2.append(i.device)

                        if len(disklist2) > len(disklist1):
                            for w in self.Frame.winfo_children():
                                w.destroy()
                            for i in psutil.disk_partitions():
                                if sys.platform == 'darwin':AddBTN(self.Frame, os.path.split(i.mountpoint)[-1], path=i.mountpoint, hdd_info=i, bg=self.bg_, fg=self.fg_, font=self.font_, font_size=self.font_size, selectbg=self.selectbg_)
                                elif sys.platform == 'win32':AddBTN(self.Frame, i.mountpoint, path=i.mountpoint, hdd_info=i, bg=self.bg_, fg=self.fg_, font=self.font_, font_size=self.font_size, selectbg=self.selectbg_)
                        elif len(disklist2) < len(disklist1):
                            for w in self.Frame.winfo_children():
                                w.destroy()
                            for i in psutil.disk_partitions():
                                if sys.platform == 'darwin':AddBTN(self.Frame, os.path.split(i.mountpoint)[-1], path=i.mountpoint, hdd_info=i, bg=self.bg_, fg=self.fg_, font=self.font_, font_size=self.font_size, selectbg=self.selectbg_)
                                elif sys.platform == 'win32':AddBTN(self.Frame, i.mountpoint, path=i.mountpoint, hdd_info=i, bg=self.bg_, fg=self.fg_, font=self.font_, font_size=self.font_size, selectbg=self.selectbg_)
                    Thread(target=check_disks, daemon=1).start()
                homefolder = ''
                with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'r', encoding='utf-8') as f:
                    homefolder = f.read()

                self.Frame = Frame(mastertk)

                theme_update()

                for i in psutil.disk_partitions():
                    if sys.platform == 'darwin':AddBTN(self.Frame, os.path.split(i.mountpoint)[-1], path=i.mountpoint, hdd_info=i, bg=self.bg_, fg=self.fg_, font=self.font_, font_size=self.font_size, selectbg=self.selectbg_)
                    elif sys.platform == 'win32':AddBTN(self.Frame, i.mountpoint, path=i.mountpoint, hdd_info=i, bg=self.bg_, fg=self.fg_, font=self.font_, font_size=self.font_size, selectbg=self.selectbg_)

                GlobalUpdate()
        hdds = MenuItem(self.Frame2, text='Локальные диски', cmdon=openhdd, cmdoff=closehdd)
        hdds.pack(pady=5, fill=BOTH)

        self.progmenu = ''
        def openprog(e=''):
            self.progmenu = ProgramsMenu(mastertk=prog.content)
            self.progmenu.pack(fill=X)
        def closeprog(e=''):
            self.progmenu.destroy()
            self.progmenu = ''

        class ProgramsMenu():
            def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
                self.side = side
                self.anchor = anchor
                self.expand = expand
                self.fill = fill
                self.padx, self.pady, self.ipadx, self.ipady = padx, pady, ipadx, ipady
                self.Frame.pack(side=self.side,
                    anchor=self.anchor,
                    expand=self.expand,
                    fill=self.fill,
                    padx=self.padx,
                    pady=self.pady,
                    ipadx=self.ipadx,
                    ipady=self.ipady
                )
            def destroy(self):
                self.Frame.after_cancel(self.theme_after)
                self.Frame.destroy()
            def __init__(self, mastertk):
                def theme_update():
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())
                    self.theme_after = self.Frame.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    self.Frame['bg'] = bg_color

                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)

                    self.fg_ = fg_color
                    self.bg_ = bg_color
                    self.font_ = font_
                    self.font_size = font_size

                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

                    self.selectbg_ = selectbg

                homefolder = ''
                with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'r', encoding='utf-8') as f:
                    homefolder = f.read()

                self.Frame = Frame(mastertk)

                theme_update()

                class AddBTN():
                    def __init__(self, master, name, path, bg, fg, font, font_size, selectbg):
                        self.name = name
                        self.path = path
                        self.bg_ = bg
                        self.fg_ = fg
                        self.font_ = font
                        self.font_size = font_size
                        self.selectbg_ = selectbg
                        def menuprog(e=''):
                            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                                bg_color = bg.read()
                            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                                fg_color = fg.read()
                            menu = Menu(background=self.bg_, foreground=self.fg_, relief='flat', cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur", tearoff=0, bd=0, font=(self.font_, self.font_size), activebackground=self.selectbg_, activeforeground=self.fg_)
                            def add_shortcut():
                                from random import randint
                                homefolder = ''
                                with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'r', encoding='utf-8') as hf:
                                    homefolder = hf.read()
                                RunProgram.run_program(D=Path('MaxOS','!SystemPrograms'), F='CreateShortcut.prog', fileopen=Path(self.path))
                            menu.add_command(label='Создать ярлык на рабочем столе', command=add_shortcut)
                            menu.post(x=e.x_root, y=e.y_root)


                        text = ''
                        with open(Path(self.path,'name.txt'), 'r', encoding='utf-8') as f:
                            text = f.read()

                        text = ''
                        with open(Path(self.path,'name.txt'), 'r', encoding='utf-8') as f:
                            text = f.read()

                        if len(text) > 15:
                            text2 = []
                            for i in range(len(text)):
                                if i <= 12:
                                    text2.append(text[i])

                            text2 = ''.join(text2)
                            text2 = f"{text2}..."
                        else:
                            text2 = text

                        self.prog = ListButton(master, text=text2, image=Path(path, 'icon.png'), size=35, command=lambda: RunProgram.run_program(D=os.path.split(self.path)[0], F=self.name))
                        self.prog.pack(fill=X)

                        self.prog.bind('<Button-2>', menuprog)
                        self.prog.bind('<Button-3>', menuprog)
                        self.prog.bind('<Control-Button-1>', menuprog)

                for i in os.listdir(Path(homefolder,'Programs')):
                    if i[0] in ['!','.']:pass
                    else:
                        if os.path.splitext(i)[1].lower() == '.prog' or os.path.splitext(i)[1].lower() == '.prg':
                            AddBTN(self.Frame, i, path=Path(homefolder,'Programs',i), bg=self.bg_, fg=self.fg_, font=self.font_, font_size=self.font_size, selectbg=self.selectbg_)

        prog = MenuItem(self.Frame2, text='Программы', cmdon=openprog, cmdoff=closeprog)
        prog.pack(pady=5, fill=BOTH)


        self.sysprogmenu = ''
        def opensysprog(e=''):
            self.sysprogmenu = SysProgramsMenu(mastertk=sysprog.content)
            self.sysprogmenu.pack(fill=X)
        def closesysprog(e=''):
            self.sysprogmenu.destroy()
            self.sysprogmenu = ''

        class SysProgramsMenu():
            def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
                self.side = side
                self.anchor = anchor
                self.expand = expand
                self.fill = fill
                self.padx, self.pady, self.ipadx, self.ipady = padx, pady, ipadx, ipady
                self.Frame.pack(side=self.side,
                    anchor=self.anchor,
                    expand=self.expand,
                    fill=self.fill,
                    padx=self.padx,
                    pady=self.pady,
                    ipadx=self.ipadx,
                    ipady=self.ipady
                )
            def destroy(self):
                self.Frame.after_cancel(self.theme_after)
                self.Frame.destroy()
            def __init__(self, mastertk):
                def theme_update():
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())
                    self.theme_after = self.Frame.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    self.Frame['bg'] = bg_color

                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)

                    self.fg_ = fg_color
                    self.bg_ = bg_color
                    self.font_ = font_
                    self.font_size = font_size

                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

                    self.selectbg_ = selectbg

                homefolder = ''
                with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'r', encoding='utf-8') as f:
                    homefolder = f.read()

                self.Frame = Frame(mastertk)

                theme_update()

                class AddBTN():
                    def __init__(self, master, name, path, bg, fg, font, font_size, selectbg):
                        self.name = name
                        self.path = path
                        self.bg_ = bg
                        self.fg_ = fg
                        self.font_ = font
                        self.font_size = font_size
                        self.selectbg_ = selectbg
                        def menuprog(e=''):
                            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                                bg_color = bg.read()
                            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                                fg_color = fg.read()
                            menu = Menu(background=self.bg_, foreground=self.fg_, relief='flat', cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur", tearoff=0, bd=0, font=(self.font_, self.font_size), activebackground=self.selectbg_, activeforeground=self.fg_)
                            def add_shortcut():
                                from random import randint
                                homefolder = ''
                                with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'r', encoding='utf-8') as hf:
                                    homefolder = hf.read()
                                RunProgram.run_program(D=Path('MaxOS','!SystemPrograms'), F='CreateShortcut.prog', fileopen=Path(self.path))
                            menu.add_command(label='Создать ярлык на рабочем столе', command=add_shortcut)
                            menu.post(x=e.x_root, y=e.y_root)


                        text = ''
                        with open(Path(self.path,'name.txt'), 'r', encoding='utf-8') as f:
                            text = f.read()

                        if len(text) > 15:
                            text2 = []
                            for i in range(len(text)):
                                if i <= 12:
                                    text2.append(text[i])

                            text2 = ''.join(text2)
                            text2 = f"{text2}..."
                        else:
                            text2 = text


                        self.prog = ListButton(master, text=text2, image=Path(path, 'icon.png'), size=35, command=lambda: RunProgram.run_program(D=os.path.split(self.path)[0], F=self.name))
                        self.prog.pack(fill=X)

                        self.prog.bind('<Button-2>', menuprog)
                        self.prog.bind('<Button-3>', menuprog)
                        self.prog.bind('<Control-Button-1>', menuprog)

                for i in os.listdir(Path('MaxOS','!SysPrograms')):
                    if i[0] in ['!','.']:pass
                    else:
                        if os.path.splitext(i)[1].lower() == '.prog' or os.path.splitext(i)[1].lower() == '.prg':
                            AddBTN(self.Frame, i, path=Path('MaxOS','!SysPrograms',i), bg=self.bg_, fg=self.fg_, font=self.font_, font_size=self.font_size, selectbg=self.selectbg_)

        sysprog = MenuItem(self.Frame2, text='Системные\nпрограммы', cmdon=opensysprog, cmdoff=closesysprog)
        sysprog.pack(pady=5, fill=BOTH)

        MenuItem(self.Frame2, text='Игры').pack(pady=5, fill=BOTH)
        MenuItem(self.Frame2, text='Изображения').pack(pady=5, fill=BOTH)
        MenuItem(self.Frame2, text='Виджеты').pack(pady=5, fill=BOTH)
        Separator(self.Frame2, orient='horizontal')
        MenuItem(self.Frame2, text='Недавние\nпрограммы').pack(pady=5, fill=BOTH)
        MenuItem(self.Frame2, text='Поиск').pack(pady=5, fill=BOTH)

        theme_update()
