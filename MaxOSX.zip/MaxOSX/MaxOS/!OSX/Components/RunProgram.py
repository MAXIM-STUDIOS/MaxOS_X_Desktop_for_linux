import os
import sys
from pathlib import Path
from threading import Thread
import time
from random import randint
import shutil

from .Libraries.MaxOSCode16 import ConvertFromMaxOSCode16, ConvertToMaxOSCode16

def run_program(D, F, fileopen=''):
    def runprog():
        if os.path.exists(Path(D,F,'program.msc16')):
            envdir = {}
            file = Path(D,F,'program.msc16')
            open_python_file = open(file, 'r', encoding='utf-8')
            r = randint(0, 10000)
            open_python_file2 = open_python_file.read()
            open_python_file.close()
            cwd = Path(D,F)
            exec(f"""
cwd = r'{cwd}'
fileopen = r'{fileopen}'
import sys
sys.path.append('{Path('MaxOS','!OSX','Components','Libraries')}')
{ConverFromMaxOSCode16(open_python_file2)}

            """, envdir)
        elif os.path.exists(Path(D,F,'program.py')):
            envdir = {}
            file = Path(D,F,'program.py')
            open_python_file = open(file, 'r', encoding='utf-8')
            r = randint(0, 10000)
            open_python_file2 = open_python_file.read()
            open_python_file.close()
            cwd = Path(D,F)
            exec(f"""
cwd = r'{cwd}'
fileopen = r'{fileopen}'
import sys
sys.path.append('{Path('MaxOS','!OSX','Components','Libraries')}')
{open_python_file2}

            """, envdir)
    runprog()
