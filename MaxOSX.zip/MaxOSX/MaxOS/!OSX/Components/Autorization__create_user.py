from .Libraries.MaxOSTkinter import (
                            MaxOSTk,
                            DialogWin,
                            WhatDialogWin,
                            LabelButtonSystem,
                            ListButton,
                            Separator,
                            empty,
                            ColorDialogWin,
                            MaxOSTk2,
                            EntryAuto,
                            WebCamDialogWin,
                            BUTTON_MENU,
                            DialogWinCustom
                        )
from tkinter import (
                        Frame,
                        Label,
                        Toplevel,
                        BOTH,
                        Y,
                        X,
                        NW,
                        N,
                        SW,
                        S,
                        W,
                        E,
                        NE,
                        LEFT,
                        RIGHT,
                        TOP,
                        BOTTOM,
                        Menu,
                        font,
                        Text,
                        END
                    )
import os
import sys
import shutil
from pathlib import Path
from threading import Thread
from customtkinter import CTkLabel, CTkFrame, CTkComboBox, CTkSlider, CTkScrollableFrame
from PIL import Image, ImageTk, ImageColor
import psutil
from .Libraries.SoundPlayer import PlaySound
from .Libraries.MaxOSCode import ConvertToMaxOSCode, ConverFromMaxOSCode
from .Libraries.Avatar import avatar
from .DE import DE
from .Enter import EnterUser
from .Libraries.Avatar import avatar

def write_file(file, text):
    o = open(file, 'w', encoding='utf-8')
    o.write(str(text))
    o.close()

def read_file(file):
    o = open(file, 'r', encoding='utf-8')
    text = o.read()
    o.close()
    return text

def create_user_func(username, password, homefolder, user_icon, desktop_image, theme=('#333533','#ffffff'), tb_config='top', font_=('Montserrat', '15')):
    listsimbols = ['!','\\','.',',','|',':',';','/','{','}','(',')','@','#','$','%','^','&','*','=','+','\'','"',' ','[',']','<','>']
    l1 = list(homefolder)
    for i in listsimbols:
        if i in l1:
            l1.remove(i)
    homefolder = ''.join(l1)

    path_users = Path('Users',homefolder.lower())
    list_user_folders = ['!Desktop','Files','Programs','Games','Images','Sounds','Screenshots']
    path_reg_users = Path('MaxOS','!Registry','USERS','LIST_USERS',homefolder.upper())
    list_reg_user_folders = [
        'PROGRAMS',
        'PASSWORD',
        'SAVING',
            Path('SAVING','DESKTOP_CONFIG'),
                Path('SAVING','DESKTOP_CONFIG','LIST_DESKTOP_IMAGE'),
                Path('SAVING','DESKTOP_CONFIG','DESKTOPS_IMAGES'),
            Path('SAVING','SYSTEM_THEME'),
                Path('SAVING','SYSTEM_THEME','CUSTOM_THEMES'),
                Path('SAVING','SYSTEM_THEME','COLORS'),
                Path('SAVING','SYSTEM_THEME','FONTS'),
            Path('SAVING','TASKBAR_CONFIG'),
            Path('SAVING','USER_ICON'),
                Path('SAVING','USER_ICON','LIST_USER_ICONS'),
        'TRASH',
        'USER_NAME'
    ]

    os.mkdir(path_users)

    for i in list_user_folders:
        os.mkdir(Path(path_users, i))

    os.mkdir(Path(path_users,'!Desktop','homefolder_12345.shrt'))
    write_file(file=Path(path_users,'!Desktop','homefolder_12345.shrt','coords.txt'),text='35 96')
    write_file(file=Path(path_users,'!Desktop','homefolder_12345.shrt','link.txt'),text=path_users)
    write_file(file=Path(path_users,'!Desktop','homefolder_12345.shrt','name.txt'),text='Домашняя папка')
    write_file(file=Path(path_users,'!Desktop','homefolder_12345.shrt','show.txt'),text='False')


    os.mkdir(path_reg_users)

    for i in list_reg_user_folders:
        os.mkdir(Path(path_reg_users, i))

    write_file(file=Path(path_reg_users,'PASSWORD','password.txt'),text=ConvertToMaxOSCode(password))
    write_file(file=Path(path_reg_users,'USER_NAME','user.txt'),text=username)

    write_file(file=Path(path_reg_users,'SAVING','DESKTOP_CONFIG','bg_desktop.txt'),text='#000000')
    write_file(file=Path(path_reg_users,'SAVING','DESKTOP_CONFIG','image_desktop_change.txt'),text='False')
    write_file(file=Path(path_reg_users,'SAVING','DESKTOP_CONFIG','image_desktop.txt'),text='True')
    if sys.platform == 'darwin':
        default_desktop = desktop_image
    elif sys.platform == 'win32':
        default_desktop = desktop_image.replace('\\', '/')
    write_file(file=Path(path_reg_users,'SAVING','DESKTOP_CONFIG','default_desktop.txt'),text=default_desktop)

    write_file(file=Path(path_reg_users,'SAVING','SYSTEM_THEME','COLORS','bg_tb.txt'),text=theme[0])
    write_file(file=Path(path_reg_users,'SAVING','SYSTEM_THEME','COLORS','fg_tb.txt'),text=theme[1])

    if theme != (('#333533','#ffffff'), ('#effbff','#000000'), ('#28749b', '#ffffff')):
        write_file(file=Path(path_reg_users,'SAVING','SYSTEM_THEME','CUSTOM_THEMES',f"{theme[0].replace('#','')}_{theme[1].replace('#','')}.xtheme"),text=f"{theme[0]} {theme[1]}")
    write_file(file=Path(path_reg_users,'SAVING','SYSTEM_THEME','CUSTOM_THEMES',f"333533_ffffff.xtheme"),text=f"#333533 #ffffff")
    write_file(file=Path(path_reg_users,'SAVING','SYSTEM_THEME','CUSTOM_THEMES',f"effbff_000000.xtheme"),text=f"#effbff #000000")
    write_file(file=Path(path_reg_users,'SAVING','SYSTEM_THEME','CUSTOM_THEMES',f"28749b_ffffff.xtheme"),text=f"#28749b #ffffff")

    if sys.platform == 'win32':pass#write_file(file=Path(path_reg_users,'SAVING','SYSTEM_THEME','FONTS','standart_font_size.txt'),text='10')
    elif sys.platform == 'darwin':pass#write_file(file=Path(path_reg_users,'SAVING','SYSTEM_THEME','FONTS','standart_font_size.txt'),text='15')
    write_file(file=Path(path_reg_users,'SAVING','SYSTEM_THEME','FONTS','standart_font_size.txt'),text=font_[1])
    write_file(file=Path(path_reg_users,'SAVING','SYSTEM_THEME','FONTS','standart_font.txt'),text=font_[0])

    write_file(file=Path(path_reg_users,'SAVING','SYSTEM_THEME','change_theme.txt'),text='False')

    write_file(file=Path(path_reg_users,'SAVING','TASKBAR_CONFIG','tb_config.txt'),text=tb_config)

    shutil.copy(user_icon, Path(path_reg_users,'SAVING','USER_ICON','UserIcon.png'))
    shutil.copy(desktop_image, Path(path_reg_users,'SAVING','DESKTOP_CONFIG','ImageDesktop.png'))
    avatar(user_icon, Path('MaxOS','!Registry','USERS','USERS_ICONS',f"{homefolder.upper()}.png"))

    list_icons = os.listdir(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS'))

    for i in list_icons:
        shutil.copy(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS',i), Path(path_reg_users,'SAVING','USER_ICON','LIST_USER_ICONS',i))

    shutil.copy(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image1.png'), Path(path_reg_users,'SAVING','DESKTOP_CONFIG','DESKTOPS_IMAGES','image1.png'))
    shutil.copy(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image2.png'), Path(path_reg_users,'SAVING','DESKTOP_CONFIG','DESKTOPS_IMAGES','image2.png'))
    shutil.copy(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image3.png'), Path(path_reg_users,'SAVING','DESKTOP_CONFIG','DESKTOPS_IMAGES','image3.png'))

class create_user():
    def destroy(self):
        self.a = 0.95
        def exiting(event=None):
            after_exit = self.root.after(10, exiting)
            if self.a < 0:
                self.root1.after_cancel(after_exit)
                self.root.destroy()
            self.a -= 0.05
            try:
                self.root.wm_attributes('-alpha', self.a)
            except Exception:
                pass
        exiting()
    def __init__(self, master=None, title='Создать пользователя', command=None, root='', sizeX='', sizeY='', system='', destroycmd1='', destroycmd2='', users_list=''):
        PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','dialogwin.wav'))
        self.master = master
        self.title = title
        self.command = command
        self.root = root
        self.sizeX = sizeX
        self.sizeY = sizeY
        self.system = system
        self.destroycmd1 = destroycmd1
        self.destroycmd2 = destroycmd2
        self.users_list = users_list
        bg_tb = ''
        fg_tb = ''
        fontMaxOS = ''
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg1:
            bg_tb = bg1.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg1:
            fg_tb = fg1.read()
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f1:
            fontMaxOS = f1.read()


        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0

            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            self.theme_after = self.root1.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            self.root0.configure(fg_color=bg_color)
            self.root1['bg'] = bg_color
            self.title2['bg'] = bg_color
            self.title2['fg'] = fg_color
            self.title2['font'] = (font_, font_size)
            self.passlab['bg'] = bg_color
            self.entrypassfr['bg'] = bg_color
            self.passlab2['bg'] = bg_color
            self.entryhffr['bg'] = bg_color
            self.entrynamefr['bg'] = bg_color

            self.homefolderlab['bg'] = bg_color
            self.namelab['bg'] = bg_color

            self.passlab['fg'] = fg_color
            self.passlab2['fg'] = fg_color

            self.homefolderlab['fg'] = fg_color
            self.namelab['fg'] = fg_color



            self.passlab['font'] = (font_, font_size)
            self.passlab2['font'] = (font_, font_size)

            self.homefolderlab['font'] = (font_, font_size)
            self.namelab['font'] = (font_, font_size)

            self.title2['fg'] = fg_color
            self.title2['font'] = (font_, font_size)

            self.steps['bg'] = bg_color
            self.steps['fg'] = fg_color
            self.steps['font'] = (font_, font_size+5, 'bold')

            self.frame_icons['bg'] = bg_color
            self.icon1['bg'] = bg_color
            self.icon2['bg'] = bg_color
            self.icon3['bg'] = bg_color
            self.icon4['bg'] = bg_color
            self.icon5['bg'] = bg_color

            self.step1['bg'] = bg_color
            self.step2['bg'] = bg_color
            self.step3['bg'] = bg_color
            self.step4['bg'] = bg_color
            self.step5['bg'] = bg_color

            self.icondesktop1['bg'] = bg_color
            self.icondesktop2['bg'] = bg_color
            self.icondesktop3['bg'] = bg_color

            self.icontb1['bg'] = bg_color
            self.icontb2['bg'] = bg_color


            self.lab1['bg'] = bg_color
            self.lab1['fg'] = fg_color
            self.lab1['font'] = (font_, font_size+2, 'bold')

            self.lab2['bg'] = bg_color
            self.lab2['fg'] = fg_color
            self.lab2['font'] = (font_, font_size+2, 'bold')

            self.icontheme1['bg'] = '#3d3f3d'
            self.icontheme2['bg'] = '#3d3f3d'
            self.icontheme3['bg'] = '#3d3f3d'
            self.icontheme4['bg'] = '#3d3f3d'

            self.lab_font_['bg'] = bg_color
            self.lab_font_['fg'] = fg_color
            self.lab_font_['font'] = (font_, font_size)

            self.lab_font['bg'] = bg_color
            self.lab_font['fg'] = fg_color
            try:self.lab_font['font'] = (font_, int(self.entry_font.get()))
            except:
                if self.entry_font.get() == '':
                    pass
                else:
                    self.entry_font.delete(0, END)
                    self.entry_font.insert(END, '15')

            self.frame_entry['bg'] = bg_color
            self.fonts['bg'] = bg_color

            self.step6['bg'] = bg_color

        def GlobalUpdate():
            self.global_after = self.root.after(100, GlobalUpdate)
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','exit_user.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.root.destroy()
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','sleep_mode.txt',), 'r', encoding='utf-8') as f:
                text = f.read().lower()
                if text == 'true':
                    self.root.withdraw()
                elif text == 'false':
                    self.root.deiconify()

        self.root = Toplevel(self.master)
        self.root.minsize(750, 500)
        self.root.maxsize(750, 500)
        self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        self.a = 0
        def showing(event=None):
            after_show = self.root.after(10, showing)
            x = (self.root.winfo_screenwidth() - self.root.winfo_reqwidth()) / 2
            y = (self.root.winfo_screenheight() - self.root.winfo_reqheight()) / 2
            self.root.geometry("+%d+%d" % (x, y))
            if self.a > 0.9:
                self.root.after_cancel(after_show)
            self.a += 0.05
            self.root.wm_attributes('-alpha', self.a)
        def passDEF(event=None):pass
        self.root.protocol('WM_DELETE_WINDOW', passDEF)
        self.root.wm_attributes('-alpha', 0.95)
        self.root.resizable(0,0)

        def startMove(event):
            global x, y
            x = event.x
            y = event.y
            if sys.platform == 'darwin':self.root.overrideredirect(1)
            if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        def stopMove(event):
            global x, y
            x = None
            y = None
            if sys.platform == 'darwin':self.root.overrideredirect(0)
            if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        def moving(event):
            global x, y
            x_ = (event.x_root - x)
            y_ = (event.y_root - y)
            self.root.geometry("+%s+%s" % (x_, y_))
            if sys.platform == 'darwin':self.root.overrideredirect(1)
            if sys.platform == 'darwin':self.root.resizable(0,0)
            self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"

        if system == 'darwin':
            self.root.wm_attributes("-transparent", True)
            self.root.config(bg='systemTransparent')
        elif system == 'win32':
            self.root.wm_attributes("-transparentcolor", '#123456')
            self.root['bg'] = '#123456'
        self.root['bd'] = 7


        self.root0 = CTkFrame(self.root, fg_color=bg_tb, corner_radius=15)
        self.root0.pack(expand=1, fill=BOTH)

        self.root1 = Frame(self.root0, bg=bg_tb)
        self.root1.pack(fill=BOTH, expand=1, padx=10, pady=10)

        self.root.wm_attributes('-topmost', 1)
        if sys.platform == 'win32':
            self.root.wm_overrideredirect(True)
        elif sys.platform == 'darwin':
            self.root.wm_overrideredirect(False)
        self.root.wm_attributes('-topmost', 1)
        self.title2 = Label(self.root1, bg=bg_tb, fg=fg_tb, text=self.title, font=(fontMaxOS, 15))
        self.title2.pack(anchor=NW, fill=X)
        self.title2.bind("<Button-1>", startMove)
        self.title2.bind("<ButtonRelease-1>", stopMove)
        self.title2.bind("<B1-Motion>", moving)

        self.steps = Label(self.root1, text='Шаг 1. Информация о пользователе', justify='left')
        self.steps.pack(anchor=NW)

        self.step1 = Frame(self.root1, bg=bg_tb, bd=7)
        self.step1.pack(anchor=NW, fill=BOTH, expand=1)

        self.entryhffr = Frame(self.step1, bg=bg_tb)
        self.entryhffr.pack(anchor=NW, expand=0, fill=X, pady=5, padx=5)

        self.homefolderlab = Label(self.entryhffr, bg=bg_tb, fg=fg_tb, text='Домашняя папка:', font=(fontMaxOS, 15))
        self.homefolderlab.pack(fill=Y, side=LEFT)
        self.entryhf = EntryAuto(self.entryhffr, bg=bg_tb, fg=fg_tb, placeholder='placeholder')
        self.entryhf.pack(fill=BOTH, side=LEFT, expand=1)

        self.entrynamefr = Frame(self.step1, bg=bg_tb)
        self.entrynamefr.pack(anchor=NW, expand=0, fill=X, pady=5, padx=5)

        self.namelab = Label(self.entrynamefr, bg=bg_tb, fg=fg_tb, text='Имя:', font=(fontMaxOS, 15))
        self.namelab.pack(fill=Y, side=LEFT)
        self.entryname = EntryAuto(self.entrynamefr, bg=bg_tb, fg=fg_tb, placeholder='placeholder')
        self.entryname.pack(fill=BOTH, side=LEFT, expand=1)


        self.entrypassfr = Frame(self.step1, bg=bg_tb)
        self.entrypassfr.pack(anchor=NW, expand=0, fill=X, pady=5, padx=5)

        self.passlab = Label(self.entrypassfr, bg=bg_tb, fg=fg_tb, text='Пароль:', font=(fontMaxOS, 15))
        self.passlab.pack(fill=Y, side=LEFT)
        self.entrypass = EntryAuto(self.entrypassfr, bg=bg_tb, fg=fg_tb, placeholder='password')
        self.entrypass.pack(fill=BOTH, side=LEFT, expand=1)

        self.passlab2 = Label(self.entrypassfr, bg=bg_tb, fg=fg_tb, text='Повторите пароль:', font=(fontMaxOS, 15))
        self.passlab2.pack(fill=Y, side=LEFT)
        self.entrypass2 = EntryAuto(self.entrypassfr, bg=bg_tb, fg=fg_tb, placeholder='password')
        self.entrypass2.pack(fill=BOTH, side=LEFT, expand=1)

        def OK(e=''):
            username = self.entryname.get()
            userpassword = self.entrypass.get()
            userpassword2 = self.entrypass2.get()
            homefolder = self.entryhf.get()

            #listsimbols = ['!','\\','.',',','|',':',';','/','{','}','(',')','@','#','$','%','^','&','*','=','+','\'','"',' ','[',']','<','>']
            #l1 = list(homefolder)
            #for i in listsimbols:
            #    if i in l1:
            #        l1.remove(i)

            #homefolder = ''.join(l1)

            if username != '' and userpassword != '' and self.entryhf.get() != '' and userpassword2 != '':
                if username in self.users_list:
                    DialogWin(self.root, title='Ошибка', text='Шаг 1\nПользователь с таким именем уже существует', type='error', global_update=0)
                else:
                    if os.path.isdir(Path('Users',homefolder)):
                        DialogWin(self.root, title='Ошибка', text='Шаг 1\nДомашняя папка с таким именем уже существует', type='error', global_update=0)
                    if userpassword == userpassword2:
                        if len(username) > 20:
                            DialogWin(self.root, title='Ошибка', text='Шаг 1\nИмя пользователя может содержать максимум 20 символов', type='error', global_update=0)
                        else:
                            if len(username) < 3:
                                DialogWin(self.root, title='Ошибка', text='Шаг 1\nИмя пользователя может содержать минимум 3 символа', type='error', global_update=0)
                            else:
                                if self.entry_font.get() == '':
                                    DialogWin(self.root, title='Ошибка', text='Шаг 5\nОшибка в размере шрифта', type='error', global_update=0)
                                else:
                                    create_user_func(username=username, password=userpassword, homefolder=homefolder, user_icon=self.user_icon, desktop_image=self.user_icondesktop, theme=self.user_icontheme, tb_config=self.tb_config, font_=('Montserrat', self.entry_font.get()))
                                    open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','password.txt'), 'w', encoding='utf-8').write(ConvertToMaxOSCode(userpassword))
                                    open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','user.txt'), 'w', encoding='utf-8').write(username)
                                    open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'w', encoding='utf-8').write(str(Path('Users',homefolder)))
                                    open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','registry_path.txt'), 'w', encoding='utf-8').write(str(Path('MaxOS','!Registry','USERS','LIST_USERS',homefolder.upper())))
                                    de = EnterUser(self.master, self.destroycmd1, self.sizeX, self.sizeY, sys.platform)
                        #Thread(target=lambda: sleep3(username, userpassword, userpassword2, homefolder), daemon=1).start()
                    else:
                        DialogWin(self.root, title='Ошибка', text='Шаг 1\nПароли не совпадают', type='error', global_update=0)
            else:
                DialogWin(self.root, title='Ошибка', text='Шаг 1\nНе все поля заполнены', type='error', global_update=0)

        def OK1(e=''):
            self.steps['text'] = 'Шаг 2. Аватарка пользователя'
            self.step1.pack_forget()
            self.step2.pack(anchor=NW, fill=BOTH, expand=1)

        self.okbtn = LabelButtonSystem(self.step1, font=(fontMaxOS, 15), text=' Далее ', width=15, bg=bg_tb, command=OK1)
        self.okbtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        self.closebtn = LabelButtonSystem(self.step1, font=(fontMaxOS, 15), text=(' '+'Отмена'+' '), width=15, bg=bg_tb, command=self.destroy)
        self.closebtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)


        self.step2 = Frame(self.root1, bg=bg_tb, bd=7)

        self.frame_icons = Frame(self.step2)
        self.frame_icons.pack(anchor=NW)

        self.icon_position = 0
        self.user_icon = str(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','UserIcon.png'))
        self.custom_user_icon = str(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','NoImage.png'))

        def check_position_icon():
            if self.icon_position == 0:
                self.user_icon = str(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','UserIcon.png'))

                self.icon1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','UserIcon.png'))
                self.icon1_ = self.icon1_.resize((100, 100), Image.ANTIALIAS)
                self.icon1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icon1_ = ImageTk.PhotoImage(self.icon1_)
                self.ACTIVE_icon1_STATE = 1
                self.icon1.image = self.icon1_
                self.icon1['image'] = self.icon1.image

                self.icon2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxoslogo.png'))
                self.icon2_ = self.icon2_.resize((100, 100), Image.ANTIALIAS)
                self.icon2_ = ImageTk.PhotoImage(self.icon2_)
                self.ACTIVE_icon2_STATE = 0
                self.icon2.image = self.icon2_
                self.icon2['image'] = self.icon2.image

                self.icon3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxos3xwallapers.png'))
                self.icon3_ = self.icon3_.resize((100, 100), Image.ANTIALIAS)
                self.icon3_ = ImageTk.PhotoImage(self.icon3_)
                self.ACTIVE_icon3_STATE = 0
                self.icon3.image = self.icon3_
                self.icon3['image'] = self.icon3.image

                self.icon4_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','face.png'))
                self.icon4_ = self.icon4_.resize((100, 100), Image.ANTIALIAS)
                self.icon4_ = ImageTk.PhotoImage(self.icon4_)
                self.ACTIVE_icon4_STATE = 0
                self.icon4.image = self.icon4_
                self.icon4['image'] = self.icon4.image

                self.icon5_ = Image.open(self.custom_user_icon)
                self.icon5_ = self.icon5_.resize((100, 100), Image.ANTIALIAS)
                self.icon5_ = ImageTk.PhotoImage(self.icon5_)
                self.ACTIVE_icon5_STATE = 0
                self.icon5.image = self.icon5_
                self.icon5['image'] = self.icon5.image
            elif self.icon_position == 1:
                self.user_icon = str(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxoslogo.png'))

                self.icon1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','UserIcon.png'))
                self.icon1_ = self.icon1_.resize((100, 100), Image.ANTIALIAS)
                #self.icon1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icon1_ = ImageTk.PhotoImage(self.icon1_)
                self.ACTIVE_icon1_STATE = 0
                self.icon1.image = self.icon1_
                self.icon1['image'] = self.icon1.image

                self.icon2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxoslogo.png'))
                self.icon2_ = self.icon2_.resize((100, 100), Image.ANTIALIAS)
                self.icon2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icon2_ = ImageTk.PhotoImage(self.icon2_)
                self.ACTIVE_icon2_STATE = 1
                self.icon2.image = self.icon2_
                self.icon2['image'] = self.icon2.image

                self.icon3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxos3xwallapers.png'))
                self.icon3_ = self.icon3_.resize((100, 100), Image.ANTIALIAS)
                self.icon3_ = ImageTk.PhotoImage(self.icon3_)
                self.ACTIVE_icon3_STATE = 0
                self.icon3.image = self.icon3_
                self.icon3['image'] = self.icon3.image

                self.icon4_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','face.png'))
                self.icon4_ = self.icon4_.resize((100, 100), Image.ANTIALIAS)
                self.icon4_ = ImageTk.PhotoImage(self.icon4_)
                self.ACTIVE_icon4_STATE = 0
                self.icon4.image = self.icon4_
                self.icon4['image'] = self.icon4.image

                self.icon5_ = Image.open(self.custom_user_icon)
                self.icon5_ = self.icon5_.resize((100, 100), Image.ANTIALIAS)
                self.icon5_ = ImageTk.PhotoImage(self.icon5_)
                self.ACTIVE_icon5_STATE = 0
                self.icon5.image = self.icon5_
                self.icon5['image'] = self.icon5.image
            elif self.icon_position == 2:
                self.user_icon = str(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxos3xwallapers.png'))

                self.icon1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','UserIcon.png'))
                self.icon1_ = self.icon1_.resize((100, 100), Image.ANTIALIAS)
                #self.icon1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icon1_ = ImageTk.PhotoImage(self.icon1_)
                self.ACTIVE_icon1_STATE = 0
                self.icon1.image = self.icon1_
                self.icon1['image'] = self.icon1.image

                self.icon2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxoslogo.png'))
                self.icon2_ = self.icon2_.resize((100, 100), Image.ANTIALIAS)
                self.icon2_ = ImageTk.PhotoImage(self.icon2_)
                self.ACTIVE_icon2_STATE = 0
                self.icon2.image = self.icon2_
                self.icon2['image'] = self.icon2.image

                self.icon3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxos3xwallapers.png'))
                self.icon3_ = self.icon3_.resize((100, 100), Image.ANTIALIAS)
                self.icon3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icon3_ = ImageTk.PhotoImage(self.icon3_)
                self.ACTIVE_icon3_STATE = 1
                self.icon3.image = self.icon3_
                self.icon3['image'] = self.icon3.image

                self.icon4_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','face.png'))
                self.icon4_ = self.icon4_.resize((100, 100), Image.ANTIALIAS)
                self.icon4_ = ImageTk.PhotoImage(self.icon4_)
                self.ACTIVE_icon4_STATE = 0
                self.icon4.image = self.icon4_
                self.icon4['image'] = self.icon4.image

                self.icon5_ = Image.open(self.custom_user_icon)
                self.icon5_ = self.icon5_.resize((100, 100), Image.ANTIALIAS)
                self.icon5_ = ImageTk.PhotoImage(self.icon5_)
                self.ACTIVE_icon5_STATE = 0
                self.icon5.image = self.icon5_
                self.icon5['image'] = self.icon5.image
            elif self.icon_position == 3:
                self.user_icon = str(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','face.png'))

                self.icon1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','UserIcon.png'))
                self.icon1_ = self.icon1_.resize((100, 100), Image.ANTIALIAS)
                #self.icon1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icon1_ = ImageTk.PhotoImage(self.icon1_)
                self.ACTIVE_icon1_STATE = 0
                self.icon1.image = self.icon1_
                self.icon1['image'] = self.icon1.image

                self.icon2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxoslogo.png'))
                self.icon2_ = self.icon2_.resize((100, 100), Image.ANTIALIAS)
                self.icon2_ = ImageTk.PhotoImage(self.icon2_)
                self.ACTIVE_icon2_STATE = 0
                self.icon2.image = self.icon2_
                self.icon2['image'] = self.icon2.image

                self.icon3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxos3xwallapers.png'))
                self.icon3_ = self.icon3_.resize((100, 100), Image.ANTIALIAS)
                self.icon3_ = ImageTk.PhotoImage(self.icon3_)
                self.ACTIVE_icon3_STATE = 0
                self.icon3.image = self.icon3_
                self.icon3['image'] = self.icon3.image

                self.icon4_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','face.png'))
                self.icon4_ = self.icon4_.resize((100, 100), Image.ANTIALIAS)
                self.icon4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icon4_ = ImageTk.PhotoImage(self.icon4_)
                self.ACTIVE_icon4_STATE = 1
                self.icon4.image = self.icon4_
                self.icon4['image'] = self.icon4.image

                self.icon5_ = Image.open(self.custom_user_icon)
                self.icon5_ = self.icon5_.resize((100, 100), Image.ANTIALIAS)
                self.icon5_ = ImageTk.PhotoImage(self.icon5_)
                self.ACTIVE_icon5_STATE = 0
                self.icon5.image = self.icon5_
                self.icon5['image'] = self.icon5.image
            elif self.icon_position == 4:
                self.user_icon = str(self.custom_user_icon)

                self.icon1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','UserIcon.png'))
                self.icon1_ = self.icon1_.resize((100, 100), Image.ANTIALIAS)
                #self.icon1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icon1_ = ImageTk.PhotoImage(self.icon1_)
                self.ACTIVE_icon1_STATE = 0
                self.icon1.image = self.icon1_
                self.icon1['image'] = self.icon1.image

                self.icon2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxoslogo.png'))
                self.icon2_ = self.icon2_.resize((100, 100), Image.ANTIALIAS)
                self.icon2_ = ImageTk.PhotoImage(self.icon2_)
                self.ACTIVE_icon2_STATE = 0
                self.icon2.image = self.icon2_
                self.icon2['image'] = self.icon2.image

                self.icon3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxos3xwallapers.png'))
                self.icon3_ = self.icon3_.resize((100, 100), Image.ANTIALIAS)
                self.icon3_ = ImageTk.PhotoImage(self.icon3_)
                self.ACTIVE_icon3_STATE = 0
                self.icon3.image = self.icon3_
                self.icon3['image'] = self.icon3.image

                self.icon4_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','face.png'))
                self.icon4_ = self.icon4_.resize((100, 100), Image.ANTIALIAS)
                self.icon4_ = ImageTk.PhotoImage(self.icon4_)
                self.ACTIVE_icon4_STATE = 0
                self.icon4.image = self.icon4_
                self.icon4['image'] = self.icon4.image

                self.icon5_ = Image.open(self.custom_user_icon)
                self.icon5_ = self.icon5_.resize((100, 100), Image.ANTIALIAS)
                self.icon5_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icon5_ = ImageTk.PhotoImage(self.icon5_)
                self.ACTIVE_icon5_STATE = 1
                self.icon5.image = self.icon5_
                self.icon5['image'] = self.icon5.image


        def _icon1_():
            self.icon1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','UserIcon.png'))
            self.icon1_ = self.icon1_.resize((100, 100), Image.ANTIALIAS)
            self.icon1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
            self.icon1_ = ImageTk.PhotoImage(self.icon1_)
            self.HOVER_icon1_STATE = 0
            self.ACTIVE_icon1_STATE = 1
            def hover_up_tb(e=''):
                self.icon1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','UserIcon.png'))
                self.icon1_ = self.icon1_.resize((100, 100), Image.ANTIALIAS)
                self.icon1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icon1_ = ImageTk.PhotoImage(self.icon1_)

                self.icon1.image = self.icon1_
                self.icon1['image'] = self.icon1.image
                self.HOVER_icon1_STATE = 1
            def unhover_up_tb(e=''):
                if self.ACTIVE_icon1_STATE:
                    self.icon1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','UserIcon.png'))
                    self.icon1_ = self.icon1_.resize((100, 100), Image.ANTIALIAS)
                    self.icon1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                    self.icon1_ = ImageTk.PhotoImage(self.icon1_)

                    self.icon1.image = self.icon1_
                    self.icon1['image'] = self.icon1.image
                else:
                    self.icon1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','UserIcon.png'))
                    self.icon1_ = self.icon1_.resize((100, 100), Image.ANTIALIAS)
                    self.icon1_ = ImageTk.PhotoImage(self.icon1_)

                    self.icon1.image = self.icon1_
                    self.icon1['image'] = self.icon1.image
                self.HOVER_icon1_STATE = 0
            self.icon1 = Label(self.frame_icons, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
            self.icon1.image = self.icon1_
            self.icon1['image'] = self.icon1.image
            self.icon1.bind('<Enter>', hover_up_tb)
            self.icon1.bind('<Leave>', unhover_up_tb)
            def cmd_up_tb(e=''):
                self.ACTIVE_icon1_STATE = 1
                self.icon_position = 0
                check_position_icon()
            self.icon1.bind('<Button-1>', cmd_up_tb)
            self.icon1.pack(side=LEFT)

        def _icon2_():
            self.icon2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxoslogo.png'))
            self.icon2_ = self.icon2_.resize((100, 100), Image.ANTIALIAS)
            self.icon2_ = ImageTk.PhotoImage(self.icon2_)
            self.HOVER_icon2_STATE = 0
            self.ACTIVE_icon2_STATE = 0
            def hover_up_tb(e=''):
                self.icon2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxoslogo.png'))
                self.icon2_ = self.icon2_.resize((100, 100), Image.ANTIALIAS)
                self.icon2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icon2_ = ImageTk.PhotoImage(self.icon2_)

                self.icon2.image = self.icon2_
                self.icon2['image'] = self.icon2.image
                self.HOVER_icon2_STATE = 1
            def unhover_up_tb(e=''):
                if self.ACTIVE_icon2_STATE:
                    self.icon2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxoslogo.png'))
                    self.icon2_ = self.icon2_.resize((100, 100), Image.ANTIALIAS)
                    self.icon2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                    self.icon2_ = ImageTk.PhotoImage(self.icon2_)

                    self.icon2.image = self.icon2_
                    self.icon2['image'] = self.icon2.image
                else:
                    self.icon2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxoslogo.png'))
                    self.icon2_ = self.icon2_.resize((100, 100), Image.ANTIALIAS)
                    self.icon2_ = ImageTk.PhotoImage(self.icon2_)

                    self.icon2.image = self.icon2_
                    self.icon2['image'] = self.icon2.image
                self.HOVER_icon2_STATE = 0
            self.icon2 = Label(self.frame_icons, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
            self.icon2.image = self.icon2_
            self.icon2['image'] = self.icon2.image
            self.icon2.bind('<Enter>', hover_up_tb)
            self.icon2.bind('<Leave>', unhover_up_tb)
            def cmd_up_tb(e=''):
                self.ACTIVE_icon2_STATE = 1
                self.icon_position = 1
                check_position_icon()
            self.icon2.bind('<Button-1>', cmd_up_tb)
            self.icon2.pack(side=LEFT)

        def _icon3_():
            self.icon3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxos3xwallapers.png'))
            self.icon3_ = self.icon3_.resize((100, 100), Image.ANTIALIAS)
            self.icon3_ = ImageTk.PhotoImage(self.icon3_)
            self.HOVER_icon3_STATE = 0
            self.ACTIVE_icon3_STATE = 0
            def hover_up_tb(e=''):
                self.icon3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxos3xwallapers.png'))
                self.icon3_ = self.icon3_.resize((100, 100), Image.ANTIALIAS)
                self.icon3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icon3_ = ImageTk.PhotoImage(self.icon3_)

                self.icon3.image = self.icon3_
                self.icon3['image'] = self.icon3.image
                self.HOVER_icon3_STATE = 1
            def unhover_up_tb(e=''):
                if self.ACTIVE_icon3_STATE:
                    self.icon3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxos3xwallapers.png'))
                    self.icon3_ = self.icon3_.resize((100, 100), Image.ANTIALIAS)
                    self.icon3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                    self.icon3_ = ImageTk.PhotoImage(self.icon3_)

                    self.icon3.image = self.icon3_
                    self.icon3['image'] = self.icon3.image
                else:
                    self.icon3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','maxos3xwallapers.png'))
                    self.icon3_ = self.icon3_.resize((100, 100), Image.ANTIALIAS)
                    self.icon3_ = ImageTk.PhotoImage(self.icon3_)

                    self.icon3.image = self.icon3_
                    self.icon3['image'] = self.icon3.image
                self.HOVER_icon3_STATE = 0
            self.icon3 = Label(self.frame_icons, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
            self.icon3.image = self.icon3_
            self.icon3['image'] = self.icon3.image
            self.icon3.bind('<Enter>', hover_up_tb)
            self.icon3.bind('<Leave>', unhover_up_tb)
            def cmd_up_tb(e=''):
                self.ACTIVE_icon3_STATE = 1
                self.icon_position = 2
                check_position_icon()
            self.icon3.bind('<Button-1>', cmd_up_tb)
            self.icon3.pack(side=LEFT)

        def _icon4_():
            self.icon4_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','face.png'))
            self.icon4_ = self.icon4_.resize((100, 100), Image.ANTIALIAS)
            self.icon4_ = ImageTk.PhotoImage(self.icon4_)
            self.HOVER_icon4_STATE = 0
            self.ACTIVE_icon4_STATE = 0
            def hover_up_tb(e=''):
                self.icon4_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','face.png'))
                self.icon4_ = self.icon4_.resize((100, 100), Image.ANTIALIAS)
                self.icon4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icon4_ = ImageTk.PhotoImage(self.icon4_)

                self.icon4.image = self.icon4_
                self.icon4['image'] = self.icon4.image
                self.HOVER_icon4_STATE = 1
            def unhover_up_tb(e=''):
                if self.ACTIVE_icon4_STATE:
                    self.icon4_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','face.png'))
                    self.icon4_ = self.icon4_.resize((100, 100), Image.ANTIALIAS)
                    self.icon4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                    self.icon4_ = ImageTk.PhotoImage(self.icon4_)

                    self.icon4.image = self.icon4_
                    self.icon4['image'] = self.icon4.image
                else:
                    self.icon4_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','USERS_ICONS','face.png'))
                    self.icon4_ = self.icon4_.resize((100, 100), Image.ANTIALIAS)
                    self.icon4_ = ImageTk.PhotoImage(self.icon4_)

                    self.icon4.image = self.icon4_
                    self.icon4['image'] = self.icon4.image
                self.HOVER_icon4_STATE = 0
            self.icon4 = Label(self.frame_icons, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
            self.icon4.image = self.icon4_
            self.icon4['image'] = self.icon4.image
            self.icon4.bind('<Enter>', hover_up_tb)
            self.icon4.bind('<Leave>', unhover_up_tb)
            def cmd_up_tb(e=''):
                self.ACTIVE_icon4_STATE = 1
                self.icon_position = 3
                check_position_icon()
            self.icon4.bind('<Button-1>', cmd_up_tb)
            self.icon4.pack(side=LEFT)

        def _icon5_():
            self.icon5_ = Image.open(self.custom_user_icon)
            self.icon5_ = self.icon5_.resize((100, 100), Image.ANTIALIAS)
            self.icon5_ = ImageTk.PhotoImage(self.icon5_)
            self.HOVER_icon5_STATE = 0
            self.ACTIVE_icon5_STATE = 0
            def hover_up_tb(e=''):
                self.icon5_ = Image.open(self.custom_user_icon)
                self.icon5_ = self.icon5_.resize((100, 100), Image.ANTIALIAS)
                self.icon5_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icon5_ = ImageTk.PhotoImage(self.icon5_)

                self.icon5.image = self.icon5_
                self.icon5['image'] = self.icon5.image
                self.HOVER_icon5_STATE = 1
            def unhover_up_tb(e=''):
                if self.ACTIVE_icon5_STATE:
                    self.icon5_ = Image.open(self.custom_user_icon)
                    self.icon5_ = self.icon5_.resize((100, 100), Image.ANTIALIAS)
                    self.icon5_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                    self.icon5_ = ImageTk.PhotoImage(self.icon5_)

                    self.icon5.image = self.icon5_
                    self.icon5['image'] = self.icon5.image
                else:
                    self.icon5_ = Image.open(self.custom_user_icon)
                    self.icon5_ = self.icon5_.resize((100, 100), Image.ANTIALIAS)
                    self.icon5_ = ImageTk.PhotoImage(self.icon5_)

                    self.icon5.image = self.icon5_
                    self.icon5['image'] = self.icon5.image
                self.HOVER_icon5_STATE = 0
            self.icon5 = Label(self.frame_icons, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
            self.icon5.image = self.icon5_
            self.icon5['image'] = self.icon5.image
            self.icon5.bind('<Enter>', hover_up_tb)
            self.icon5.bind('<Leave>', unhover_up_tb)
            def cmd_up_tb(e=''):
                self.ACTIVE_icon5_STATE = 1
                self.icon_position = 4
                check_position_icon()
            self.icon5.bind('<Button-1>', cmd_up_tb)
            #self.icon5.pack(side=LEFT)

        _icon1_()
        _icon2_()
        _icon3_()
        _icon4_()
        _icon5_()
        def makeusericon():
            def OK(e=''):
                self.custom_user_icon = win.getpath()

                self.icon5_ = Image.open(self.custom_user_icon)
                self.icon5_ = self.icon5_.resize((100, 100), Image.ANTIALIAS)
                self.icon5_ = ImageTk.PhotoImage(self.icon5_)

                self.icon5.image = self.icon5_
                self.icon5['image'] = self.icon5.image
                self.icon5.pack(side=LEFT)
                self.plus1.delete()
                self.minus1.pack(side=LEFT)

            win = WebCamDialogWin(self.root, title='Сделать аватарку', command=OK, global_update=0)
        self.plus1 = BUTTON_MENU(self.frame_icons, path='PLUS', command=makeusericon, size=(100, 100))
        self.plus1.pack(side=LEFT)

        def deleteusericon():
            if self.icon_position == 4:
                self.icon_position = 0
                check_position_icon()
            self.icon5.pack_forget()
            self.minus1.delete()
            self.plus1.pack(side=LEFT)

        self.minus1 = BUTTON_MENU(self.frame_icons, path='MINUS', command=deleteusericon, size=(100, 100))
        #self.minus1.pack(side=LEFT)

        check_position_icon()

        def OK2(e=''):
            self.steps['text'] = 'Шаг 3. Фон рабочего стола'
            self.step2.pack_forget()
            self.step3.pack(anchor=NW, fill=BOTH, expand=1)

        self.okbtn = LabelButtonSystem(self.step2, font=(fontMaxOS, 15), text=' Далее ', width=15, bg=bg_tb, command=OK2)
        self.okbtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        def back1(e=''):
            self.steps['text'] = 'Шаг 1. Информация о пользователе'
            self.step2.pack_forget()
            self.step1.pack(anchor=NW, fill=BOTH, expand=1)

        self.backbtn = LabelButtonSystem(self.step2, font=(fontMaxOS, 15), text=' Назад ', width=15, bg=bg_tb, command=back1)
        self.backbtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        self.closebtn = LabelButtonSystem(self.step2, font=(fontMaxOS, 15), text=(' '+'Отмена'+' '), width=15, bg=bg_tb, command=self.destroy)
        self.closebtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        self.step3 = Frame(self.root1, bg=bg_tb, bd=7)

        self.frame_iconsdesktop = Frame(self.step3)
        self.frame_iconsdesktop.pack(anchor=NW)

        self.icondesktop_position = 0
        self.user_icondesktop = str(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image1.png'))

        def check_position_icondesktop():
            if self.icondesktop_position == 0:
                self.user_icondesktop = str(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image1.png'))

                self.icondesktop1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image1.png'))
                self.icondesktop1_ = self.icondesktop1_.resize((175, 118), Image.ANTIALIAS)
                self.icondesktop1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icondesktop1_ = ImageTk.PhotoImage(self.icondesktop1_)
                self.icondesktop1.image = self.icondesktop1_
                self.icondesktop1['image'] = self.icondesktop1.image
                self.ACTIVE_icondesktop1_STATE = 1


                self.icondesktop2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image2.png'))
                self.icondesktop2_ = self.icondesktop2_.resize((175, 118), Image.ANTIALIAS)
                #self.icondesktop2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icondesktop2_ = ImageTk.PhotoImage(self.icondesktop2_)
                self.icondesktop2.image = self.icondesktop2_
                self.icondesktop2['image'] = self.icondesktop2.image
                self.ACTIVE_icondesktop2_STATE = 0


                self.icondesktop3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image3.png'))
                self.icondesktop3_ = self.icondesktop3_.resize((175, 118), Image.ANTIALIAS)
                #self.icondesktop2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icondesktop3_ = ImageTk.PhotoImage(self.icondesktop3_)
                self.icondesktop3.image = self.icondesktop3_
                self.icondesktop3['image'] = self.icondesktop3.image
                self.ACTIVE_icondesktop3_STATE = 0
            elif self.icondesktop_position == 1:
                self.user_icondesktop = str(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image2.png'))

                self.icondesktop1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image1.png'))
                self.icondesktop1_ = self.icondesktop1_.resize((175, 118), Image.ANTIALIAS)
                #self.icondesktop1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icondesktop1_ = ImageTk.PhotoImage(self.icondesktop1_)
                self.icondesktop1.image = self.icondesktop1_
                self.icondesktop1['image'] = self.icondesktop1.image
                self.ACTIVE_icondesktop1_STATE = 0


                self.icondesktop2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image2.png'))
                self.icondesktop2_ = self.icondesktop2_.resize((175, 118), Image.ANTIALIAS)
                self.icondesktop2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icondesktop2_ = ImageTk.PhotoImage(self.icondesktop2_)
                self.icondesktop2.image = self.icondesktop2_
                self.icondesktop2['image'] = self.icondesktop2.image
                self.ACTIVE_icondesktop2_STATE = 1


                self.icondesktop3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image3.png'))
                self.icondesktop3_ = self.icondesktop3_.resize((175, 118), Image.ANTIALIAS)
                #self.icondesktop2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icondesktop3_ = ImageTk.PhotoImage(self.icondesktop3_)
                self.icondesktop3.image = self.icondesktop3_
                self.icondesktop3['image'] = self.icondesktop3.image
                self.ACTIVE_icondesktop3_STATE = 0
            elif self.icondesktop_position == 2:
                self.user_icondesktop = str(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image3.png'))

                self.icondesktop1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image1.png'))
                self.icondesktop1_ = self.icondesktop1_.resize((175, 118), Image.ANTIALIAS)
                #self.icondesktop1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icondesktop1_ = ImageTk.PhotoImage(self.icondesktop1_)
                self.icondesktop1.image = self.icondesktop1_
                self.icondesktop1['image'] = self.icondesktop1.image
                self.ACTIVE_icondesktop1_STATE = 0


                self.icondesktop2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image2.png'))
                self.icondesktop2_ = self.icondesktop2_.resize((175, 118), Image.ANTIALIAS)
                #self.icondesktop2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icondesktop2_ = ImageTk.PhotoImage(self.icondesktop2_)
                self.icondesktop2.image = self.icondesktop2_
                self.icondesktop2['image'] = self.icondesktop2.image
                self.ACTIVE_icondesktop2_STATE = 0


                self.icondesktop3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image3.png'))
                self.icondesktop3_ = self.icondesktop3_.resize((175, 118), Image.ANTIALIAS)
                self.icondesktop3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icondesktop3_ = ImageTk.PhotoImage(self.icondesktop3_)
                self.icondesktop3.image = self.icondesktop3_
                self.icondesktop3['image'] = self.icondesktop3.image
                self.ACTIVE_icondesktop3_STATE = 1


        def _icondesktop1_():
            self.icondesktop1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image1.png'))
            self.icondesktop1_ = self.icondesktop1_.resize((175, 118), Image.ANTIALIAS)
            self.icondesktop1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
            self.icondesktop1_ = ImageTk.PhotoImage(self.icondesktop1_)
            self.HOVER_icondesktop1_STATE = 0
            self.ACTIVE_icondesktop1_STATE = 1
            def hover_up_tb(e=''):
                self.icondesktop1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image1.png'))
                self.icondesktop1_ = self.icondesktop1_.resize((175, 118), Image.ANTIALIAS)
                self.icondesktop1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icondesktop1_ = ImageTk.PhotoImage(self.icondesktop1_)

                self.icondesktop1.image = self.icondesktop1_
                self.icondesktop1['image'] = self.icondesktop1.image
                self.HOVER_icondesktop1_STATE = 1
            def unhover_up_tb(e=''):
                if self.ACTIVE_icondesktop1_STATE:
                    self.icondesktop1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image1.png'))
                    self.icondesktop1_ = self.icondesktop1_.resize((175, 118), Image.ANTIALIAS)
                    self.icondesktop1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                    self.icondesktop1_ = ImageTk.PhotoImage(self.icondesktop1_)

                    self.icondesktop1.image = self.icondesktop1_
                    self.icondesktop1['image'] = self.icondesktop1.image
                else:
                    self.icondesktop1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image1.png'))
                    self.icondesktop1_ = self.icondesktop1_.resize((175, 118), Image.ANTIALIAS)
                    self.icondesktop1_ = ImageTk.PhotoImage(self.icondesktop1_)

                    self.icondesktop1.image = self.icondesktop1_
                    self.icondesktop1['image'] = self.icondesktop1.image
                self.HOVER_icondesktop1_STATE = 0
            self.icondesktop1 = Label(self.frame_iconsdesktop, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
            self.icondesktop1.image = self.icondesktop1_
            self.icondesktop1['image'] = self.icondesktop1.image
            self.icondesktop1.bind('<Enter>', hover_up_tb)
            self.icondesktop1.bind('<Leave>', unhover_up_tb)
            def cmd_up_tb(e=''):
                self.ACTIVE_icondesktop1_STATE = 1
                self.icondesktop_position = 0
                check_position_icondesktop()
            self.icondesktop1.bind('<Button-1>', cmd_up_tb)
            self.icondesktop1.pack(side=LEFT)

        def _icondesktop2_():
            self.icondesktop2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image2.png'))
            self.icondesktop2_ = self.icondesktop2_.resize((175, 118), Image.ANTIALIAS)
            #self.icondesktop2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
            self.icondesktop2_ = ImageTk.PhotoImage(self.icondesktop2_)
            self.HOVER_icondesktop2_STATE = 0
            self.ACTIVE_icondesktop2_STATE = 0
            def hover_up_tb(e=''):
                self.icondesktop2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image2.png'))
                self.icondesktop2_ = self.icondesktop2_.resize((175, 118), Image.ANTIALIAS)
                self.icondesktop2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icondesktop2_ = ImageTk.PhotoImage(self.icondesktop2_)

                self.icondesktop2.image = self.icondesktop2_
                self.icondesktop2['image'] = self.icondesktop2.image
                self.HOVER_icondesktop2_STATE = 1
            def unhover_up_tb(e=''):
                if self.ACTIVE_icondesktop2_STATE:
                    self.icondesktop2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image2.png'))
                    self.icondesktop2_ = self.icondesktop2_.resize((175, 118), Image.ANTIALIAS)
                    self.icondesktop2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                    self.icondesktop2_ = ImageTk.PhotoImage(self.icondesktop2_)

                    self.icondesktop2.image = self.icondesktop2_
                    self.icondesktop2['image'] = self.icondesktop2.image
                else:
                    self.icondesktop2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image2.png'))
                    self.icondesktop2_ = self.icondesktop2_.resize((175, 118), Image.ANTIALIAS)
                    self.icondesktop2_ = ImageTk.PhotoImage(self.icondesktop2_)

                    self.icondesktop2.image = self.icondesktop2_
                    self.icondesktop2['image'] = self.icondesktop2.image
                self.HOVER_icondesktop2_STATE = 0
            self.icondesktop2 = Label(self.frame_iconsdesktop, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
            self.icondesktop2.image = self.icondesktop2_
            self.icondesktop2['image'] = self.icondesktop2.image
            self.icondesktop2.bind('<Enter>', hover_up_tb)
            self.icondesktop2.bind('<Leave>', unhover_up_tb)
            def cmd_up_tb(e=''):
                self.ACTIVE_icondesktop2_STATE = 1
                self.icondesktop_position = 1
                check_position_icondesktop()
            self.icondesktop2.bind('<Button-1>', cmd_up_tb)
            self.icondesktop2.pack(side=LEFT)

        def _icondesktop3_():
            self.icondesktop3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image3.png'))
            self.icondesktop3_ = self.icondesktop3_.resize((175, 118), Image.ANTIALIAS)
            #self.icondesktop3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
            self.icondesktop3_ = ImageTk.PhotoImage(self.icondesktop3_)
            self.HOVER_icondesktop3_STATE = 0
            self.ACTIVE_icondesktop3_STATE = 0
            def hover_up_tb(e=''):
                self.icondesktop3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image3.png'))
                self.icondesktop3_ = self.icondesktop3_.resize((175, 118), Image.ANTIALIAS)
                self.icondesktop3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icondesktop3_ = ImageTk.PhotoImage(self.icondesktop3_)

                self.icondesktop3.image = self.icondesktop3_
                self.icondesktop3['image'] = self.icondesktop3.image
                self.HOVER_icondesktop3_STATE = 1
            def unhover_up_tb(e=''):
                if self.ACTIVE_icondesktop3_STATE:
                    self.icondesktop3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image3.png'))
                    self.icondesktop3_ = self.icondesktop3_.resize((175, 118), Image.ANTIALIAS)
                    self.icondesktop3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                    self.icondesktop3_ = ImageTk.PhotoImage(self.icondesktop3_)

                    self.icondesktop3.image = self.icondesktop3_
                    self.icondesktop3['image'] = self.icondesktop3.image
                else:
                    self.icondesktop3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image3.png'))
                    self.icondesktop3_ = self.icondesktop3_.resize((175, 118), Image.ANTIALIAS)
                    self.icondesktop3_ = ImageTk.PhotoImage(self.icondesktop3_)

                    self.icondesktop3.image = self.icondesktop3_
                    self.icondesktop3['image'] = self.icondesktop3.image
                self.HOVER_icondesktop3_STATE = 0
            self.icondesktop3 = Label(self.frame_iconsdesktop, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
            self.icondesktop3.image = self.icondesktop3_
            self.icondesktop3['image'] = self.icondesktop3.image
            self.icondesktop3.bind('<Enter>', hover_up_tb)
            self.icondesktop3.bind('<Leave>', unhover_up_tb)
            def cmd_up_tb(e=''):
                self.ACTIVE_icondesktop3_STATE = 1
                self.icondesktop_position = 2
                check_position_icondesktop()
            self.icondesktop3.bind('<Button-1>', cmd_up_tb)
            self.icondesktop3.pack(side=LEFT)

        _icondesktop1_()
        _icondesktop2_()
        _icondesktop3_()

        check_position_icondesktop()

        def OK3(e=''):
            self.steps['text'] = 'Шаг 4. Конфигурация панели задач'
            self.step3.pack_forget()
            self.step4.pack(anchor=NW, fill=BOTH, expand=1)

        self.okbtn = LabelButtonSystem(self.step3, font=(fontMaxOS, 15), text=' Далее ', width=15, bg=bg_tb, command=OK3)
        self.okbtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        def back2(e=''):
            self.steps['text'] = 'Шаг 2. Аватарка пользователя'
            self.step3.pack_forget()
            self.step2.pack(anchor=NW, fill=BOTH, expand=1)

        self.backbtn = LabelButtonSystem(self.step3, font=(fontMaxOS, 15), text=' Назад ', width=15, bg=bg_tb, command=back2)
        self.backbtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        self.closebtn = LabelButtonSystem(self.step3, font=(fontMaxOS, 15), text=(' '+'Отмена'+' '), width=15, bg=bg_tb, command=self.destroy)
        self.closebtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)


        self.step4 = Frame(self.root1, bg=bg_tb, bd=7)

        self.frame_tb = Frame(self.step4)
        self.frame_tb.pack(anchor=NW)

        self.tb_position = 1
        self.tb_config = 'top'

        def check_position_tb():
            if self.tb_position == 0:
                self.tb_config = 'False'

                self.icontb1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','TOP_TB_BTN','normal.png'))
                self.icontb1_ = self.icontb1_.resize((175, 118), Image.ANTIALIAS)
                #self.icontb1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icontb1_ = ImageTk.PhotoImage(self.icontb1_)
                self.icontb1.image = self.icontb1_
                self.icontb1['image'] = self.icontb1.image
                self.ACTIVE_icontb1_STATE = 0


                self.icontb2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','BOTTOM_TB_BTN','normal.png'))
                self.icontb2_ = self.icontb2_.resize((175, 118), Image.ANTIALIAS)
                #self.icontbw_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icontb2_ = ImageTk.PhotoImage(self.icontb2_)
                self.icontb2.image = self.icontb2_
                self.icontb2['image'] = self.icontb2.image
                self.ACTIVE_icontb2_STATE = 0
            elif  self.tb_position == 1:
                self.tb_config = 'top'

                self.icontb1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','TOP_TB_BTN','normal.png'))
                self.icontb1_ = self.icontb1_.resize((175, 118), Image.ANTIALIAS)
                self.icontb1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icontb1_ = ImageTk.PhotoImage(self.icontb1_)
                self.icontb1.image = self.icontb1_
                self.icontb1['image'] = self.icontb1.image
                self.ACTIVE_icontb1_STATE = 1


                self.icontb2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','BOTTOM_TB_BTN','normal.png'))
                self.icontb2_ = self.icontb2_.resize((175, 118), Image.ANTIALIAS)
                #self.icontbw_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icontb2_ = ImageTk.PhotoImage(self.icontb2_)
                self.icontb2.image = self.icontb2_
                self.icontb2['image'] = self.icontb2.image
                self.ACTIVE_icontb2_STATE = 0
            elif  self.tb_position == 2:
                self.tb_config = 'bottom'

                self.icontb1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','TOP_TB_BTN','normal.png'))
                self.icontb1_ = self.icontb1_.resize((175, 118), Image.ANTIALIAS)
                #self.icontb1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icontb1_ = ImageTk.PhotoImage(self.icontb1_)
                self.icontb1.image = self.icontb1_
                self.icontb1['image'] = self.icontb1.image
                self.ACTIVE_icontb1_STATE = 0


                self.icontb2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','BOTTOM_TB_BTN','normal.png'))
                self.icontb2_ = self.icontb2_.resize((175, 118), Image.ANTIALIAS)
                self.icontb2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icontb2_ = ImageTk.PhotoImage(self.icontb2_)
                self.icontb2.image = self.icontb2_
                self.icontb2['image'] = self.icontb2.image
                self.ACTIVE_icontb2_STATE = 1



        def _icontbup_():
            self.icontb1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','TOP_TB_BTN','normal.png'))
            self.icontb1_ = self.icontb1_.resize((175, 118), Image.ANTIALIAS)
            self.icontb1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
            self.icontb1_ = ImageTk.PhotoImage(self.icontb1_)
            self.HOVER_icontb1_STATE = 0
            self.ACTIVE_icontb1_STATE = 1
            def hover_up_tb(e=''):
                self.icontb1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','TOP_TB_BTN','normal.png'))
                self.icontb1_ = self.icontb1_.resize((175, 118), Image.ANTIALIAS)
                self.icontb1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icontb1_ = ImageTk.PhotoImage(self.icontb1_)

                self.icontb1.image = self.icontb1_
                self.icontb1['image'] = self.icontb1.image
                self.HOVER_icontb1_STATE = 1
            def unhover_up_tb(e=''):
                if self.ACTIVE_icontb1_STATE:
                    self.icontb1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','TOP_TB_BTN','normal.png'))
                    self.icontb1_ = self.icontb1_.resize((175, 118), Image.ANTIALIAS)
                    self.icontb1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                    self.icontb1_ = ImageTk.PhotoImage(self.icontb1_)

                    self.icontb1.image = self.icontb1_
                    self.icontb1['image'] = self.icontb1.image
                else:
                    self.icontb1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','TOP_TB_BTN','normal.png'))
                    self.icontb1_ = self.icontb1_.resize((175, 118), Image.ANTIALIAS)
                    self.icontb1_ = ImageTk.PhotoImage(self.icontb1_)

                    self.icontb1.image = self.icontb1_
                    self.icontb1['image'] = self.icontb1.image
                self.HOVER_icontb1_STATE = 0
            self.icontb1 = Label(self.frame_tb, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
            self.icontb1.image = self.icontb1_
            self.icontb1['image'] = self.icontb1.image
            self.icontb1.bind('<Enter>', hover_up_tb)
            self.icontb1.bind('<Leave>', unhover_up_tb)
            def cmd_up_tb(e=''):
                if self.ACTIVE_icontb1_STATE:
                    self.ACTIVE_icontb1_STATE = 0
                    self.tb_position = 0
                else:
                    self.ACTIVE_icontb1_STATE = 1
                    self.tb_position = 1
                check_position_tb()
            self.icontb1.bind('<Button-1>', cmd_up_tb)
            self.icontb1.pack(side=LEFT)

        def _icontbdown_():
            self.icontb2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','BOTTOM_TB_BTN','normal.png'))
            self.icontb2_ = self.icontb2_.resize((175, 118), Image.ANTIALIAS)
            #self.icontb2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
            self.icontb2_ = ImageTk.PhotoImage(self.icontb2_)
            self.HOVER_icontb2_STATE = 0
            self.ACTIVE_icontb2_STATE = 0
            def hover_up_tb(e=''):
                self.icontb2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','BOTTOM_TB_BTN','normal.png'))
                self.icontb2_ = self.icontb2_.resize((175, 118), Image.ANTIALIAS)
                self.icontb2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                self.icontb2_ = ImageTk.PhotoImage(self.icontb2_)

                self.icontb2.image = self.icontb2_
                self.icontb2['image'] = self.icontb2.image
                self.HOVER_icontb2_STATE = 1
            def unhover_up_tb(e=''):
                if self.ACTIVE_icontb2_STATE:
                    self.icontb2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','BOTTOM_TB_BTN','normal.png'))
                    self.icontb2_ = self.icontb2_.resize((175, 118), Image.ANTIALIAS)
                    self.icontb2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((175, 118), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((175, 118), Image.ANTIALIAS))
                    self.icontb2_ = ImageTk.PhotoImage(self.icontb2_)

                    self.icontb2.image = self.icontb2_
                    self.icontb2['image'] = self.icontb2.image
                else:
                    self.icontb2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','TB_CONFIG_BUTTONS','BOTTOM_TB_BTN','normal.png'))
                    self.icontb2_ = self.icontb2_.resize((175, 118), Image.ANTIALIAS)
                    self.icontb2_ = ImageTk.PhotoImage(self.icontb2_)

                    self.icontb2.image = self.icontb2_
                    self.icontb2['image'] = self.icontb2.image
                self.HOVER_icontb2_STATE = 0
            self.icontb2 = Label(self.frame_tb, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
            self.icontb2.image = self.icontb2_
            self.icontb2['image'] = self.icontb2.image
            self.icontb2.bind('<Enter>', hover_up_tb)
            self.icontb2.bind('<Leave>', unhover_up_tb)
            def cmd_up_tb(e=''):
                if self.ACTIVE_icontb2_STATE:
                    self.ACTIVE_icontb2_STATE = 0
                    self.tb_position = 0
                else:
                    self.ACTIVE_icontb2_STATE = 1
                    self.tb_position = 2
                check_position_tb()
            self.icontb2.bind('<Button-1>', cmd_up_tb)
            self.icontb2.pack(side=LEFT)

        _icontbup_()
        _icontbdown_()

        check_position_tb()

        def OK4(e=''):
            self.steps['text'] = 'Шаг 5. Тема и шрифт'
            self.step4.pack_forget()
            self.step5.pack(anchor=NW, fill=BOTH, expand=1)

        self.okbtn = LabelButtonSystem(self.step4, font=(fontMaxOS, 15), text=' Далее ', width=15, bg=bg_tb, command=OK4)
        self.okbtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        def back3(e=''):
            self.steps['text'] = 'Шаг 3. Фон рабочего стола'
            self.step4.pack_forget()
            self.step3.pack(anchor=NW, fill=BOTH, expand=1)

        self.backbtn = LabelButtonSystem(self.step4, font=(fontMaxOS, 15), text=' Назад ', width=15, bg=bg_tb, command=back3)
        self.backbtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        self.closebtn = LabelButtonSystem(self.step4, font=(fontMaxOS, 15), text=(' '+'Отмена'+' '), width=15, bg=bg_tb, command=self.destroy)
        self.closebtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)


        self.step5 = Frame(self.root1, bg=bg_tb, bd=7)

        self.lab1 = Label(self.step5, text='Тема')
        self.lab1.pack(anchor=NW)

        self.frametheme = Frame(self.step5)
        self.frametheme.pack(anchor=NW)

        self.icontheme_position = 0
        self.user_icontheme = ("#333533", "#ffffff")
        self.bg_color, self.fg_color = "#333533", "#ffffff"
        self.custom_user_icontheme = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','window.png'))

        def check_position_icontheme():
            if self.icontheme_position == 0:
                self.user_icontheme = ("#333533", "#ffffff")

                self.icontheme1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','DARK_THEME','normal.png'))
                self.icontheme1_ = self.icontheme1_.resize((100, 100), Image.ANTIALIAS)
                self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme1_ = ImageTk.PhotoImage(self.icontheme1_)
                self.icontheme1.image = self.icontheme1_
                self.icontheme1['image'] = self.icontheme1.image
                self.ACTIVE_icontheme1_STATE = 1


                self.icontheme2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','LIGHT_THEME','normal.png'))
                self.icontheme2_ = self.icontheme2_.resize((100, 100), Image.ANTIALIAS)
                #self.icontheme2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme2_ = ImageTk.PhotoImage(self.icontheme2_)
                self.icontheme2.image = self.icontheme2_
                self.icontheme2['image'] = self.icontheme2.image
                self.ACTIVE_icontheme2_STATE = 0

                self.icontheme3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','MAXOSXBLUE_THEME','normal.png'))
                self.icontheme3_ = self.icontheme3_.resize((100, 100), Image.ANTIALIAS)
                #self.icontheme3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme3_ = ImageTk.PhotoImage(self.icontheme3_)
                self.icontheme3.image = self.icontheme3_
                self.icontheme3['image'] = self.icontheme3.image
                self.ACTIVE_icontheme3_STATE = 0


                self.icontheme4_ = self.custom_user_icontheme
                self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
                #self.icontheme3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)
                self.icontheme4.image = self.icontheme4_
                self.icontheme4['image'] = self.icontheme4.image
                self.ACTIVE_icontheme4_STATE = 0
            elif self.icontheme_position == 1:
                self.user_icontheme = ("#effbff", "#000000")

                self.icontheme1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','DARK_THEME','normal.png'))
                self.icontheme1_ = self.icontheme1_.resize((100, 100), Image.ANTIALIAS)
                #self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme1_ = ImageTk.PhotoImage(self.icontheme1_)
                self.icontheme1.image = self.icontheme1_
                self.icontheme1['image'] = self.icontheme1.image
                self.ACTIVE_icontheme1_STATE = 0


                self.icontheme2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','LIGHT_THEME','normal.png'))
                self.icontheme2_ = self.icontheme2_.resize((100, 100), Image.ANTIALIAS)
                self.icontheme2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme2_ = ImageTk.PhotoImage(self.icontheme2_)
                self.icontheme2.image = self.icontheme2_
                self.icontheme2['image'] = self.icontheme2.image
                self.ACTIVE_icontheme2_STATE = 1


                self.icontheme3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','MAXOSXBLUE_THEME','normal.png'))
                self.icontheme3_ = self.icontheme3_.resize((100, 100), Image.ANTIALIAS)
                #self.icontheme3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme3_ = ImageTk.PhotoImage(self.icontheme3_)
                self.icontheme3.image = self.icontheme3_
                self.icontheme3['image'] = self.icontheme3.image
                self.ACTIVE_icontheme3_STATE = 0


                self.icontheme4_ = self.custom_user_icontheme
                self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
                #self.icontheme3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)
                self.icontheme4.image = self.icontheme4_
                self.icontheme4['image'] = self.icontheme4.image
                self.ACTIVE_icontheme4_STATE = 0
            elif self.icontheme_position == 2:
                self.user_icontheme = ("#28749b", "#ffffff")

                self.icontheme1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','DARK_THEME','normal.png'))
                self.icontheme1_ = self.icontheme1_.resize((100, 100), Image.ANTIALIAS)
                #self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme1_ = ImageTk.PhotoImage(self.icontheme1_)
                self.icontheme1.image = self.icontheme1_
                self.icontheme1['image'] = self.icontheme1.image
                self.ACTIVE_icontheme1_STATE = 0


                self.icontheme2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','LIGHT_THEME','normal.png'))
                self.icontheme2_ = self.icontheme2_.resize((100, 100), Image.ANTIALIAS)
                #self.icontheme2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme2_ = ImageTk.PhotoImage(self.icontheme2_)
                self.icontheme2.image = self.icontheme2_
                self.icontheme2['image'] = self.icontheme2.image
                self.ACTIVE_icontheme2_STATE = 0


                self.icontheme3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','MAXOSXBLUE_THEME','normal.png'))
                self.icontheme3_ = self.icontheme3_.resize((100, 100), Image.ANTIALIAS)
                self.icontheme3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme3_ = ImageTk.PhotoImage(self.icontheme3_)
                self.icontheme3.image = self.icontheme3_
                self.icontheme3['image'] = self.icontheme3.image
                self.ACTIVE_icontheme3_STATE = 1


                self.icontheme4_ = self.custom_user_icontheme
                self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
                #self.icontheme3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)
                self.icontheme4.image = self.icontheme4_
                self.icontheme4['image'] = self.icontheme4.image
                self.ACTIVE_icontheme4_STATE = 0
            elif self.icontheme_position == 3:
                self.user_icontheme = (self.bg_color, self.fg_color)

                self.icontheme1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','DARK_THEME','normal.png'))
                self.icontheme1_ = self.icontheme1_.resize((100, 100), Image.ANTIALIAS)
                #self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme1_ = ImageTk.PhotoImage(self.icontheme1_)
                self.icontheme1.image = self.icontheme1_
                self.icontheme1['image'] = self.icontheme1.image
                self.ACTIVE_icontheme1_STATE = 0


                self.icontheme2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','LIGHT_THEME','normal.png'))
                self.icontheme2_ = self.icontheme2_.resize((100, 100), Image.ANTIALIAS)
                #self.icontheme2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme2_ = ImageTk.PhotoImage(self.icontheme2_)
                self.icontheme2.image = self.icontheme2_
                self.icontheme2['image'] = self.icontheme2.image
                self.ACTIVE_icontheme2_STATE = 0


                self.icontheme3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','MAXOSXBLUE_THEME','normal.png'))
                self.icontheme3_ = self.icontheme3_.resize((100, 100), Image.ANTIALIAS)
                #self.icontheme3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme3_ = ImageTk.PhotoImage(self.icontheme3_)
                self.icontheme3.image = self.icontheme3_
                self.icontheme3['image'] = self.icontheme3.image
                self.ACTIVE_icontheme3_STATE = 0


                self.icontheme4_ = self.custom_user_icontheme
                self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
                self.icontheme4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)
                self.icontheme4.image = self.icontheme4_
                self.icontheme4['image'] = self.icontheme4.image
                self.ACTIVE_icontheme4_STATE = 1



        def _icontheme1_():
            self.icontheme1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','DARK_THEME','normal.png'))
            self.icontheme1_ = self.icontheme1_.resize((100, 100), Image.ANTIALIAS)
            self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
            self.icontheme1_ = ImageTk.PhotoImage(self.icontheme1_)
            self.HOVER_icontheme1_STATE = 0
            self.ACTIVE_icontheme1_STATE = 1
            def hover_up_tb(e=''):
                self.icontheme1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','DARK_THEME','normal.png'))
                self.icontheme1_ = self.icontheme1_.resize((100, 100), Image.ANTIALIAS)
                self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme1_ = ImageTk.PhotoImage(self.icontheme1_)

                self.icontheme1.image = self.icontheme1_
                self.icontheme1['image'] = self.icontheme1.image
                self.HOVER_icontheme1_STATE = 1
            def unhover_up_tb(e=''):
                if self.ACTIVE_icontheme1_STATE:
                    self.icontheme1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','DARK_THEME','normal.png'))
                    self.icontheme1_ = self.icontheme1_.resize((100, 100), Image.ANTIALIAS)
                    self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                    self.icontheme1_ = ImageTk.PhotoImage(self.icontheme1_)

                    self.icontheme1.image = self.icontheme1_
                    self.icontheme1['image'] = self.icontheme1.image
                else:
                    self.icontheme1_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','DARK_THEME','normal.png'))
                    self.icontheme1_ = self.icontheme1_.resize((100, 100), Image.ANTIALIAS)
                    self.icontheme1_ = ImageTk.PhotoImage(self.icontheme1_)

                    self.icontheme1.image = self.icontheme1_
                    self.icontheme1['image'] = self.icontheme1.image
                self.HOVER_icontheme1_STATE = 0
            self.icontheme1 = Label(self.frametheme, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
            self.icontheme1.image = self.icontheme1_
            self.icontheme1['image'] = self.icontheme1.image
            self.icontheme1.bind('<Enter>', hover_up_tb)
            self.icontheme1.bind('<Leave>', unhover_up_tb)
            def cmd_up_tb(e=''):
                self.ACTIVE_icontheme1_STATE = 1
                self.icontheme_position = 0
                check_position_icontheme()
            self.icontheme1.bind('<Button-1>', cmd_up_tb)
            self.icontheme1.pack(side=LEFT)

        def _icontheme2_():
            self.icontheme2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','LIGHT_THEME','normal.png'))
            self.icontheme2_ = self.icontheme2_.resize((100, 100), Image.ANTIALIAS)
            #self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
            self.icontheme2_ = ImageTk.PhotoImage(self.icontheme2_)
            self.HOVER_icontheme2_STATE = 0
            self.ACTIVE_icontheme2_STATE = 0
            def hover_up_tb(e=''):
                self.icontheme2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','LIGHT_THEME','normal.png'))
                self.icontheme2_ = self.icontheme2_.resize((100, 100), Image.ANTIALIAS)
                self.icontheme2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme2_ = ImageTk.PhotoImage(self.icontheme2_)

                self.icontheme2.image = self.icontheme2_
                self.icontheme2['image'] = self.icontheme2.image
                self.HOVER_icontheme2_STATE = 1
            def unhover_up_tb(e=''):
                if self.ACTIVE_icontheme2_STATE:
                    self.icontheme2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','LIGHT_THEME','normal.png'))
                    self.icontheme2_ = self.icontheme2_.resize((100, 100), Image.ANTIALIAS)
                    self.icontheme2_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                    self.icontheme2_ = ImageTk.PhotoImage(self.icontheme2_)

                    self.icontheme2.image = self.icontheme2_
                    self.icontheme2['image'] = self.icontheme2.image
                else:
                    self.icontheme2_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','LIGHT_THEME','normal.png'))
                    self.icontheme2_ = self.icontheme2_.resize((100, 100), Image.ANTIALIAS)
                    self.icontheme2_ = ImageTk.PhotoImage(self.icontheme2_)

                    self.icontheme2.image = self.icontheme2_
                    self.icontheme2['image'] = self.icontheme2.image
                self.HOVER_icontheme2_STATE = 0
            self.icontheme2 = Label(self.frametheme, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
            self.icontheme2.image = self.icontheme2_
            self.icontheme2['image'] = self.icontheme2.image
            self.icontheme2.bind('<Enter>', hover_up_tb)
            self.icontheme2.bind('<Leave>', unhover_up_tb)
            def cmd_up_tb(e=''):
                self.ACTIVE_icontheme2_STATE = 1
                self.icontheme_position = 1
                check_position_icontheme()
            self.icontheme2.bind('<Button-1>', cmd_up_tb)
            self.icontheme2.pack(side=LEFT)

        def _icontheme3_():
            self.icontheme3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','MAXOSXBLUE_THEME','normal.png'))
            self.icontheme3_ = self.icontheme3_.resize((100, 100), Image.ANTIALIAS)
            #self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
            self.icontheme3_ = ImageTk.PhotoImage(self.icontheme3_)
            self.HOVER_icontheme3_STATE = 0
            self.ACTIVE_icontheme3_STATE = 0
            def hover_up_tb(e=''):
                self.icontheme3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','MAXOSXBLUE_THEME','normal.png'))
                self.icontheme3_ = self.icontheme3_.resize((100, 100), Image.ANTIALIAS)
                self.icontheme3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme3_ = ImageTk.PhotoImage(self.icontheme3_)

                self.icontheme3.image = self.icontheme3_
                self.icontheme3['image'] = self.icontheme3.image
                self.HOVER_icontheme3_STATE = 1
            def unhover_up_tb(e=''):
                if self.ACTIVE_icontheme3_STATE:
                    self.icontheme3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','MAXOSXBLUE_THEME','normal.png'))
                    self.icontheme3_ = self.icontheme3_.resize((100, 100), Image.ANTIALIAS)
                    self.icontheme3_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                    self.icontheme3_ = ImageTk.PhotoImage(self.icontheme3_)

                    self.icontheme3.image = self.icontheme3_
                    self.icontheme3['image'] = self.icontheme3.image
                else:
                    self.icontheme3_ = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','MAXOSXBLUE_THEME','normal.png'))
                    self.icontheme3_ = self.icontheme3_.resize((100, 100), Image.ANTIALIAS)
                    self.icontheme3_ = ImageTk.PhotoImage(self.icontheme3_)

                    self.icontheme3.image = self.icontheme3_
                    self.icontheme3['image'] = self.icontheme3.image
                self.HOVER_icontheme3_STATE = 0
            self.icontheme3 = Label(self.frametheme, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
            self.icontheme3.image = self.icontheme3_
            self.icontheme3['image'] = self.icontheme3.image
            self.icontheme3.bind('<Enter>', hover_up_tb)
            self.icontheme3.bind('<Leave>', unhover_up_tb)
            def cmd_up_tb(e=''):
                self.ACTIVE_icontheme3_STATE = 1
                self.icontheme_position = 2
                check_position_icontheme()
            self.icontheme3.bind('<Button-1>', cmd_up_tb)
            self.icontheme3.pack(side=LEFT)

        def _icontheme4_():
            self.icontheme4_ = self.custom_user_icontheme
            self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
            #self.icontheme1_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
            self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)
            self.HOVER_icontheme4_STATE = 0
            self.ACTIVE_icontheme4_STATE = 0
            def hover_up_tb(e=''):
                self.icontheme4_ = self.custom_user_icontheme
                self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
                self.icontheme4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)

                self.icontheme4.image = self.icontheme4_
                self.icontheme4['image'] = self.icontheme4.image
                self.HOVER_icontheme4_STATE = 1
            def unhover_up_tb(e=''):
                if self.ACTIVE_icontheme4_STATE:
                    self.icontheme4_ = self.custom_user_icontheme
                    self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
                    self.icontheme4_.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','active.png')).resize((100, 100), Image.ANTIALIAS), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SELECTED','select.png')).resize((100, 100), Image.ANTIALIAS))
                    self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)

                    self.icontheme4.image = self.icontheme4_
                    self.icontheme4['image'] = self.icontheme4.image
                else:
                    self.icontheme4_ = self.custom_user_icontheme
                    self.icontheme4_ = self.icontheme4_.resize((100, 100), Image.ANTIALIAS)
                    self.icontheme4_ = ImageTk.PhotoImage(self.icontheme4_)

                    self.icontheme4.image = self.icontheme4_
                    self.icontheme4['image'] = self.icontheme4.image
                self.HOVER_icontheme4_STATE = 0
            self.icontheme4 = Label(self.frametheme, cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
            self.icontheme4.image = self.icontheme4_
            self.icontheme4['image'] = self.icontheme4.image
            self.icontheme4.bind('<Enter>', hover_up_tb)
            self.icontheme4.bind('<Leave>', unhover_up_tb)
            def cmd_up_tb(e=''):
                self.ACTIVE_icontheme4_STATE = 1
                self.icontheme_position = 3
                check_position_icontheme()
            self.icontheme4.bind('<Button-1>', cmd_up_tb)
            #self.icontheme4.pack(side=LEFT)

        _icontheme1_()
        _icontheme2_()
        _icontheme3_()
        _icontheme4_()

        check_position_icontheme()

        def maketheme():
            self.theme_root = DialogWinCustom(self.root, global_update=0)
            self.theme_root.title('Создать тему')

            def theme_upd():
                self.theme_aft = self.frame_content.after(10000, theme_upd)

                bg_color = ''
                fg_color = ''
                font_ = ''
                font_size = 0

                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                    bg_color = bg.read()
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                    fg_color = fg.read()
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                    font_ = f.read()
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                    font_size = int(fs.read())

                self.frame_content['bg'] = bg_color
                self.colors1['bg'] = bg_color

                self.lab_bg_['bg'] = bg_color
                self.lab_bg_['fg'] = fg_color
                self.lab_bg_['font'] = (font_, font_size)

                self.lab_fg_['bg'] = bg_color
                self.lab_fg_['fg'] = fg_color
                self.lab_fg_['font'] = (font_, font_size)

                self.colors2['bg'] = bg_color

                self.colors3['bg'] = bg_color

                self.framebtns['bg'] = bg_color


            self.frame_content = Frame(self.theme_root.content)
            self.frame_content.pack(fill=BOTH, expand=1)

            self.colors1 = Frame(self.frame_content)
            self.colors1.pack(fill=X)

            self.lab_bg_ = Label(self.colors1, text='Цвет фона')
            self.lab_bg_.pack(side=LEFT, expand=1, padx=10, pady=5)

            self.lab_fg_ = Label(self.colors1, text='Цвет текста')
            self.lab_fg_.pack(side=LEFT, expand=1, padx=10, pady=5)


            self.colors2 = Frame(self.frame_content)
            self.colors2.pack(fill=X)

            self.frame_bg = Frame(self.colors2, bg='#9e9e9e')
            self.frame_bg.pack(side=LEFT, expand=1, padx=10, pady=5, fill=X)

            self.lab_bg = Label(self.frame_bg, width=5, font=('Montserrat', 15), bg='#000000')
            self.lab_bg.pack(side=LEFT, expand=1, padx=2, pady=2, fill=X)

            self.frame_fg = Frame(self.colors2, bg='#9e9e9e')
            self.frame_fg.pack(side=LEFT, expand=1, padx=10, pady=5, fill=X)

            self.lab_fg = Label(self.frame_fg, width=5, font=('Montserrat', 15), bg='#000000')
            self.lab_fg.pack(side=LEFT, expand=1, padx=2, pady=2, fill=X)


            self.colors3 = Frame(self.frame_content)
            self.colors3.pack(fill=X)

            def _bg_():
                def OK_():
                    color = COLOR.getcolorhex()
                    self.bg_color = color
                    self.lab_bg['bg'] = color
                    COLOR.destroy()
                COLOR = ColorDialogWin(self.theme_root.root, command=OK_, title='Выбрать цвет фона', global_update=0)

            LabelButtonSystem(self.colors3, text='Выбрать цвет', command=_bg_).pack(side=LEFT, expand=1, padx=10, pady=5, fill=X)

            def _fg_():
                def OK_():
                    color = COLOR.getcolorhex()
                    self.fg_color = color
                    self.lab_fg['bg'] = color
                    COLOR.destroy()
                COLOR = ColorDialogWin(self.theme_root.root, command=OK_, title='Выбрать цвет текста', global_update=0)

            LabelButtonSystem(self.colors3, text='Выбрать цвет', command=_fg_).pack(side=LEFT, expand=1, padx=10, pady=5, fill=X)

            self.framebtns = Frame(self.frame_content)
            self.framebtns.pack(side=BOTTOM, fill=X, expand=1, anchor=NW)

            def OK():
                def color_img(img, color):
                    img = Image.open(img)
                    pixdata = img.load()
                    r, g, b, = ImageColor.getcolor(color, "RGB")
                    for y in range(img.size[1]):
                        for x in range(img.size[0]):
                            alpha = pixdata[x, y][3]
                            if alpha:
                                pixdata[x, y] = (r, g, b, alpha)
                    return img

                self.custom_user_icontheme = color_img(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','window.png'), color=self.bg_color)
                self.custom_user_icontheme.paste(color_img(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','title.png'), color=self.fg_color), (0,0), color_img(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','title.png'), color=self.fg_color))
                self.custom_user_icontheme.paste(Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','icon.png')), (0,0), Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','THEME_BUTTONS','CUSTOM_THEME','icon.png')))

                check_position_icontheme()

                self.plus2.delete()
                self.icontheme4.pack(side=LEFT)
                self.minus2.pack(side=LEFT)

                self.frame_content.after_cancel(self.theme_aft)
                self.theme_root.destroy()

            LabelButtonSystem(self.framebtns, text=' OK ', command=OK).pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

            def close():
                self.frame_content.after_cancel(self.theme_aft)
                self.theme_root.destroy()

            LabelButtonSystem(self.framebtns, text=(' '+'Отмена'+' '), command=close).pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

            theme_upd()

        self.plus2 = BUTTON_MENU(self.frametheme, path='PLUS', command=maketheme, size=(100, 100))
        self.plus2.pack(side=LEFT)

        def deletetheme():
            if self.icontheme_position == 3:
                self.icontheme_position = 0
                check_position_icontheme()
            self.icontheme4.pack_forget()
            self.minus2.delete()
            self.plus2.pack(side=LEFT)

        self.minus2 = BUTTON_MENU(self.frametheme, path='MINUS', command=deletetheme, size=(100, 100))
        #self.minus2.pack(side=LEFT)

        Separator(self.step5, orient='horizontal')

        self.lab2 = Label(self.step5, text='Шрифт')
        self.lab2.pack(anchor=NW)

        self.fonts = Frame(self.step5)
        self.fonts.pack(anchor=NW)

        self.lab_font = Label(self.fonts, text='Montserrat')
        self.lab_font.pack(anchor=NW)

        self.frame_entry = Frame(self.fonts)
        self.frame_entry.pack(anchor=NW, fill=X)

        self.lab_font_ = Label(self.frame_entry, text='Размер')
        self.lab_font_.pack(side=LEFT)

        self.entry_font = EntryAuto(self.frame_entry, placeholder='placeholder')
        self.entry_font.pack(side=LEFT, fill=X)

        self.entry_font.insert(END, '15')

        def OK5(e=''):
            self.steps['text'] = 'Шаг 6. Создание аккаунта'
            self.step5.pack_forget()
            self.step6.pack(anchor=NW, fill=BOTH, expand=1)

        self.okbtn = LabelButtonSystem(self.step5, font=(fontMaxOS, 15), text=' Далее ', width=15, bg=bg_tb, command=OK5)
        self.okbtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        def back4(e=''):
            self.steps['text'] = 'Шаг 4. Конфигурация панели задач'
            self.step5.pack_forget()
            self.step4.pack(anchor=NW, fill=BOTH, expand=1)

        self.backbtn = LabelButtonSystem(self.step5, font=(fontMaxOS, 15), text=' Назад ', width=15, bg=bg_tb, command=back4)
        self.backbtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        self.closebtn = LabelButtonSystem(self.step5, font=(fontMaxOS, 15), text=(' '+'Отмена'+' '), width=15, bg=bg_tb, command=self.destroy)
        self.closebtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        self.step6 = Frame(self.root1)

        LabelButtonSystem(self.step6, font=(fontMaxOS, 15), text=' Создать ', width=15, bg=bg_tb, command=OK).pack(expand=1)

        def back5(e=''):
            self.steps['text'] = 'Шаг 5. Тема и шрифт'
            self.step6.pack_forget()
            self.step5.pack(anchor=NW, fill=BOTH, expand=1)

        self.backbtn = LabelButtonSystem(self.step6, font=(fontMaxOS, 15), text=' Назад ', width=15, bg=bg_tb, command=back5)
        self.backbtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        self.closebtn = LabelButtonSystem(self.step6, font=(fontMaxOS, 15), text=(' '+'Отмена'+' '), width=15, bg=bg_tb, command=self.destroy)
        self.closebtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)


        theme_update()
        #GlobalUpdate()

        showing()
