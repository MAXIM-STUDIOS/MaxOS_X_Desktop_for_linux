from tkinter import (
                        Frame,
                        Label,
                        Toplevel,
                        BOTH,
                        Y,
                        X,
                        NW,
                        N,
                        SW,
                        S,
                        W,
                        E,
                        NE,
                        LEFT,
                        RIGHT,
                        TOP,
                        BOTTOM,
                        Menu
                    )
from customtkinter import CTkFrame, CTkSlider, CTkLabel
from PIL import Image, ImageTk, ImageColor
import sys
import time, datetime
from pathlib import Path
from Components.StartMenu import StartMenu
import os

from random import randint


import kernel
from .Libraries.SoundPlayer import PlaySound
from .Libraries.MaxOSTkinter import Separator, DialogWin, WhatDialogWin, maxOSShrt, empty, maxOSFold
from threading import Thread

import psutil
from .Exit import ExitUser
from . import RunProgram


def write_file(file, text):
    o = open(file, 'w', encoding='utf-8')
    o.write(str(text))
    o.close()

def read_file(file):
    o = open(file, 'r', encoding='utf-8')
    text = o.read()
    o.close()
    return text



class DE():
    def destroy(self):
        self.main.after_cancel(self.theme_after)
        self.tb.destroy()
        self.main.destroy()

    def __init__(self, master, sizeX, sizeY, system):
        with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','exit_user.txt',), 'w', encoding='utf-8') as f:
            f.write('False')
        PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','startup.wav'))
        self.bg_ = ''
        self.fg_ = ''
        self.list_ext = []
        for i in os.listdir(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST')):
            if i[0] != '.' or i[0] != '!':
                type = ''
                with open(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST', i,'type.txt'), 'r', encoding='utf-8') as f:
                    type = f.read()
                name = ''
                with open(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST', i,'name.txt'), 'r', encoding='utf-8') as f:
                    name = f.read()
                if i[0] != '.' or i[0] != '!':
                    if '|' in name:
                        for n in name.split('|'):
                            self.list_ext.append(n)
                    else:
                        self.list_ext.append(name)

        class Shortcut():
            def __init__(self, master, shrt, list_ext=self.list_ext, create=False):
                self.shrt = shrt
                self.master = master
                self.list_ext = list_ext

                self.homefolder = ''
                with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'r', encoding='utf-8') as hf:
                    self.homefolder = hf.read()

                if create != False:
                    os.mkdir(self.shrt)
                    write_file(Path(self.shrt, 'link.txt'), str(create['link']))
                    write_file(Path(self.shrt, 'name.txt'), str(create['name']))
                    write_file(Path(self.shrt, 'coords.txt'), str(create['coords']))

                    write_file(Path(self.shrt, 'show.txt'), 'False')

                self.link = ''
                with open(Path(self.shrt, 'link.txt'), 'r', encoding='utf-8') as f:
                    self.link = f.read()
                self.coords = ''
                with open(Path(self.shrt, 'coords.txt'), 'r', encoding='utf-8') as f:
                    self.coords = f.read()
                self.X = self.coords.split()[0]
                self.Y = self.coords.split()[1]

                self.name = ''
                with open(Path(self.shrt, 'name.txt'), 'r', encoding='utf-8') as f:
                    self.name = f.read()

                self.show = ''
                with open(Path(self.shrt, 'show.txt'), 'r', encoding='utf-8') as f:
                    self.show = f.read()

                list_disks = []
                for i in psutil.disk_partitions():
                    list_disks.append(i.mountpoint)

                if f"{Path(self.link)}" in list_disks:
                    hdd_info = ''
                    for i in psutil.disk_partitions():
                        if f"{Path(self.link)}" == i.mountpoint:
                            hdd_info = i
                    if 'cdrom' in hdd_info.opts or 'ro' in hdd_info.opts.split(',') and hdd_info.mountpoint != '/':
                        img = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','cd_dvd.png'))
                        img = img.resize((105, 105), Image.ANTIALIAS)
                        img = ImageTk.PhotoImage(img)
                        if sys.platform == 'win32':self.name = hdd_info.mountpoint
                        elif sys.platform == 'darwin':self.name = os.path.split(hdd_info.mountpoint)[1]
                        if len(self.name) > 11:
                            l2 = []
                            for i in range(len(self.name)):
                                if len(l2) <= 8:
                                    l2.append(self.name[i])

                            self.name = ''.join(l2)+"..."
                        app = maxOSShrt(self.master, text=self.name, image=img, command=lambda: RunProgram.run_program(D=Path('MaxOS','!SysPrograms'), F='MaxOS File Manager.prog', fileopen=f"{self.link}"), path=self.link, shortcut=Path(self.shrt), commandopenwhen=None, type='cdrom')
                        if self.show.lower() == 'false':
                            with open(Path(self.shrt, 'show.txt'), 'w', encoding='utf-8') as f:
                                f.write('True')
                            app.place(x=self.X, y=self.Y)
                    else:
                        img = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','HDD_ICONS','sys_hdd.png'))
                        img = img.resize((105, 105), Image.ANTIALIAS)
                        img = ImageTk.PhotoImage(img)
                        if sys.platform == 'win32':self.name = hdd_info.mountpoint
                        elif sys.platform == 'darwin':self.name = os.path.split(hdd_info.mountpoint)[1]
                        if hdd_info.mountpoint == '/':
                            self.name = 'Macintosh HD'
                        if len(self.name) > 11:
                            l2 = []
                            for i in range(len(self.name)):
                                if len(l2) <= 8:
                                    l2.append(self.name[i])

                            self.name = ''.join(l2)+"..."
                        app = maxOSShrt(self.master, text=self.name, image=img, command=lambda: RunProgram.run_program(D=Path('MaxOS','!SysPrograms'), F='MaxOS File Manager.prog', fileopen=f"{self.link}"), path=self.link, shortcut=Path(self.shrt), commandopenwhen=None, type='hdd')
                        if self.show.lower() == 'false':
                            with open(Path(self.shrt, 'show.txt'), 'w', encoding='utf-8') as f:
                                f.write('True')
                            app.place(x=self.X, y=self.Y)
                else:
                    if os.path.isdir(self.link):
                        if os.path.splitext(self.link)[1].lower() == '.prog' or os.path.splitext(self.link)[1].lower() == '.prg':
                            if os.path.isfile(Path(self.link,'icon.png')):
                                img = Image.open(Path(self.link,'icon.png'))
                                img = img.resize((105, 105), Image.ANTIALIAS)
                                img = ImageTk.PhotoImage(img)
                            else:
                                img = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','NoImage.png'))
                                img = img.resize((105, 105), Image.ANTIALIAS)
                                img = ImageTk.PhotoImage(img)

                            if len(self.name) > 11:
                                l2 = []
                                for i in range(len(self.name)):
                                    if len(l2) <= 8:
                                        l2.append(self.name[i])

                                self.name = ''.join(l2)+"..."
                            app = maxOSShrt(self.master, text=self.name, image=img, command=lambda: RunProgram.run_program(D=os.path.split(self.link)[0], F=os.path.split(self.link)[1]), path=self.link, shortcut=Path(self.shrt), commandopenwhen=None)
                            if self.show.lower() == 'false':
                                with open(Path(self.shrt, 'show.txt'), 'w', encoding='utf-8') as f:
                                    f.write('True')
                                app.place(x=self.X, y=self.Y)
                        else:
                            if self.link == '.':
                                img = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SystemFolder.png'))
                                img = img.resize((105, 105), Image.ANTIALIAS)
                                img = ImageTk.PhotoImage(img)

                                if len(self.name) > 11:
                                    l2 = []
                                    for i in range(len(self.name)):
                                        if len(l2) <= 8:
                                            l2.append(self.name[i])

                                    self.name = ''.join(l2)+"..."
                                app = maxOSShrt(self.master, text=self.name, image=img, command=lambda: RunProgram.run_program(D=Path('MaxOS','!SysPrograms'), F='MaxOS File Manager.prog', fileopen=self.link), path=self.link, shortcut=Path(self.shrt), commandopenwhen=None)
                                if self.show.lower() == 'false':
                                    with open(Path(self.shrt, 'show.txt'), 'w', encoding='utf-8') as f:
                                        f.write('True')
                                    app.place(x=self.X, y=self.Y)
                            else:
                                if len(self.name) > 11:
                                    l2 = []
                                    for i in range(len(self.name)):
                                        if len(l2) <= 8:
                                            l2.append(self.name[i])

                                    self.name = ''.join(l2)+"..."

                                app = maxOSFold(self.master, text=self.name, command=lambda: RunProgram.run_program(D=Path('MaxOS','!SysPrograms'), F='MaxOS File Manager.prog', fileopen=self.link), path=self.link, shortcut=Path(self.shrt), commandopenwhen=None)
                                if self.show.lower() == 'false':
                                    with open(Path(self.shrt, 'show.txt'), 'w', encoding='utf-8') as f:
                                        f.write('True')
                                    app.place(x=self.X, y=self.Y)
                    else:
                        if os.path.splitext(self.link)[1].lower() in self.list_ext:
                            self.type = ''
                            self.icon_file = ''
                            self.cmd = ''
                            for n in os.listdir(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST')):
                                name = ''
                                with open(Path('MaxOS', '!Registry', 'SYSTEM', 'SYSTEM_EXT_LIST', n,'name.txt'), 'r', encoding='utf-8') as f:
                                    name = f.read()
                                if os.path.splitext(self.link)[1].lower() == name:
                                    program_open = ''
                                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_EXT_LIST',n, 'open_in_program.txt'), 'r', encoding='utf-8') as f:
                                        program_open = f.read()
                                    self.cmd = lambda: RunProgram.run_program(D=os.path.split(program_open)[0], F=os.path.split(program_open)[1], fileopen=self.link)

                                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_EXT_LIST',n, 'type.txt'), 'r', encoding='utf-8') as f:
                                        self.type = f.read()

                                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_EXT_LIST',n, 'icon_file.txt'), 'r', encoding='utf-8') as f:
                                        self.icon_file = f.read()

                                    self.current_ext = n



                            if self.type == 'image':
                                try:
                                    image1 = Image.open(self.link)
                                    if image1.size[0] > image1.size[1]:
                                        image2 = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'))
                                        image2 = image2.resize((image1.size[0], image1.size[0]), Image.ANTIALIAS)
                                    elif image1.size[0] < image1.size[1]:
                                        image2 = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'))
                                        image2 = image2.resize((image1.size[1], image1.size[1]), Image.ANTIALIAS)
                                    else:
                                        image2 = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'))
                                        image2 = image2.resize((image1.size[0], image1.size[0]), Image.ANTIALIAS)
                                    image2.paste(image1, (0, 0))

                                    image2 = image2.resize((105, 105), Image.ANTIALIAS)

                                    img = ImageTk.PhotoImage(image2)
                                except:
                                    try:
                                        img = Image.open(self.icon_file)
                                        img = img.resize((105, 105), Image.ANTIALIAS)
                                        img = ImageTk.PhotoImage(img)
                                    except:
                                        img = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','NoImage.png'))
                                        img = img.resize((105, 105), Image.ANTIALIAS)
                                        img = ImageTk.PhotoImage(img)
                            else:
                                try:
                                    img = Image.open(self.icon_file)
                                    img = img.resize((105, 105), Image.ANTIALIAS)
                                    img = ImageTk.PhotoImage(img)
                                except:
                                    img = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','NoImage.png'))
                                    img = img.resize((105, 105), Image.ANTIALIAS)
                                    img = ImageTk.PhotoImage(img)

                            if len(self.name) > 11:
                                l2 = []
                                for i in range(len(self.name)):
                                    if len(l2) <= 8:
                                        l2.append(self.name[i])

                                self.name = ''.join(l2)+"..."
                            app = maxOSShrt(self.master, text=self.name, image=img, command=self.cmd, path=self.link, shortcut=Path(self.shrt), commandopenwhen=True, type=self.current_ext)
                            if self.show.lower() == 'false':
                                with open(Path(self.shrt, 'show.txt'), 'w', encoding='utf-8') as f:
                                    f.write('True')
                                app.place(x=self.X, y=self.Y)

        def create_shortcuts():
            homefolder = ''
            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'r', encoding='utf-8') as hf:
                homefolder = hf.read()

            for i in os.listdir(Path(homefolder,'!Desktop')):
                if os.path.isdir(Path(homefolder,'!Desktop',i)):
                    if i[0] != '!' or i[0] != '.':
                        Shortcut(master=self.maindesktop, shrt=Path(homefolder,'!Desktop',i))



        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            homefolder = ''

            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','registry_path.txt'), 'r', encoding='utf-8') as hf:
                homefolder = hf.read()

            with open(Path(homefolder,'SAVING','SYSTEM_THEME','change_theme.txt'), 'r', encoding='utf-8') as f:
                if f.read().lower() == 'true':
                    with open(Path(homefolder,'SAVING','SYSTEM_THEME','change_theme.txt'), 'w', encoding='utf-8') as f2:
                        f2.write('False')


                    with open(Path(homefolder.upper(),'SAVING','SYSTEM_THEME','COLORS','bg_tb.txt'), 'r', encoding='utf-8') as clr:
                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'w', encoding='utf-8') as f3:
                            f3.write(clr.read())

                    with open(Path(homefolder.upper(),'SAVING','SYSTEM_THEME','COLORS','fg_tb.txt'), 'r', encoding='utf-8') as clr:
                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'w', encoding='utf-8') as f3:
                            f3.write(clr.read())

                    with open(Path(homefolder.upper(),'SAVING','SYSTEM_THEME','FONTS','standart_font.txt'), 'r', encoding='utf-8') as clr:
                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'w', encoding='utf-8') as f3:
                            f3.write(clr.read())

                    with open(Path(homefolder.upper(),'SAVING','SYSTEM_THEME','FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as clr:
                        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'w', encoding='utf-8') as f3:
                            f3.write(clr.read())



            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            self.theme_after = self.main.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            self.tb_main01.configure(fg_color=bg_color)
            self.tb_main1['bg'] = bg_color

            self.btnstart['bg'] = bg_color
            self.btn2['bg'] = bg_color
            self.btn3['bg'] = bg_color
            self.btn4['bg'] = bg_color
            self.btnUser['bg'] = bg_color

            self.btn_battery['bg'] = bg_color

            self.tb_main02.configure(fg_color=bg_color)
            self.tb_main2['bg'] = bg_color

            self.date['bg'] = bg_color

            self.watch['bg'] = bg_color
            self.date1['bg'] = bg_color
            self.date2['bg'] = bg_color

            self.watch['fg'] = fg_color
            self.date1['fg'] = fg_color
            self.date2['fg'] = fg_color

            self.watch['font'] = (font_, font_size+20)
            self.date1['font'] = (font_, font_size)
            self.date2['font'] = (font_, font_size)

            self.UserIcon = Image.open(Path('MaxOS','!Registry','USERS','USERS_ICONS',f"{os.path.split(homefolder)[1]}.png"))
            self.UserIcon = self.UserIcon.resize((40, 40), Image.ANTIALIAS)
            self.UserIcon = ImageTk.PhotoImage(self.UserIcon)

            self.btnUser.image = self.UserIcon
            self.btnUser['image'] = self.btnUser.image

            self.btn_sound['bg'] = bg_color



            tb = ''
            with open(Path(homefolder,'SAVING','TASKBAR_CONFIG','tb_config.txt'), 'r', encoding='utf-8') as hf:
                tb = hf.read()
            '''
            if tb.lower() == 'false':
                self.tb_main01.pack_forget()
                self.tb_main02.pack_forget()
            else:
                if tb == 'top':
                    self.tb_main01.pack(anchor=W, padx=20, pady=20, side=TOP)
                    self.tb_main02.pack(anchor=S, padx=20, pady=20, side=RIGHT)
                elif tb == 'bottom':
                    self.tb_main01.pack(anchor=W, padx=20, pady=20, side=BOTTOM)
                    self.tb_main02.pack(anchor=N, padx=20, pady=20, side=RIGHT)
            '''
            self.bg_ = bg_color
            self.fg_ = fg_color
            self.font_ = font_
            self.font_size = font_size
            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)
            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

            self.selectbg_ = selectbg



        def GlobalUpdate():
            self.global_after = self.main.after(100, GlobalUpdate)

            with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','registry_path.txt'), 'r', encoding='utf-8') as hf:
                homefolder = hf.read()
            tb = ''
            with open(Path(homefolder,'SAVING','TASKBAR_CONFIG','tb_config.txt'), 'r', encoding='utf-8') as hf:
                tb = hf.read()

            if tb.lower() == 'false':
                self.tb_main01.pack_forget()
                self.tb_main02.pack_forget()
            else:
                if tb == 'top':
                    self.tb_main01.pack(anchor=W, padx=20, pady=20, side=TOP)
                    self.tb_main02.pack(anchor=S, padx=20, pady=20, side=RIGHT)
                elif tb == 'bottom':
                    self.tb_main01.pack(anchor=W, padx=20, pady=20, side=BOTTOM)
                    self.tb_main02.pack(anchor=N, padx=20, pady=20, side=RIGHT)




            with open(Path(homefolder,'SAVING','DESKTOP_CONFIG','image_desktop.txt'), 'r', encoding='utf-8') as f:
                if f.read().lower() == 'true':
                    self.image_desktop.place(x=0,y=0)
                else:
                    with open(Path(homefolder,'SAVING','DESKTOP_CONFIG','bg_desktop.txt'), 'r', encoding='utf-8') as bg:
                        with open(Path(homefolder,'SAVING','DESKTOP_CONFIG','image_desktop_change.txt'), 'r', encoding='utf-8') as f2:
                            if f2.read().lower() == 'true':
                                with open(Path(homefolder,'SAVING','DESKTOP_CONFIG','image_desktop_change.txt'), 'w', encoding='utf-8') as f3:
                                    f3.write('False')
                                bg_r = bg.read()
                                def color_img(img, color):
                                    img = Image.open(img)
                                    pixdata = img.load()
                                    r, g, b, = ImageColor.getcolor(color, "RGB")
                                    for y in range(img.size[1]):
                                        for x in range(img.size[0]):
                                            alpha = pixdata[x, y][3]
                                            if alpha:
                                                pixdata[x, y] = (r, g, b, alpha)
                                    return img
                                self.img = color_img(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','BG_Desktop.png'), color=bg_r)
                                self.img = self.img.resize((sizeX, sizeY), Image.ANTIALIAS)
                                self.img = ImageTk.PhotoImage(self.img)
                                self.image_desktop.image = self.img
                                self.image_desktop['image'] = self.image_desktop.image


            with open(Path(homefolder,'SAVING','DESKTOP_CONFIG','image_desktop_change.txt'), 'r', encoding='utf-8') as f:
                if f.read().lower() == 'true':
                    with open(Path(homefolder,'SAVING','DESKTOP_CONFIG','image_desktop_change.txt'), 'w', encoding='utf-8') as f2:
                        f2.write('False')
                    self.img = Image.open(Path(homefolder,'SAVING','DESKTOP_CONFIG','ImageDesktop.png'))
                    self.img = self.img.resize((sizeX, sizeY), Image.ANTIALIAS)
                    self.img = ImageTk.PhotoImage(self.img)
                    self.image_desktop.image = self.img
                    self.image_desktop['image'] = self.image_desktop.image

            def check_disks(e=''):
                disklist1 = []
                for i in psutil.disk_partitions():
                    disklist1.append(i.device)
                time.sleep(0.1)
                disklist2 = []
                for i in psutil.disk_partitions():
                    disklist2.append(i.device)

                if len(disklist2) > len(disklist1):
                    PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','HDD Insert.wav'))
                elif len(disklist2) < len(disklist1):
                    PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','HDD Out.wav'))
            Thread(target=check_disks, daemon=1).start()

            def check_shortcuts(e=''):
                homefolder = ''
                with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'r', encoding='utf-8') as hf:
                    homefolder = hf.read()

                true = read_file(Path('MaxOS','!Registry','SYSTEM','SYSTEM_DE','CREATE_SHORTCUT','create_state.txt'))

                if true.lower() == 'true':
                    write_file(Path('MaxOS','!Registry','SYSTEM','SYSTEM_DE','CREATE_SHORTCUT','create_state.txt'), 'False')
                    name = read_file(Path('MaxOS','!Registry','SYSTEM','SYSTEM_DE','CREATE_SHORTCUT','name.txt'))
                    link = read_file(Path('MaxOS','!Registry','SYSTEM','SYSTEM_DE','CREATE_SHORTCUT','link.txt'))
                    coords = read_file(Path('MaxOS','!Registry','SYSTEM','SYSTEM_DE','CREATE_SHORTCUT','coords.txt'))
                    info = {
                    'name'   : name,
                    'link'   : link,
                    'coords' : coords
                    }

                    if link == 'MS160722':
                        Shortcut(master=self.maindesktop, shrt=Path(homefolder,'!Desktop',f"MaxOS_System_{randint(9999, 99999)}.shrt"), create=info)
                    else:
                        Shortcut(master=self.maindesktop, shrt=Path(homefolder,'!Desktop',f"{os.path.split(link)[1]}_{randint(9999, 99999)}.shrt"), create=info)

                    write_file(Path('MaxOS','!Registry','SYSTEM','SYSTEM_DE','CREATE_SHORTCUT','name.txt'), '')
                    write_file(Path('MaxOS','!Registry','SYSTEM','SYSTEM_DE','CREATE_SHORTCUT','link.txt'), '')
                    write_file(Path('MaxOS','!Registry','SYSTEM','SYSTEM_DE','CREATE_SHORTCUT','coords.txt'), '')

            #Thread(target=check_shortcuts, daemon=1).start()
            check_shortcuts()

            def check_battery(e=''):
                if psutil.sensors_battery() != None:
                    battery = psutil.sensors_battery()
                    percent = int(battery.percent)
                    power = battery.power_plugged
                    if power:
                        if percent == 100 and percent > 90:
                            #print(10)
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','BATTERY_POWER','10.png'))
                        elif percent < 100 and percent >= 90:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','BATTERY_POWER','9.png'))
                            #print(9)
                        elif percent < 90 and percent < 100 and percent >= 80:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','BATTERY_POWER','8.png'))
                            #print(8)
                        elif percent < 80 and percent < 100 and percent < 90 and percent >= 70:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','BATTERY_POWER','7.png'))
                            #print(7)
                        elif percent < 70 and percent < 100 and percent < 90 and percent < 80 and percent >= 60:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','BATTERY_POWER','6.png'))
                            #print(6)
                        elif percent < 60 and percent != 100 and percent < 100 and percent < 90 and percent < 80 and percent < 70 and percent >= 50:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','BATTERY_POWER','5.png'))
                            #print(5)
                        elif percent < 50 and percent != 100 and percent < 100 and percent < 90 and percent < 80 and percent < 70 and percent < 60 and percent >= 40:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','BATTERY_POWER','4.png'))
                            #print(4)
                        elif percent < 40 and percent != 100 and percent < 100 and percent < 90 and percent < 80 and percent < 70 and percent < 60 and percent < 50 and percent >= 30:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','BATTERY_POWER','3.png'))
                            #print(3)
                        elif percent < 30 and percent != 100 and percent < 100 and percent < 90 and percent < 80 and percent < 70 and percent < 60 and percent < 50 and percent < 40 and percent >= 20:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','BATTERY_POWER','2.png'))
                            #print(2)
                        elif percent < 20 and percent != 100 and percent < 100 and percent < 90 and percent < 80 and percent < 70 and percent < 60 and percent < 50 and percent < 40 and percent < 30 and percent >= 10:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','BATTERY_POWER','1.png'))
                            #print(1)
                        elif percent < 10 and percent != 100 and percent < 100 and percent < 90 and percent < 80 and percent < 70 and percent < 60 and percent < 50 and percent < 40 and percent < 30 and percent < 20:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','BATTERY_POWER','0.png'))
                            #print(0)
                    else:
                        if percent == 100 and percent > 90:
                            #print(10)
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','10.png'))
                        elif percent < 100 and percent >= 90:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','9.png'))
                            #print(9)
                        elif percent < 90 and percent < 100 and percent >= 80:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','8.png'))
                            #print(8)
                        elif percent < 80 and percent < 100 and percent < 90 and percent >= 70:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','7.png'))
                            #print(7)
                        elif percent < 70 and percent < 100 and percent < 90 and percent < 80 and percent >= 60:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','6.png'))
                            #print(6)
                        elif percent < 60 and percent != 100 and percent < 100 and percent < 90 and percent < 80 and percent < 70 and percent >= 50:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','5.png'))
                            #print(5)
                        elif percent < 50 and percent != 100 and percent < 100 and percent < 90 and percent < 80 and percent < 70 and percent < 60 and percent >= 40:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','4.png'))
                            #print(4)
                        elif percent < 40 and percent != 100 and percent < 100 and percent < 90 and percent < 80 and percent < 70 and percent < 60 and percent < 50 and percent >= 30:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','3.png'))
                            #print(3)
                        elif percent < 30 and percent != 100 and percent < 100 and percent < 90 and percent < 80 and percent < 70 and percent < 60 and percent < 50 and percent < 40 and percent >= 20:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','2.png'))
                            #print(2)
                        elif percent < 20 and percent != 100 and percent < 100 and percent < 90 and percent < 80 and percent < 70 and percent < 60 and percent < 50 and percent < 40 and percent < 30 and percent >= 10:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','1.png'))
                            #print(1)
                        elif percent < 10 and percent != 100 and percent < 100 and percent < 90 and percent < 80 and percent < 70 and percent < 60 and percent < 50 and percent < 40 and percent < 30 and percent < 20:
                            self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','0.png'))
                            #print(0)


                    self.BatteryState = self.BatteryState.resize((25, 25), Image.ANTIALIAS)
                    self.BatteryState = ImageTk.PhotoImage(self.BatteryState)

                    self.btn_battery.image = self.BatteryState
                    self.btn_battery['image'] = self.btn_battery.image
            check_battery()


            def check_sound(e=''):
                volume = ''
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_OUTPUT','AUDIO_OUTPUT','volume.txt'), 'r', encoding='utf-8') as f:
                    volume = int(f.read())

                if volume >= 75:
                    self.SoundState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SOUND','3.png'))
                elif volume >= 50:
                    self.SoundState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SOUND','2.png'))
                elif volume >= 25:
                    self.SoundState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SOUND','1.png'))
                elif volume > 0:
                    self.SoundState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SOUND','0.png'))
                elif volume == 0:
                    self.SoundState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SOUND','off.png'))

                self.SoundState = self.SoundState.resize((25, 25), Image.ANTIALIAS)
                self.SoundState = ImageTk.PhotoImage(self.SoundState)

                self.btn_sound.image = self.SoundState
                self.btn_sound['image'] = self.btn_sound.image
            check_sound()





        self.sizeX = sizeX
        self.sizeY = sizeY
        self.system = system


        self.main = Frame(master, bg='black')
        self.main.pack(fill=BOTH, expand=1)

        homefolder = ''
        with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','registry_path.txt'), 'r', encoding='utf-8') as hf:
            homefolder = hf.read()

        with open(Path(homefolder.upper(),'SAVING','SYSTEM_THEME','COLORS','bg_tb.txt'), 'r', encoding='utf-8') as clr:
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'w', encoding='utf-8') as f3:
                f3.write(clr.read())

        with open(Path(homefolder.upper(),'SAVING','SYSTEM_THEME','COLORS','fg_tb.txt'), 'r', encoding='utf-8') as clr:
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'w', encoding='utf-8') as f3:
                f3.write(clr.read())

        with open(Path(homefolder.upper(),'SAVING','SYSTEM_THEME','FONTS','standart_font.txt'), 'r', encoding='utf-8') as clr:
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'w', encoding='utf-8') as f3:
                f3.write(clr.read())

        with open(Path(homefolder.upper(),'SAVING','SYSTEM_THEME','FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as clr:
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'w', encoding='utf-8') as f3:
                f3.write(clr.read())

        self.img = Image.open(Path(homefolder,'SAVING','DESKTOP_CONFIG','ImageDesktop.png'))
        self.img = self.img.resize((sizeX, sizeY), Image.ANTIALIAS)
        self.img = ImageTk.PhotoImage(self.img)

        with open(Path(homefolder,'SAVING','DESKTOP_CONFIG','image_desktop_change.txt'), 'w', encoding='utf-8') as f3:
            f3.write('True')

        self.maindesktop = Frame(self.main, bg='black', width=5000, height=5000)
        self.maindesktop.place(x=0, y=0)

        if sys.platform == "win32":
            self.tb = Toplevel()
            self.tb.wm_attributes('-fullscreen',1)
            self.tb.wm_attributes('-topmost',1)
            self.tb.wm_attributes("-transparentcolor", '#123456')
            self.tb['bg'] = '#123456'
            self.tb.wm_attributes('-alpha', 0.7)
            self.tb['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        else:
            self.tb = self.main


        self.tb_main01 = CTkFrame(self.tb, fg_color='#EFFBFF', corner_radius=15)
        self.tb_main01.pack(anchor=W, padx=20, pady=20, side=TOP)

        self.tb_main1 = Frame(self.tb_main01, bg='#EFFBFF')
        self.tb_main1.pack(anchor=NW, padx=5, pady=5)

        MSOS_ico = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','MSOS_ico.png'))
        MSOS_ico = MSOS_ico.resize((50, 50), Image.ANTIALIAS)
        MSOS_ico = ImageTk.PhotoImage(MSOS_ico)

        MSOS_ico_light = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','MSOS_ico_light.png'))
        MSOS_ico_light = MSOS_ico_light.resize((50, 50), Image.ANTIALIAS)
        MSOS_ico_light = ImageTk.PhotoImage(MSOS_ico_light)

        FM_Icon = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','FM_icon.png'))
        FM_Icon = FM_Icon.resize((25, 25), Image.ANTIALIAS)
        FM_Icon = ImageTk.PhotoImage(FM_Icon)

        Terminal = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','Terminal.png'))
        Terminal = Terminal.resize((25, 25), Image.ANTIALIAS)
        Terminal = ImageTk.PhotoImage(Terminal)

        Trash = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','Trash.png'))
        Trash = Trash.resize((25, 25), Image.ANTIALIAS)
        Trash = ImageTk.PhotoImage(Trash)

        self.UserIcon = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','UserIcon.png'))
        self.UserIcon = self.UserIcon.resize((40, 40), Image.ANTIALIAS)
        self.UserIcon = ImageTk.PhotoImage(self.UserIcon)

        self.BatteryState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BATTERY','10.png'))
        self.BatteryState = self.BatteryState.resize((25, 25), Image.ANTIALIAS)
        self.BatteryState = ImageTk.PhotoImage(self.BatteryState)

        self.SoundState = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','SOUND','3.png'))
        self.SoundState = self.SoundState.resize((25, 25), Image.ANTIALIAS)
        self.SoundState = ImageTk.PhotoImage(self.SoundState)

        self.state_sound = 0
        self.sound = ''

        self.NoActiveState = 1
        self.SelectState = 0
        self.btnstart = Label(self.tb_main1, bg='#EFFBFF', cursor='hand1')
        self.btnstart.image = MSOS_ico
        self.btnstart['image'] = self.btnstart.image
        self.btnstart.pack(padx=2, pady=2, side=LEFT)

        def hover_btn_start(e=''):
            self.btnstart.image = MSOS_ico_light
            self.btnstart['image'] = self.btnstart.image
            self.SelectState = 1
            self.btnstart['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur"
        def leave_btn_start(e=''):
            if self.NoActiveState:
                self.btnstart.image = MSOS_ico
                self.btnstart['image'] = self.btnstart.image
            self.btnstart['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
            self.SelectState = 0

        def start(e=''):
            if self.state_sound:
                self.sound.destroy()
                self.state_sound = 0
            self.Start_Menu = StartMenu(self.tb, sizeX, sizeY, system, self.main)
            def stop(e=''):
                if self.SelectState:
                    self.NoActiveState = 1
                    self.btnstart.bind('<ButtonRelease-1>', start)
                    self.Start_Menu.stop()
                    PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','start.wav'))
            if self.SelectState:
                self.NoActiveState = 0
                self.btnstart.image = MSOS_ico_light
                self.btnstart['image'] = self.btnstart.image
                self.btnstart.bind('<ButtonRelease-1>', stop)
                self.Start_Menu.start()
                PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','start.wav'))

        self.btnstart.bind("<Enter>", hover_btn_start)
        self.btnstart.bind("<Leave>", leave_btn_start)
        self.btnstart.bind('<ButtonRelease-1>', start)

        Separator(self.tb_main1, orient='vertical')

        self.btn2 = Label(self.tb_main1, bg='#EFFBFF')
        self.btn2.image = FM_Icon
        self.btn2['image'] = self.btn2.image
        self.btn2.pack(padx=2, pady=2, side=LEFT)

        self.btn3 = Label(self.tb_main1, bg='#EFFBFF')
        self.btn3.image = Terminal
        self.btn3['image'] = self.btn3.image
        self.btn3.pack(padx=2, pady=2, side=LEFT)

        self.btn4 = Label(self.tb_main1, bg='#EFFBFF')
        self.btn4.image = Trash
        self.btn4['image'] = self.btn4.image
        self.btn4.pack(padx=2, pady=2, side=LEFT)

        self.btn_battery = Label(self.tb_main1, bg='#EFFBFF')
        if psutil.sensors_battery() != None:
            self.btn_battery.image = self.BatteryState
            self.btn_battery['image'] = self.btn_battery.image
            self.btn_battery.pack(padx=2, pady=2, side=LEFT)

        class SoundVoume():
            def destroy(self):
                self.main.after_cancel(self.theme_after)
                self.main.destroy()
            def __init__(self, mastertk, tb=self.tb_main01):

                volume = ''
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_OUTPUT','AUDIO_OUTPUT','volume.txt'), 'r', encoding='utf-8') as f:
                    volume = int(f.read())

                def theme_update():
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    registry_path = ''
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())
                    with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','registry_path.txt'), 'r', encoding='utf-8') as hf:
                        registry_path = hf.read()
                    self.theme_after = self.main.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())

                    self.bg_ = bg_color
                    self.fg_ = fg_color
                    self.font_ = font_
                    self.font_size = font_size

                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)

                    color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                        color_rgb_activebackground[0] = 0
                    else:
                        color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

                    if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                        color_rgb_activebackground[1] = 0
                    else:
                        color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

                    if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                        color_rgb_activebackground[2] = 0
                    else:
                        color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

                    activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

                    self.selectbg_ = selectbg

                    self.main.configure(fg_color=bg_color)

                    self.percent['bg'] = bg_color
                    self.percent['fg'] = fg_color
                    self.percent['font'] = (font_, font_size+5, 'bold')

                    self.slider.configure(fg_color=selectbg)
                    self.slider.configure(progress_color=activebackground)
                    self.slider.configure(button_color=activebackground)
                    self.slider.configure(button_hover_color=selectbg)

                    self.lab.configure(fg_color=bg_color)

                self.main = CTkFrame(mastertk, fg_color='#EFFBFF', corner_radius=15, width=tb.winfo_width())
                def change_volume(e=''):
                    self.percent['text'] = f"Громкость: {int(self.slider.get())} %"
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_OUTPUT','AUDIO_OUTPUT','volume.txt'), 'w', encoding='utf-8') as f:
                        f.write(str(int(self.slider.get())))
                def check_sound(e=''):
                    PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','power_off.wav'))
                self.percent = Label(self.main, text=f"Громкость: {volume} %")
                self.percent.pack(anchor=NW, padx=5, pady=5)
                self.slider = CTkSlider(self.main, from_=0, to=100, command=change_volume, width=tb.winfo_width(), corner_radius=360, cursor='none')
                self.slider.pack(anchor=NW, padx=5, pady=5, fill=X)
                self.slider.bind('<ButtonRelease-1>', check_sound)
                self.slider.set(volume)

                self.lab = CTkLabel(self.main, corner_radius=25, text='')
                self.lab.pack(anchor=NW, padx=10)

                tb = ''
                with open(Path(homefolder,'SAVING','TASKBAR_CONFIG','tb_config.txt'), 'r', encoding='utf-8') as hf:
                    tb = hf.read()

                if tb == 'top':
                    self.main.pack(anchor=W, padx=20, pady=0, side=TOP)
                elif tb == 'bottom':
                    self.main.pack(anchor=W, padx=20, pady=0, side=BOTTOM)

                theme_update()


        self.btn_sound = Label(self.tb_main1, bg='#EFFBFF', cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
        self.btn_sound.image = self.SoundState
        self.btn_sound['image'] = self.btn_sound.image
        self.btn_sound.pack(padx=2, pady=2, side=LEFT)
        def sound1(e=''):
            if self.NoActiveState == 0:
                self.NoActiveState = 1
                self.btnstart.bind('<ButtonRelease-1>', start)
                self.Start_Menu.stop()
            PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','start.wav'))
            if self.state_sound == 0:
                self.sound = SoundVoume(mastertk=self.tb)
                self.state_sound = 1
            else:
                if self.state_sound:
                    self.sound.destroy()
                self.state_sound = 0
        self.btn_sound.bind('<Button-1>', sound1)

        Separator(self.tb_main1, orient='vertical')

        def LOGOUT(e=''):
            def Ok(e=''):
                ExitUser(self.main, self.tb, self.sizeX, self.sizeY, sys.platform)
            w = WhatDialogWin(self.main, title='Выйти', text='Вы точно хотите выйти?', textyes='Да', textno='Отмена', command=Ok, type='warning')

        self.btnUser = Label(self.tb_main1, bg='#EFFBFF', cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
        self.btnUser.image = self.UserIcon
        self.btnUser['image'] = self.btnUser.image
        self.btnUser.pack(padx=2, pady=2, side=LEFT)

        def menuusr(e):
            menu = Menu(background=self.bg_, foreground=self.fg_, relief='flat', cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur", tearoff=0, bd=0, font=(self.font_, self.font_size), activebackground=self.selectbg_, activeforeground=self.fg_)

            imagelogout = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','BUTTONS','LOGOUT_BTN','normal.png'))
            imagelogout = imagelogout.resize((20, 20), Image.ANTIALIAS)
            imagelogout = ImageTk.PhotoImage(imagelogout)

            menu.add_command(label='Выйти', command=LOGOUT, image=imagelogout, compound=LEFT)

            menu.post(x=e.x_root, y=e.y_root)

        self.btnUser.bind('<Double-Button-1>', menuusr)

        self.tb_main02 = CTkFrame(self.tb, fg_color='#EFFBFF', corner_radius=15)
        self.tb_main02.pack(anchor=S, padx=20, pady=20, side=RIGHT)

        self.tb_main2 = Frame(self.tb_main02, bg='#EFFBFF')
        self.tb_main2.pack(anchor=NW, padx=5, pady=5)

        def tick_watch():
            self.watch.after(1000, tick_watch)
            self.watch['text'] = time.strftime('%H:%M')#%S

        self.watch = Label(self.tb_main2, bg='#EFFBFF', font=('Montserrat', 35), fg='black', text='12:00')
        self.watch.pack(padx=2, pady=2, side=LEFT)

        tick_watch()

        Separator(self.tb_main2, orient='vertical')


        def date_tick():
            a = time.strftime("%a")
            if a == 'Mon':a = "Понедельник"
            elif a == 'Tue':a = "Вторник"
            elif a == 'Wed':a = "Среда"
            elif a == 'Thu':a = "Четверг"
            elif a == 'Fri':a = "Пятница"
            elif a == 'Sat':a = "Суббота"
            elif a == 'Sun':a = "Воскресенье"
            dt = datetime.datetime.now()
            dt_string = dt.strftime("%d/%m/%Y")
            b = a + dt_string
            self.date1['text'] = a
            self.date2['text'] = dt_string
            self.date.after(100, date_tick)

        self.date = Frame(self.tb_main2, bg='#EFFBFF')
        self.date.pack(padx=2, pady=2, side=LEFT, expand=1)

        self.date1 = Label(self.date, bg='#EFFBFF', font=('Montserrat', 15), fg='black', text='Суббота')
        self.date1.pack(padx=2, pady=2, expand=1)
        Separator(self.date, orient='horizontal')
        self.date2 = Label(self.date, bg='#EFFBFF', font=('Montserrat', 15), fg='black', text='16/07/2022')
        self.date2.pack(padx=2, pady=2, expand=1)
        date_tick()

        self.image_desktop = Label(self.maindesktop, bg='black')
        self.image_desktop.image = self.img
        self.image_desktop.place(x=0,y=0)
        self.image_desktop['image'] = self.image_desktop.image

        theme_update()
        create_shortcuts()
        GlobalUpdate()
