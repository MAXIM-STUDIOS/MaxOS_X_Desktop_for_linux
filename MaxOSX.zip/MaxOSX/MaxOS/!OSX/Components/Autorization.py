from tkinter import (
                        Frame,
                        Label,
                        Toplevel,
                        BOTH,
                        Y,
                        X,
                        NW,
                        N,
                        SW,
                        S,
                        W,
                        E,
                        NE,
                        LEFT,
                        RIGHT,
                        TOP,
                        BOTTOM
                    )
from customtkinter import CTkFrame, CTkScrollableFrame
from PIL import Image, ImageTk, ImageColor
import sys
import time, datetime
from pathlib import Path
import os
import shutil


import kernel
from .Libraries.SoundPlayer import PlaySound
from .Libraries.MaxOSTkinter import Separator, BUTTON_MENU, ListButton, MaxOSTk, MaxOSTk2, Entry2, EntryAuto, LabelButtonSystem, DialogWin, WhatDialogWin, WebCamDialogWin
from .Libraries.Avatar import avatar
from .Libraries.MaxOSCode import ConvertToMaxOSCode, ConverFromMaxOSCode
from threading import Thread
from .DE import DE
from .Shutdown import Shutdown
from .Enter import EnterUser
from .Autorization__create_user import create_user
from . import RunProgram

def empty(*args, **kwargs):pass




class Autorization():
    def destroy(self):
        self.main.after_cancel(self.theme_after)
        self.tb.destroy()
        self.main.destroy()

    def __init__(self, master, sizeX, sizeY, system):
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'w', encoding='utf-8') as bg:
            bg.write('#333533')
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'w', encoding='utf-8') as fg:
            fg.write('#ffffff')
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'w', encoding='utf-8') as f:
            f.write('Montserrat')
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'w', encoding='utf-8') as fs:
            fs.write('15')

        with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','exit_user.txt',), 'w', encoding='utf-8') as f:
            f.write('True')

        self.master = master
        def theme_update():
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())
            self.theme_after = self.main.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            self.tb_main01.configure(fg_color=bg_color)
            self.tb_main1['bg'] = bg_color

            self.date['bg'] = bg_color

            self.watch['bg'] = bg_color
            self.date1['bg'] = bg_color
            self.date2['bg'] = bg_color

            self.watch['fg'] = fg_color
            self.date1['fg'] = fg_color
            self.date2['fg'] = fg_color

            self.watch['font'] = (font_, font_size+20)
            self.date1['font'] = (font_, font_size)
            self.date2['font'] = (font_, font_size)

            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)

            color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                color_rgb_activebackground[0] = 0
            else:
                color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

            if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                color_rgb_activebackground[1] = 0
            else:
                color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

            if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                color_rgb_activebackground[2] = 0
            else:
                color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

            activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])


            self.FramesUsers.configure(fg_color=bg_color)
            self.FramesUsers.configure(scrollbar_fg_color=bg_color)
            self.FramesUsers.configure(scrollbar_button_color=bg_color)
            self.FramesUsers.configure(scrollbar_button_hover_color=selectbg)

        self.users_list = {}
        for i in os.listdir(Path('MaxOS','!registry','USERS','LIST_USERS')):
            if i[0] == '.' or i[0] == '_':
                pass
            else:
                name = ''
                with open(Path('MaxOS','!registry','USERS','LIST_USERS',i,'USER_NAME','user.txt'), 'r', encoding='utf-8') as f:
                    name = f.read()
                password = ''
                with open(Path('MaxOS','!registry','USERS','LIST_USERS',i,'PASSWORD','password.txt'), 'r', encoding='utf-8') as f:
                    password = f.read()
                self.users_list[name] = [i.lower(), password]
        for i in self.users_list.keys():
            avatar(Path('MaxOS','!Registry','USERS','LIST_USERS',self.users_list[i][0].upper(),'SAVING','USER_ICON','UserIcon.png'), Path('MaxOS','!Registry','USERS','USERS_ICONS',f"{self.users_list[i][0].upper()}.png"))
        print(self.users_list)
        self.main = Frame(master, bg='black')
        self.main.pack(fill=BOTH, expand=1)



        img = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','DESKTOP_IMAGE','image1.png'))
        img = img.resize((sizeX, sizeY), Image.ANTIALIAS)
        img = ImageTk.PhotoImage(img)

        self.maindesktop = Frame(self.main, bg='black', width=5000, height=5000)
        self.maindesktop.place(x=0, y=0)


        if sys.platform == "win32":
            self.tb = Toplevel()
            self.tb.wm_attributes('-fullscreen',1)
            self.tb.wm_attributes('-topmost',1)
            self.tb.wm_attributes("-transparentcolor", '#123456')
            self.tb['bg'] = '#123456'
            self.tb.wm_attributes('-alpha', 0.7)
            self.tb['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
        else:
            self.tb = self.main

        self.tb_main01 = CTkFrame(self.tb, fg_color='#EFFBFF', corner_radius=15)
        self.tb_main01.pack(anchor=NW, padx=20, pady=20, fill=Y)

        self.tb_main1 = Frame(self.tb_main01, bg='#EFFBFF')
        self.tb_main1.pack(anchor=NW, padx=5, pady=5)

        UserIcon = Image.open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','UserIcon.png'))
        UserIcon = UserIcon.resize((40, 40), Image.ANTIALIAS)
        UserIcon = ImageTk.PhotoImage(UserIcon)


        self.NoActiveState = 1
        self.SelectState = 0

        def shutdown():
            def Ok(e=''):
                Shutdown(self.main, self.tb)
                w.destroy()
            w = WhatDialogWin(self.main, title='Выключение', text='Вы точно хотите выключить компьютер?', textyes='Да', textno='Отмена', command=Ok, type='warning', global_update=0)
        BUTTON_MENU(self.tb_main1, path='SHUTDOWN_BTN', command=shutdown).pack(padx=3, pady=3)
        BUTTON_MENU(self.tb_main1, path='RESTART_BTN', command=lambda: PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','dialogwin.wav'))).pack(padx=3, pady=3)
        BUTTON_MENU(self.tb_main1, path='SLEEP_MODE_BTN', command=lambda: PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','logon.wav'))).pack(padx=3, pady=3)

        Separator(self.tb_main1, orient='horizontal')

        def tick_watch():
            self.watch.after(1000, tick_watch)
            self.watch['text'] = time.strftime('%H:%M')#%S

        self.watch = Label(self.tb_main1, bg='#EFFBFF', font=('Montserrat', 35), fg='black', text='12:00')
        self.watch.pack(padx=2, pady=2)

        tick_watch()

        Separator(self.tb_main1, orient='horizontal')


        def date_tick():
            a = time.strftime("%a")
            if a == 'Mon':a = "Пн"
            elif a == 'Tue':a = "Вт"
            elif a == 'Wed':a = "Ср"
            elif a == 'Thu':a = "Чт"
            elif a == 'Fri':a = "Пт"
            elif a == 'Sat':a = "Сб"
            elif a == 'Sun':a = "Вс"
            dt = datetime.datetime.now()
            dt_string = dt.strftime("%d/%m/%Y")
            b = a + dt_string
            self.date1['text'] = a
            self.date2['text'] = dt_string
            self.date.after(100, date_tick)

        self.date = Frame(self.tb_main1, bg='#EFFBFF')
        self.date.pack(padx=2, pady=2, expand=1)

        self.date1 = Label(self.date, bg='#EFFBFF', font=('Montserrat', 15), fg='black', text='Суббота')
        self.date1.pack(padx=2, pady=2, expand=1)
        self.date2 = Label(self.date, bg='#EFFBFF', font=('Montserrat', 15), fg='black', text='16/07/2022')
        self.date2.pack(padx=2, pady=2, expand=1)
        date_tick()

        #Separator(self.tb_main1, orient='horizontal')

        self.FramesUsers = CTkScrollableFrame(self.tb_main1, corner_radius=0, width=100)
        self.FramesUsers.pack(fill=BOTH)

        ListButton(self.FramesUsers, text='Создать', image=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','plus.png'), size=20, command=lambda: create_user(master=self.main, root=master, sizeX=sizeX, sizeY=sizeY, system=system, destroycmd1=self.tb, destroycmd2=self.main, users_list=self.users_list), fontsize=12).pack(fill=X)
        Separator(self.FramesUsers, orient='horizontal')
        class enter_in_guest():
            def __init__(self, sizeX='', sizeY='', system='', destroycmd1='', destroycmd2=''):
                self.sizeX = sizeX
                self.sizeY = sizeY
                self.system = system
                self.destroycmd1 = destroycmd1
                self.destroycmd2 = destroycmd2
                open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','password.txt'), 'w', encoding='utf-8').write('none')
                open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','user.txt'), 'w', encoding='utf-8').write('Гость')
                open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'w', encoding='utf-8').write(str(Path('Users','_guest')))
                open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','registry_path.txt'), 'w', encoding='utf-8').write(str(Path('MaxOS','!Registry','USERS','LIST_USERS','_GUEST')))
                de = EnterUser(self.destroycmd2, self.destroycmd1, self.sizeX, self.sizeY, sys.platform)
        ListButton(self.FramesUsers, text='Гость', image=Path('MaxOS','!Registry','USERS','USERS_ICONS','_GUEST.png'), size=20, command=lambda: enter_in_guest(sizeX, sizeY, system, self.tb, self.main), fontsize=12).pack(fill=X)
        class enter_in_user():
            def getpassword(self):
                return self.entrynamecopy.get()
            def destroy(self):
                self.a = 0.95
                def exiting(event=None):
                    after_exit = self.root.after(10, exiting)
                    if self.a < 0:
                        self.root.after_cancel(after_exit)
                        self.root.destroy()
                    self.a -= 0.05
                    try:
                        self.root.wm_attributes('-alpha', self.a)
                    except Exception:
                        pass
                exiting()
            def __init__(self, master=None, title='Добавить аккаунт', command=None, root='', sizeX='', sizeY='', system='', destroycmd1='', destroycmd2='', userslist='', selecteduser=''):
                PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','dialogwin.wav'))
                self.master = master
                self.title = title
                self.command = command
                self.root = root
                self.sizeX = sizeX
                self.sizeY = sizeY
                self.system = system
                self.destroycmd1 = destroycmd1
                self.destroycmd2 = destroycmd2
                self.userslist = userslist
                self.selecteduser = selecteduser
                bg_tb = ''
                fg_tb = ''
                fontMaxOS = ''
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg1:
                    bg_tb = bg1.read()
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg1:
                    fg_tb = fg1.read()
                with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f1:
                    fontMaxOS = f1.read()


                def theme_update():
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0

                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())
                    self.theme_after = self.root.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    self.root0.configure(fg_color=bg_color)
                    self.root1['bg'] = bg_color
                    self.title2['bg'] = bg_color
                    self.title2['fg'] = fg_color
                    self.title2['font'] = (font_, font_size)
                    self.frameimgdesktop['bg'] = bg_color
                    self.passlab['bg'] = bg_color
                    self.entrypassfr['bg'] = bg_color

                    self.passlab['fg'] = fg_color



                    self.passlab['font'] = (font_, font_size)

                    self.title2['fg'] = fg_color
                    self.title2['font'] = (font_, font_size)

                def GlobalUpdate():
                    self.global_after = self.root.after(100, GlobalUpdate)
                    with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','exit_user.txt',), 'r', encoding='utf-8') as f:
                        text = f.read().lower()
                        if text == 'true':
                            self.root.destroy()
                    with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','sleep_mode.txt',), 'r', encoding='utf-8') as f:
                        text = f.read().lower()
                        if text == 'true':
                            self.root.withdraw()
                        elif text == 'false':
                            self.root.deiconify()

                self.root = Toplevel(self.master)
                self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
                self.a = 0
                def showing(event=None):
                    after_show = self.root.after(10, showing)
                    x = (self.root.winfo_screenwidth() - self.root.winfo_reqwidth()) / 2
                    y = (self.root.winfo_screenheight() - self.root.winfo_reqheight()) / 2
                    self.root.geometry("+%d+%d" % (x, y))
                    if self.a > 0.9:
                        self.root.after_cancel(after_show)
                    self.a += 0.05
                    self.root.wm_attributes('-alpha', self.a)
                showing()
                def passDEF(event=None):pass
                self.root.protocol('WM_DELETE_WINDOW', passDEF)
                self.root.wm_attributes('-alpha', 0.95)
                self.root.resizable(0,0)

                def startMove(event):
                    global x, y
                    x = event.x
                    y = event.y
                    if sys.platform == 'darwin':self.root.overrideredirect(1)
                    if sys.platform == 'darwin':self.root.resizable(0,0)
                    self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
                def stopMove(event):
                    global x, y
                    x = None
                    y = None
                    if sys.platform == 'darwin':self.root.overrideredirect(0)
                    if sys.platform == 'darwin':self.root.resizable(0,0)
                    self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"
                def moving(event):
                    global x, y
                    x_ = (event.x_root - x)
                    y_ = (event.y_root - y)
                    self.root.geometry("+%s+%s" % (x_, y_))
                    if sys.platform == 'darwin':self.root.overrideredirect(1)
                    if sys.platform == 'darwin':self.root.resizable(0,0)
                    self.root['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"

                if system == 'darwin':
                    self.root.wm_attributes("-transparent", True)
                    self.root.config(bg='systemTransparent')
                elif system == 'win32':
                    self.root.wm_attributes("-transparentcolor", '#123456')
                    self.root['bg'] = '#123456'
                self.root['bd'] = 7


                self.root0 = CTkFrame(self.root, fg_color=bg_tb, corner_radius=15)
                self.root0.pack(expand=1, fill=BOTH)

                self.root1 = Frame(self.root0, bg=bg_tb)
                self.root1.pack(fill=BOTH, expand=1, padx=10, pady=10)

                self.root.wm_attributes('-topmost', 1)
                if sys.platform == 'win32':
                    self.root.wm_overrideredirect(True)
                elif sys.platform == 'darwin':
                    self.root.wm_overrideredirect(False)
                self.root.wm_attributes('-topmost', 1)
                self.title2 = Label(self.root1, bg=bg_tb, fg=fg_tb, text=self.title, font=(fontMaxOS, 15))
                self.title2.pack(anchor=NW, fill=X)
                self.title2.bind("<Button-1>", startMove)
                self.title2.bind("<ButtonRelease-1>", stopMove)
                self.title2.bind("<B1-Motion>", moving)
                self.frameimgdesktop = Frame(self.root1, bg=bg_tb, bd=7)
                self.frameimgdesktop.pack(anchor=NW, fill=BOTH, expand=1)

                self.entrypassfr = Frame(self.frameimgdesktop, bg=bg_tb)
                self.entrypassfr.pack(anchor=NW, expand=1, fill=X, pady=5, padx=5)

                self.passlab = Label(self.entrypassfr, bg=bg_tb, fg=fg_tb, text='Пароль:', font=(fontMaxOS, 15))
                self.passlab.pack(fill=Y, side=LEFT)
                self.entrypass = EntryAuto(self.entrypassfr, bg=bg_tb, fg=fg_tb, placeholder='password')
                self.entrypass.pack(fill=BOTH, side=LEFT, expand=1)

                def OK(e=''):

                    '''
                    lnames = []
                    lpass = []
                    for i in self.userslist.keys():
                        lnames.append(i)

                    for i in self.userslist.keys():
                        lpass.append(self.userslist[i][1])

                    if self.selecteduser
                    '''

                    for i in self.userslist.keys():
                        if i == self.selecteduser:
                            if self.entrypass.get() == '':
                                DialogWin(self.root, title='Ошибка', text='Введите пароль', type='error', global_update=0)
                            else:
                                if ConverFromMaxOSCode(self.userslist[i][1]) == self.entrypass.get():
                                    open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','password.txt'), 'w', encoding='utf-8').write(ConvertToMaxOSCode(self.entrypass.get()))
                                    open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','user.txt'), 'w', encoding='utf-8').write(i)
                                    open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'w', encoding='utf-8').write(str(Path('Users',self.userslist[i][0])))
                                    open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','registry_path.txt'), 'w', encoding='utf-8').write(str(Path('MaxOS','!Registry','USERS','LIST_USERS',self.userslist[i][0].upper())))
                                    de = EnterUser(self.master, self.destroycmd1, self.sizeX, self.sizeY, sys.platform)
                                    break
                                else:
                                    DialogWin(self.root, title='Ошибка', text='Неправильный пароль', type='error', global_update=0)

                self.entrypass.bind('<Return>', OK)



                self.okbtn = LabelButtonSystem(self.frameimgdesktop, font=(fontMaxOS, 15), text=' OK ', width=15, bg=bg_tb, command=OK)
                self.okbtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

                self.rootbtn = LabelButtonSystem(self.frameimgdesktop, font=(fontMaxOS, 15), text=' Войти как root ', width=15, bg=bg_tb, command=OK)
                self.rootbtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

                self.closebtn = LabelButtonSystem(self.frameimgdesktop, font=(fontMaxOS, 15), text=(' '+'Отмена'+' '), width=15, bg=bg_tb, command=self.destroy)
                self.closebtn.pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

                theme_update()
                #GlobalUpdate()
        class UsersButtons():
            def __init__(self, master, userlist, main, tb):
                def theme_update():
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())
                    self.theme_after = self.Frame.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    self.Frame['bg'] = bg_color

                self.main = main
                self.tb = tb
                self.Frame = Frame(master)
                self.Frame.pack(fill=X)

                class AddBTN():
                    def __init__(self, master, userlist, main, tb, name, hf):
                        self.main = main
                        self.tb = tb
                        self.name = name
                        self.homefolder = hf
                        if len(self.name) >= 7:
                            l2 = []
                            for i in range(len(self.name)):
                                if len(l2) <= 5:
                                    l2.append(self.name[i])
                            self.username = ''.join(l2)+"..."
                        else:
                            self.username = self.name
                        ListButton(master, text=self.username, image=Path('MaxOS','!Registry','USERS','USERS_ICONS',f"{self.homefolder}.png"), size=20, command=lambda: enter_in_user(master=self.main, root=master, sizeX=sizeX, sizeY=sizeY, system=system, destroycmd1=self.tb, destroycmd2=self.main, userslist=userlist, selecteduser=self.name, title=f"Войти как {self.name}"), fontsize=12).pack(fill=X)

                for i in sorted(userlist.keys()):
                    AddBTN(self.Frame, userlist, main, tb, i, userlist[i][0])


        if self.users_list != {}:
            UsersButtons(self.FramesUsers, self.users_list, self.main, self.tb)
        #Separator(self.FramesUsers, orient='horizontal')
        #ListButton(self.FramesUsers, text='DKM100', image=Path('MaxOS','!Registry','USERS','USERS_ICONS','DKM100.png'), size=20, command=lambda: PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','logoff.wav')), fontsize=12).pack(fill=X)

        #self.root = MaxOSTk2(icon=Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','MSOS_ico_light.png'), resizeable=0, exitfunc=empty)
        #self.root.title2('Авторизация')
        #self.root.minsize(500, 500)

        #EntryAuto(self.root.content, placeholder='password').pack()



        self.image_desktop = Label(self.maindesktop, bg='black')
        self.image_desktop.image = img
        self.image_desktop.place(x=0,y=0)
        self.image_desktop['image'] = self.image_desktop.image

        theme_update()
