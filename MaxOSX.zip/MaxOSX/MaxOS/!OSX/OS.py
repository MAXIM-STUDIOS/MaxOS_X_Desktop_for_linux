import os
os.chdir('..')
os.chdir('..')
from tkinter import *
from customtkinter import *
from PIL import Image, ImageTk
import sys
from kernel import *
from Components.DE import DE
from Components.Autorization import Autorization
from Components.Libraries.MaxOSTkinter import MaxOSTk2
from Components.Libraries.SoundPlayer import PlaySound
from pathlib import Path
import shutil

try:
    def run_MaxOS():
        PlaySound(Path('MaxOS','!Registry','SYSTEM','SYSTEM_AUDIO','maxOS.wav'))
        for i in os.listdir(Path('MaxOS','!Registry','SYSTEM','SYSTEM_INPUT','WEB_CAMERA','CLIP_BOARD')):
            os.remove(Path('MaxOS','!Registry','SYSTEM','SYSTEM_INPUT','WEB_CAMERA','CLIP_BOARD',i))
        mainroot = Tk()
        mainroot['cursor'] = f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/Default.cur"

        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'w', encoding='utf-8') as bg:
            bg.write('#333533')
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'w', encoding='utf-8') as fg:
            fg.write('#ffffff')
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'w', encoding='utf-8') as f:
            f.write('Montserrat')
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'w', encoding='utf-8') as fs:
            fs.write('15')
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CLIP_BOARDS','clip_board.txt'), 'w', encoding='utf-8') as f:
            f.write('')
        with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CLIP_BOARDS','file_clip_board.txt'), 'w', encoding='utf-8') as f:
            f.write('')

        shutil.copy(Path('MaxOS','!Registry','SYSTEM','SYSTEM_ICONS','space.png'), Path('MaxOS','!Registry','SYSTEM','SYSTEM_CLIP_BOARDS','image_clip_board.png'))

        sizeX, sizeY = mainroot.winfo_screenwidth(), mainroot.winfo_screenheight()
        if sys.platform == "darwin":
            mainroot.overrideredirect(1)
            mainroot.wm_attributes('-topmost',1)
            mainroot.geometry(f'{sizeX}x{sizeY}+0+0')
            mainroot.minsize(sizeX,sizeY)
            mainroot.maxsize(sizeX,sizeY)
            mainroot.resizable(0,0)
            mainroot.wm_attributes('-topmost',0)
        elif sys.platform == "win32":
            mainroot.wm_attributes('-fullscreen',1)

        mainroot['bg'] = 'black'


        Autorization(mainroot, sizeX, sizeY, system)

        mainroot.mainloop()

    run_MaxOS()

except Exception:
    RSOD()
