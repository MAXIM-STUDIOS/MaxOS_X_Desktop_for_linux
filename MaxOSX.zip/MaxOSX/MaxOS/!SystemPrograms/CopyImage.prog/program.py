import os
import sys
import shutil
from pathlib import Path
import sys

shutil.copy(fileopen, Path('MaxOS','!Registry','SYSTEM','SYSTEM_CLIP_BOARDS','image_clip_board.png'))
