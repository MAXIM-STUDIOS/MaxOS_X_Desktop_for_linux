import os
import sys
import shutil
from pathlib import Path
import sys
from random import randint
from threading import Thread

def write_file(file, text):
    o = open(file, 'w', encoding='utf-8')
    o.write(str(text))
    o.close()

def read_file(file):
    o = open(file, 'r', encoding='utf-8')
    text = o.read()
    o.close()
    return text

homefolder = ''
with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'r', encoding='utf-8') as f:
    homefolder = f.read()

hdd_word = ''
with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_INFO','hdd_word.txt'), 'r', encoding='utf-8') as hf:
    hdd_word = hf.read()

if fileopen == 'MS160722':
    name_shrt = f'MaxOS System'


    write_file(Path('MaxOS','!Registry','SYSTEM','SYSTEM_DE','CREATE_SHORTCUT','name.txt'), name_shrt)
    write_file(Path('MaxOS','!Registry','SYSTEM','SYSTEM_DE','CREATE_SHORTCUT','link.txt'), '.')
    write_file(Path('MaxOS','!Registry','SYSTEM','SYSTEM_DE','CREATE_SHORTCUT','coords.txt'), f"{randint(30, 50)} {randint(30, 50)}")

    write_file(Path('MaxOS','!Registry','SYSTEM','SYSTEM_DE','CREATE_SHORTCUT','create_state.txt'), 'True')
else:
    name_shrt = ''
    if os.path.splitext(fileopen)[1] in ['.prog', '.prg']:
        try:
            with open(Path(fileopen,'name.txt'), 'r', encoding='utf-8') as f:
                name_shrt = f.read()
        except:
            name_shrt = os.path.split(fileopen)[1]
    else:
        name_shrt = os.path.split(fileopen)[1]


    write_file(Path('MaxOS','!Registry','SYSTEM','SYSTEM_DE','CREATE_SHORTCUT','name.txt'), name_shrt)
    write_file(Path('MaxOS','!Registry','SYSTEM','SYSTEM_DE','CREATE_SHORTCUT','link.txt'), str(fileopen))
    write_file(Path('MaxOS','!Registry','SYSTEM','SYSTEM_DE','CREATE_SHORTCUT','coords.txt'), f"{randint(30, 50)} {randint(30, 50)}")

    write_file(Path('MaxOS','!Registry','SYSTEM','SYSTEM_DE','CREATE_SHORTCUT','create_state.txt'), 'True')
