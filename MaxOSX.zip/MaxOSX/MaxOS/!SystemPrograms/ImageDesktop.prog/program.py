import sys
import shutil
from pathlib import Path
from threading import Thread
import psutil

registry_path = ''
with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','registry_path.txt'), 'r', encoding='utf-8') as f:
    registry_path = f.read()

shutil.copy(fileopen, Path(registry_path, 'SAVING', 'DESKTOP_CONFIG', 'ImageDesktop.png'))
shutil.copy(fileopen, Path(registry_path, 'SAVING', 'DESKTOP_CONFIG', 'DESKTOPS_IMAGES','custom_desktop_image.png'))

with open(Path(registry_path, 'SAVING', 'DESKTOP_CONFIG', 'default_desktop.txt'), 'w', encoding='utf-8') as f:
    f.write('False')

with open(Path(registry_path, 'SAVING', 'DESKTOP_CONFIG', 'image_desktop.txt'), 'w', encoding='utf-8') as f:
    f.write('True')

with open(Path(registry_path, 'SAVING', 'DESKTOP_CONFIG', 'image_desktop_change.txt'), 'w', encoding='utf-8') as f:
    f.write('True')
