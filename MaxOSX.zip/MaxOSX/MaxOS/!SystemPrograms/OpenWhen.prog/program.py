from MaxOSTkinter import (
                            MaxOSTk,
                            DialogWin,
                            WhatDialogWin,
                            LabelButtonSystem,
                            ListButton,
                            Separator,
                            empty,
                            ColorDialogWin,
                            MaxOSTk2,
                            BUTTON_MENU,
                            DialogWinCustom,
                            ThemeButtons,
                            FileDialogWin
                        )
from tkinter import (
                        Frame,
                        Label,
                        Toplevel,
                        BOTH,
                        Y,
                        X,
                        NW,
                        N,
                        SW,
                        S,
                        W,
                        E,
                        NE,
                        LEFT,
                        RIGHT,
                        TOP,
                        BOTTOM,
                        Menu,
                        font,
                        Text,
                        END
                    )
import os
import sys
import shutil
from pathlib import Path
from threading import Thread
from customtkinter import CTkLabel, CTkFrame, CTkComboBox, CTkSlider, CTkScrollableFrame
from PIL import Image, ImageTk, ImageColor, ImageChops
import psutil
import sys

sys.path.append(Path('MaxOS','!OSX'))

from Components.RunProgram import run_program

class App():
    def __init__(self):
        def theme_update():
            def get_hex(r, g, b):
                return '#{:02x}{:02x}{:02x}'.format(r, g, b)
            self.theme_after = self.root.content.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
            bg_color = ''
            fg_color = ''
            font_ = ''
            font_size = 0
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                bg_color = bg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                fg_color = fg.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                font_ = f.read()
            with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                font_size = int(fs.read())

            color_rgb_activebackground = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_activebackground[0] == 0 or color_rgb_activebackground[0] <= 10:
                color_rgb_activebackground[0] = 0
            else:
                color_rgb_activebackground[0] = color_rgb_activebackground[0]-10

            if color_rgb_activebackground[1] == 0 or color_rgb_activebackground[1] <= 10:
                color_rgb_activebackground[1] = 0
            else:
                color_rgb_activebackground[1] = color_rgb_activebackground[1]-10

            if color_rgb_activebackground[2] == 0 or color_rgb_activebackground[2] <= 10:
                color_rgb_activebackground[2] = 0
            else:
                color_rgb_activebackground[2] = color_rgb_activebackground[2]-10

            activebackground = get_hex(color_rgb_activebackground[0], color_rgb_activebackground[1], color_rgb_activebackground[2])


            color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

            if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                color_rgb_select[0] = 250
            else:
                color_rgb_select[0] = color_rgb_select[0]+10

            if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                color_rgb_select[1] = 250
            else:
                color_rgb_select[1] = color_rgb_select[1]+10

            if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                color_rgb_select[2] = 250
            else:
                color_rgb_select[2] = color_rgb_select[2]+10

            selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

            self.bg_ = bg_color
            self.fg_ = fg_color
            self.selectbg_ = selectbg
            self.activebg_ = activebackground

            self.framebtns['bg'] = bg_color

            self.frame_programs.configure(fg_color=bg_color)
            self.frame_programs.configure(scrollbar_fg_color=bg_color)
            self.frame_programs.configure(scrollbar_button_color=bg_color)
            self.frame_programs.configure(scrollbar_button_hover_color=selectbg)

            self.menubar['bg'] = bg_color

            if self.ACTIVE_prog_STATE == 1 and self.HOVER_prog_STATE == 0:
                self.prog_btn['bg'] = self.activebg_
                self.prog_btn['fg'] = fg_color
                self.prog_btn['font'] = (font_, font_size-2)
            elif self.HOVER_prog_STATE == 1:
                self.prog_btn['bg'] = self.selectbg_
                self.prog_btn['fg'] = fg_color
                self.prog_btn['font'] = (font_, font_size-2)
            else:
                self.prog_btn['bg'] = bg_color
                self.prog_btn['fg'] = fg_color
                self.prog_btn['font'] = (font_, font_size-2)


            if self.ACTIVE_sys_prog_STATE == 1 and self.HOVER_sys_prog_STATE == 0:
                self.sys_prog_btn['bg'] = self.activebg_
                self.sys_prog_btn['fg'] = fg_color
                self.sys_prog_btn['font'] = (font_, font_size-2)
            elif self.HOVER_sys_prog_STATE == 1:
                self.sys_prog_btn['bg'] = self.selectbg_
                self.sys_prog_btn['fg'] = fg_color
                self.sys_prog_btn['font'] = (font_, font_size-2)
            else:
                self.sys_prog_btn['bg'] = bg_color
                self.sys_prog_btn['fg'] = fg_color
                self.sys_prog_btn['font'] = (font_, font_size-2)

        self.root = DialogWinCustom()
        self.root.title('Открыть в программе')

        self.progmenu = ''
        self.progmenu_state = 0

        def OK(e=''):
            self.root.content.after_cancel(self.theme_after)
            self.root.destroy()

        self.menubar = Frame(self.root.content)
        self.menubar.pack(anchor=NE, fill=X)

        self.state_prog = 0

        def check_prog_state(e=''):
            if self.state_prog == 0:
                self.prog_btn['bg'] = self.activebg_
                self.ACTIVE_prog_STATE = 1

                self.sys_prog_btn['bg'] = self.bg_
                self.ACTIVE_sys_prog_STATE = 0

                if self.progmenu_state:
                    self.progmenu.destroy()
                self.progmenu = ProgramsMenu(mastertk=self.frame_programs)
                self.progmenu_state = 1
            elif self.state_prog == 1:
                self.prog_btn['bg'] = self.bg_
                self.ACTIVE_prog_STATE = 0

                self.sys_prog_btn['bg'] = self.activebg_
                self.ACTIVE_sys_prog_STATE = 1

                if self.progmenu_state:
                    self.progmenu.destroy()
                self.progmenu = SysProgramsMenu(mastertk=self.frame_programs)
                self.progmenu_state = 1

        self.ACTIVE_prog_STATE = 1
        self.HOVER_prog_STATE = 0

        def hover_prog(e=''):
            self.prog_btn['bg'] = self.selectbg_
            self.HOVER_prog_STATE = 1
        def unhover_prog(e=''):
            if self.ACTIVE_prog_STATE:
                self.prog_btn['bg'] = self.activebg_
            else:
                self.prog_btn['bg'] = self.bg_
            self.HOVER_prog_STATE = 0

        def click_prog(e=''):
            self.ACTIVE_prog_STATE = 1
            self.state_prog = 0
            check_prog_state()
        self.prog_btn = Label(self.menubar, text='Программы', cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
        self.prog_btn.pack(side=LEFT, expand=1, fill=BOTH)
        self.prog_btn.bind('<Enter>',hover_prog)
        self.prog_btn.bind('<Leave>',unhover_prog)
        self.prog_btn.bind('<Button-1>',click_prog)


        self.ACTIVE_sys_prog_STATE = 0
        self.HOVER_sys_prog_STATE = 0

        def hover_sys_prog(e=''):
            self.sys_prog_btn['bg'] = self.selectbg_
            self.HOVER_sys_prog_STATE = 1
        def unhover_sys_prog(e=''):
            if self.ACTIVE_sys_prog_STATE:
                self.sys_prog_btn['bg'] = self.activebg_
            else:
                self.sys_prog_btn['bg'] = self.bg_
            self.HOVER_sys_prog_STATE = 0

        def click_sys_prog(e=''):
            self.ACTIVE_sys_prog_STATE = 1
            self.state_prog = 1
            check_prog_state()
        self.sys_prog_btn = Label(self.menubar, text='Системные программы', cursor=f"@MaxOS/!Registry/SYSTEM/SYSTEM_ICONS/CURSORS/link.cur")
        self.sys_prog_btn.pack(side=LEFT, expand=1, fill=BOTH)
        self.sys_prog_btn.bind('<Enter>',hover_sys_prog)
        self.sys_prog_btn.bind('<Leave>',unhover_sys_prog)
        self.sys_prog_btn.bind('<Button-1>',click_sys_prog)

        class ProgramsMenu():
            def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
                self.side = side
                self.anchor = anchor
                self.expand = expand
                self.fill = fill
                self.padx, self.pady, self.ipadx, self.ipady = padx, pady, ipadx, ipady
                self.Frame.pack(side=self.side,
                    anchor=self.anchor,
                    expand=self.expand,
                    fill=self.fill,
                    padx=self.padx,
                    pady=self.pady,
                    ipadx=self.ipadx,
                    ipady=self.ipady
                )
            def destroy(self):
                self.Frame.after_cancel(self.theme_after)
                self.Frame.destroy()
            def __init__(self, mastertk, fileopen=fileopen, OK=OK):
                def theme_update():
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())
                    self.theme_after = self.Frame.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    self.Frame['bg'] = bg_color

                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)

                    self.fg_ = fg_color
                    self.bg_ = bg_color
                    self.font_ = font_
                    self.font_size = font_size

                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

                    self.selectbg_ = selectbg

                homefolder = ''
                with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'r', encoding='utf-8') as f:
                    homefolder = f.read()

                self.Frame = Frame(mastertk)
                self.pack(fill=BOTH, expand=1)

                theme_update()

                class AddBTN():
                    def __init__(self, master, name, path, bg, fg, font, font_size, selectbg, fileopen=fileopen, OK=OK):
                        self.name = name
                        self.path = path
                        self.bg_ = bg
                        self.fg_ = fg
                        self.font_ = font
                        self.font_size = font_size
                        self.selectbg_ = selectbg


                        text = ''
                        with open(Path(self.path,'name.txt'), 'r', encoding='utf-8') as f:
                            text = f.read()

                        def run():
                            run_program(D=os.path.split(self.path)[0], F=self.name, fileopen=fileopen)
                            OK()

                        text = ''
                        with open(Path(self.path,'name.txt'), 'r', encoding='utf-8') as f:
                            text = f.read()

                        if len(text) > 20:
                            text2 = []
                            for i in range(len(text)):
                                if i <= 17:
                                    text2.append(text[i])

                            text2 = ''.join(text2)
                            text2 = f"{text2}..."
                        else:
                            text2 = text

                        self.prog = ListButton(master, text=text2, image=Path(path, 'icon.png'), size=20, command=run, fontsize=10)
                        self.prog.pack(fill=X)

                        #self.prog.bind('<Button-2>', menuprog)
                        #self.prog.bind('<Button-3>', menuprog)
                        #self.prog.bind('<Control-Button-1>', menuprog)

                for i in os.listdir(Path(homefolder,'Programs')):
                    if i[0] in ['!','.']:pass
                    else:
                        if os.path.splitext(i)[1].lower() == '.prog' or os.path.splitext(i)[1].lower() == '.prg':
                            AddBTN(self.Frame, i, path=Path(homefolder,'Programs',i), bg=self.bg_, fg=self.fg_, font=self.font_, font_size=self.font_size, selectbg=self.selectbg_)

        class SysProgramsMenu():
            def pack(self, side=None, anchor=None, ipadx=None, ipady=None, padx=None, pady=None, expand=0, fill=None):
                self.side = side
                self.anchor = anchor
                self.expand = expand
                self.fill = fill
                self.padx, self.pady, self.ipadx, self.ipady = padx, pady, ipadx, ipady
                self.Frame.pack(side=self.side,
                    anchor=self.anchor,
                    expand=self.expand,
                    fill=self.fill,
                    padx=self.padx,
                    pady=self.pady,
                    ipadx=self.ipadx,
                    ipady=self.ipady
                )
            def destroy(self):
                self.Frame.after_cancel(self.theme_after)
                self.Frame.destroy()
            def __init__(self, mastertk, fileopen=fileopen, OK=OK):
                def theme_update():
                    bg_color = ''
                    fg_color = ''
                    font_ = ''
                    font_size = 0
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','bg_tb.txt'), 'r', encoding='utf-8') as bg:
                        bg_color = bg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_COLORS','fg_tb.txt'), 'r', encoding='utf-8') as fg:
                        fg_color = fg.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font.txt'), 'r', encoding='utf-8') as f:
                        font_ = f.read()
                    with open(Path('MaxOS','!Registry','SYSTEM','SYSTEM_CUSTOMIZE','SYSTEM_FONTS','standart_font_size.txt'), 'r', encoding='utf-8') as fs:
                        font_size = int(fs.read())
                    self.theme_after = self.Frame.after(10000, theme_update)#lambda: Thread(target=theme_update, daemon=1).start())
                    self.Frame['bg'] = bg_color

                    def get_hex(r, g, b):
                        return '#{:02x}{:02x}{:02x}'.format(r, g, b)

                    self.fg_ = fg_color
                    self.bg_ = bg_color
                    self.font_ = font_
                    self.font_size = font_size

                    color_rgb_select = list(ImageColor.getcolor(bg_color, "RGB"))

                    if color_rgb_select[0] == 255 or color_rgb_select[0] >= 250:
                        color_rgb_select[0] = 250
                    else:
                        color_rgb_select[0] = color_rgb_select[0]+10

                    if color_rgb_select[1] == 255 or color_rgb_select[1] >= 250:
                        color_rgb_select[1] = 250
                    else:
                        color_rgb_select[1] = color_rgb_select[1]+10

                    if color_rgb_select[2] == 255 or color_rgb_select[2] >= 250:
                        color_rgb_select[2] = 250
                    else:
                        color_rgb_select[2] = color_rgb_select[2]+10

                    selectbg = get_hex(color_rgb_select[0],color_rgb_select[1],color_rgb_select[2])

                    self.selectbg_ = selectbg

                homefolder = ''
                with open(Path('MaxOS','!Registry','USERS','CURRENT_USER_INFO','homefolder.txt'), 'r', encoding='utf-8') as f:
                    homefolder = f.read()

                self.Frame = Frame(mastertk)
                self.pack(fill=BOTH, expand=1)

                theme_update()

                class AddBTN():
                    def __init__(self, master, name, path, bg, fg, font, font_size, selectbg, fileopen=fileopen, OK=OK):
                        self.name = name
                        self.path = path
                        self.bg_ = bg
                        self.fg_ = fg
                        self.font_ = font
                        self.font_size = font_size
                        self.selectbg_ = selectbg


                        text = ''
                        with open(Path(self.path,'name.txt'), 'r', encoding='utf-8') as f:
                            text = f.read()

                        def run():
                            run_program(D=os.path.split(self.path)[0], F=self.name, fileopen=fileopen)
                            OK()

                        text = ''
                        with open(Path(self.path,'name.txt'), 'r', encoding='utf-8') as f:
                            text = f.read()

                        if len(text) > 20:
                            text2 = []
                            for i in range(len(text)):
                                if i <= 17:
                                    text2.append(text[i])

                            text2 = ''.join(text2)
                            text2 = f"{text2}..."
                        else:
                            text2 = text

                        self.prog = ListButton(master, text=text2, image=Path(path, 'icon.png'), size=20, command=run, fontsize=10)
                        self.prog.pack(fill=X)

                        #self.prog.bind('<Button-2>', menuprog)
                        #self.prog.bind('<Button-3>', menuprog)
                        #self.prog.bind('<Control-Button-1>', menuprog)

                for i in os.listdir(Path('MaxOS','!SysPrograms')):
                    if i[0] in ['!','.']:pass
                    else:
                        if os.path.splitext(i)[1].lower() == '.prog' or os.path.splitext(i)[1].lower() == '.prg':
                            AddBTN(self.Frame, i, path=Path('MaxOS','!SysPrograms',i), bg=self.bg_, fg=self.fg_, font=self.font_, font_size=self.font_size, selectbg=self.selectbg_)
        self.frame_programs = CTkScrollableFrame(self.root.content, corner_radius=0)
        self.frame_programs.pack(fill=BOTH, expand=1, anchor=NW)

        #self.progmenu = ProgramsMenu(mastertk=self.frame_programs)
        #self.progmenu_state = 1


        self.framebtns = Frame(self.root.content)
        self.framebtns.pack(side=BOTTOM, fill=X, expand=1, anchor=NW)

        def close():
            self.root.content.after_cancel(self.theme_after)
            self.root.destroy()

        LabelButtonSystem(self.framebtns, text=(' '+'Отмена'+' '), command=close).pack(anchor=S, side=LEFT, fill=X, expand=1, padx=5, pady=5)

        theme_update()
        check_prog_state()
App()
